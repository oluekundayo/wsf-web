import { DatePipe } from "@angular/common";
import { Injectable } from "@angular/core";
import * as moment from "moment";

@Injectable()
export class UtilitiesService {
  constructor(private datepipe: DatePipe) {}

  static convertDateAsString(date: Date): string {
    //return this.datepipe.transform(date, "yyyy-MMMM-dd");
    // return this.datepipe.transform(date, "MMM dd, yyyy");
    return moment(date).format("MMM DD, YYYY");
  }

  // solution to the timezone wahala is to use a different date format from 'DD-MMM-YYYY' to 'MMM DD, YYYY'

  createDateAsUTCKeep(date: Date) {
    return moment.utc(date.toISOString()).toDate();
  }

  createDateStringAsUTCDate(dateString: string): Date {
    const date = new Date(dateString);
    if (date) {
      return new Date(
        Date.UTC(
          date.getFullYear(),
          date.getMonth(),
          date.getDate(),
          date.getHours(),
          date.getMinutes(),
          date.getSeconds()
        )
      );
    } else {
      return date;
    }
  }

  createDateAsUTC(date: Date) {
    // console.log(date);

    if (date) {
      return new Date(
        Date.UTC(
          date.getFullYear(),
          date.getMonth(),
          date.getDate(),
          date.getHours(),
          date.getMinutes(),
          date.getSeconds()
        )
      );
    } else {
      return date;
    }
  }

  getQuarter(date: Date) {
    return moment(date)
      .utc()
      .quarter();
  }

  getCurrentQuarter() {
    return moment().quarter(); //outputs current quarter ie. 2
  }

  getWeekNo(date: Date): number {
    const pipe = new DatePipe("en-US");
    return parseInt(pipe.transform(date, "W"));

    //return moment(date).monthWeek() + 1; // 0
  }
}
