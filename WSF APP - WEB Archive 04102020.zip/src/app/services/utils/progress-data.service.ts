import { Injectable } from "@angular/core";

//https://alligator.io/angular/httpclient-intro/
import {
  HttpClient,
  HttpRequest,
  HttpEvent,
  HttpEventType
} from "@angular/common/http";

@Injectable()
export class ProgressDataService {
  url = "/some/api";

  constructor(private http: HttpClient) {}

  getData() {
    const req = new HttpRequest("GET", this.url, {
      reportProgress: true
    });

    this.http.request(req).subscribe((event: HttpEvent<any>) => {
      switch (event.type) {
        case HttpEventType.Sent:
          console.log("Request sent!");
          break;
        case HttpEventType.ResponseHeader:
          console.log("Response header received!");
          break;
        case HttpEventType.DownloadProgress:
          const kbLoaded = Math.round(event.loaded / 1024);
          console.log(`Download in progress! ${kbLoaded}Kb loaded`);
          break;
        case HttpEventType.Response:
          console.log("😺 Done!", event.body);
      }
    });
  }
}
