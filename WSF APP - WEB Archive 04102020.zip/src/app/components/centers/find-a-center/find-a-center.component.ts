import { finalize } from "rxjs/operators";
import { Component, OnInit, OnDestroy } from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import { Lookup, ApiUrlParam } from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import {
  CenterSearchResult,
  CenterSearchParams
} from "../../../models/centers.models";
import { BsModalRef } from "ngx-bootstrap/modal";

@Component({
  selector: "app-find-a-center",
  templateUrl: "./find-a-center.component.html",
  styleUrls: ["./find-a-center.component.scss"]
})
export class FindACenterComponent implements OnInit, OnDestroy {
  loading = false;
  centerTypes: Lookup[] = [];
  formGroup: FormGroup;
  //centerTypePositionLevels: Observable<Lookup[]>;
  centerFinderResults: CenterSearchResult[];
  //_includePositionHolderInSearch = false;
  //includePHInSearchSubscription: Subscription;

  constructor(private api: APIService, private fb: FormBuilder) {
    this.formGroup = fb.group({
      centerTypeId: [null],
      searchByAddress: [""],
      limitSearchToDescendants: false,
      limitSearchToACenterType: true
    });
  }

  ngOnInit() {
    this.loading = true;
    this.api
      .getAll<Lookup[]>(ApiRoutes.centers.centers_types_lookup)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.centerTypes = response;
      });
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
  }

  public findACenter() {
    const finder: CenterSearchParams = this.formGroup.value;

    if (finder == null) {
      alert("Search Criteria not valid.");
      return;
    }

    if (finder.centerTypeId <= 0) {
      alert("Invalid Center Type to find.");
      return;
    }

    if (!finder.searchByAddress) {
      alert("Area of Coverage is Required");
      return;
    }

    this.loading = true;
    this.api
      .post<CenterSearchResult[]>(ApiRoutes.centers.search, finder)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.centerFinderResults = response;
      });
  }

  ngOnDestroy(): void {}
}
