import { Injectable } from "@angular/core";
import { PaginatorFilter } from "../../models/utilities.models";

@Injectable({
  providedIn: "root"
})
export class PagerService {
  constructor() {}

  // https://jasonwatmore.com/post/2016/08/23/angular-2-pagination-example-with-logic-like-google
  //https://g00glen00b.be/pagination-component-angular-2/
  resetPager(paginator: PaginatorFilter) {
    if (paginator && paginator.totalItemsCount) {
      // console.log(paginator);
      /*
      // calculate total pages
      let totalPages = Math.ceil(
        paginator.totalItemsCount / paginator.pageSize
      );

      // ensure current page isn't out of range
      if (paginator.currentPage < 1) {
        paginator.currentPage = 1;
      } else if (paginator.currentPage > totalPages) {
        paginator.currentPage = totalPages;
      }

      let startPage: number, endPage: number;
      if (totalPages <= 10) {
        // less than 10 total pages so show all
        startPage = 1;
        endPage = totalPages;
      } else {
        // more than 10 total pages so calculate start and end pages
        if (paginator.currentPage <= 6) {
          startPage = 1;
          endPage = 10;
        } else if (paginator.currentPage + 4 >= totalPages) {
          startPage = totalPages - 9;
          endPage = totalPages;
        } else {
          startPage = paginator.currentPage - 5;
          endPage = paginator.currentPage + 4;
        }
      }

      // calculate start and end item indexes
      let startIndex = (paginator.currentPage - 1) * paginator.pageSize;
      let endIndex = Math.min(
        startIndex + paginator.pageSize - 1,
        paginator.totalItemsCount - 1
      );

      // create an array of pages to ng-repeat in the pager control
      let pages = Array.from(Array(endPage + 1 - startPage).keys()).map(
        i => startPage + i
      );

      // return object with all pager properties required by the view
      paginator.totalPages = totalPages;
      paginator.startPage = startPage;
      paginator.endPage = endPage;
      paginator.startIndexForItemsOfCurrentPage = startIndex;
      paginator.endIndexForItemsOfCurrentPage = endIndex;
      paginator.pagesList = pages;

      */
    }
  }
}
