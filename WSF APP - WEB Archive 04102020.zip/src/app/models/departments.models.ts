import { MemberPersonalDetails } from "./centers.models";

export class Department {
  id: number;
  center: string;
  center_id: number;
  parent_group_id: number;
  parent_group: string;
  name: string;
  description: string;
  is_sub_group: boolean;
  effective_date: Date;
  created_at: Date;
  created_by: string;
}

export class DepartmentMember {
  member_id: number;
  center: string;
  center_id: number;
  department: string;
  department_id: number;
  position_level: string;
  personalDetails: MemberPersonalDetails;
  joined_at: Date;
  converted_at: Date;
  is_first_timer: boolean;
  created_at: Date;
  created_by: string;
}

/*
export class DepartmentsRoutes {
    static departments = "department";
    static departmentsMembers = "department_members";
   
  }*/
