import { NgModule } from "@angular/core";
import { SharedModule } from "../../app.shared.module";
import { SendOutPublicationsComponent } from "./send-out-publications/send-out-publications.component";
import { ViewPublications } from "./view-publications/view-publications.component";
import { PublicationsRoutingModule } from "./publications-routing.module";
import {
  FileSelectDirective,
  FileUploader,
  FileUploadModule
} from "ng2-file-upload";
import { AngularEditorModule } from "@kolkov/angular-editor";
import { PublicationsReportComponent } from "./publications-report/publications-report.component";
import { ChartsModule } from "ng2-charts";
import { FileSizePipe } from "../../pipes/file-size.pipe";
import { ApprovePublicationDialogComponent } from "../dialog/approve-publication-dialog/approve-publication-dialog.component";
@NgModule({
  imports: [
    SharedModule,
    PublicationsRoutingModule,
    AngularEditorModule,
    FileUploadModule,
    ChartsModule
  ],
  declarations: [
    SendOutPublicationsComponent,
    ViewPublications,
    ApprovePublicationDialogComponent,
    PublicationsReportComponent,
    FileSizePipe
  ],
  entryComponents: [ApprovePublicationDialogComponent]
})
export class PublicationsModule {}
