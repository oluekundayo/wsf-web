import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "../../services/guards/auth-guard.service";
import { ForwardAccessCodesComponent } from "./forward-access-codes/forward-access-codes.component";
import { MyProfileComponent } from "./my-profile/my-profile.component";
import { ChangePasswordComponent } from "./change-password/change-password.component";

const routes: Routes = [
  {
    path: "forward-access-codes",
    component: ForwardAccessCodesComponent,
    data: {
      title: "Forward Access Codes"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "my-profile",
    component: MyProfileComponent,
    data: {
      title: "My Profile"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "change-password",
    component: ChangePasswordComponent,
    data: {
      title: "Change Password"
    },
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserAccountRoutingModule {}
