import { NgModule } from "@angular/core";
import { SharedModule } from "../../app.shared.module";
import { ForwardAccessCodesComponent } from "./forward-access-codes/forward-access-codes.component";
import { UserAccountRoutingModule } from "./user-account-routing.module";
import { MyProfileComponent } from "./my-profile/my-profile.component";
import { ChangePasswordComponent } from "./change-password/change-password.component";
import { ReadOnlyComponent } from "../utilities/read-only/read-only.component";

@NgModule({
  imports: [SharedModule, UserAccountRoutingModule],
  declarations: [
    ForwardAccessCodesComponent,
    MyProfileComponent,
    ChangePasswordComponent,
    ReadOnlyComponent
  ]
  // entryComponents: [ApproveTestimoniesDialogComponent]
})
export class UserAccountModule {}
