import {
  Component,
  OnInit,
  AfterViewInit,
  AfterViewChecked,
  AfterContentInit,
  OnDestroy
} from "@angular/core";
import { Subscription } from "rxjs";
import { MenuInfo } from "../models/menu.models";
import { Router } from "@angular/router";
import { AuthService } from "../services/auth.service";
import { MenuService } from "../services/components-services/menu.service";

declare var $: any;

@Component({
  moduleId: module.id,
  selector: "sidebar-cmp",
  templateUrl: "sidebar.component.html"
})
export class SidebarComponent implements OnDestroy {
  public menuItems: MenuInfo[] = [];
  public sideMenuTitle: string = "WSF PORTAL";
  public churchWebsite: string = "http://faithtabernacle.org.ng";
  public menuSubscription: Subscription;

  constructor(
    private menuService: MenuService,
    private router: Router,
    private authService: AuthService
  ) {
    this.menuSubscription = this.menuService
      .GetUserMenu()
      .subscribe(response => {
        this.menuItems = response;
        //console.log(response);
      });
  }

  isNotMobileMenu() {
    try {
      if ($(window).width() > 991) {
        return false;
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  ngOnInit() {
    try {
      var isWindows = navigator.platform.indexOf("Win") > -1 ? true : false;
      //this.menuItems = ROUTES.filter(menuItem => menuItem);

      isWindows = navigator.platform.indexOf("Win") > -1 ? true : false;

      if (isWindows) {
        // if we are on windows OS we activate the perfectScrollbar function
        $(".sidebar .sidebar-wrapper, .main-panel").perfectScrollbar();
        $("html").addClass("perfect-scrollbar-on");
      } else {
        $("html").addClass("perfect-scrollbar-off");
      }
    } catch (e) {}
  }
  ngAfterViewInit() {
    try {
      var $sidebarParent = $(
        ".sidebar .nav > li.active .collapse li.active > a"
      )
        .parent()
        .parent()
        .parent();

      var collapseId = $sidebarParent.siblings("a").attr("href");

      $(collapseId).collapse("show");
    } catch (e) {}
  }

  ngOnDestroy(): void {
    try {
      this.menuSubscription.unsubscribe();
    } catch (e) {}
  }

  cacheResourceId(menuItemId: number) {
    this.authService.setResourceId(menuItemId);
  }

  public confirmLogout() {
    if (confirm("Wants to Logout? Please confirm")) {
      this.router.navigate(["/auth/user/login"]);
    }
  }
}
