import { Component, OnInit, TemplateRef } from "@angular/core";
import { CenterType, PositionLevel } from "../../../models/centers.models";
import { Observable } from "rxjs";
import { finalize } from "rxjs/operators";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import {
  AssignableResource,
  AssignableResourceGroup
} from "../../../models/resources.models";

import { groupBy, map, chain } from "lodash";
import { PrivilegesDialogComponent } from "../../dialog/privileges-dialog/privileges-dialog.component";
import { ResourcesSetupDialogComponent } from "../../dialog/resources-setup-dialog/resources-setup-dialog.component";
import { MeetingSetup, Meeting } from "../../../models/meetings.models";
import { ResponseModel, Lookup } from "../../../models/utilities.models";

@Component({
  selector: "app-meetings-setup",
  templateUrl: "./meetings-setup.component.html",
  styleUrls: ["./meetings-setup.component.scss"]
})
export class MeetingsSetupComponent implements OnInit {
  meetings: Lookup[] = [];
  churchsystems: Lookup[];
  loading: boolean = false;

  formGroup: FormGroup;
  selectedMeeting: Lookup;

  reportTypeList: string[] = [];
  statusList: string[] = [];
  weekdayList: string[] = [];

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    private modalService: BsModalService,
    private sweetAlertService: SweetAlertService
  ) {
    this.weekdayList = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Thursday",
      "Friday",
      "Saturday"
    ];
    this.reportTypeList = ["Attendance", "Participants"];
    this.statusList = [
      "Active",
      "Inactive",
      "Approved",
      "Disapproved",
      "Visible",
      "NotVisible"
    ];

    this.createConfigForm();
  }

  ngOnInit() {
    this.loadMeetings();
    this.loadChurchSystems();
  }

  private loadMeetings() {
    this.loading = true;
    this.api
      .getAll<Lookup[]>(ApiRoutes.meetings.meetings)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.meetings = response;
      });
  }

  private loadChurchSystems() {
    this.loading = true;
    this.api
      .getAll<Lookup[]>(
        ApiRoutes.church_setups.church_operational_systems_lookup
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.churchsystems = response;
      });
  }

  private createConfigForm() {
    this.formGroup = this.fb.group({
      id: [null],
      details: this.fb.group({
        name: ["", Validators.required],
        description: [""],
        status: [null, Validators.required],
        churchSystemId: [0],
        postUrlOnWeb: [""],
        postUrlOnMobile: [""],
        getUrlOnWeb: [""],
        getUrlOnMobile: [""]
      }),
      config: this.fb.group({
        meetingWeekDays: [""],
        requiredParticipationCount: [0],
        holdsInSections: [false],
        hasOfferings: [false],
        requiredApprovalTypes: [null],
        reportEditAllowableHours: [0],
        reportingType: [null],
        isAccessibleToAll: [false]
      })
    });
  }

  private patchConfigForm(meeting: MeetingSetup) {
    if (meeting == null) {
      this.formGroup.reset();
      return;
    }

    //console.log(meeting);

    if (meeting.details != null)
      this.formGroup.patchValue({
        id: this.selectedMeeting.id,
        details: {
          name: meeting.details.name,
          description: meeting.details.description,
          status: meeting.details.status,
          churchSystemId: meeting.details.churchSystemId,
          postUrlOnWeb: meeting.details.postUrlOnWeb,
          postUrlOnMobile: meeting.details.postUrlOnMobile,
          getUrlOnWeb: meeting.details.getUrlOnWeb,
          getUrlOnMobile: meeting.details.getUrlOnMobile
        },
        config: {
          meetingWeekDays: meeting.config.meetingWeekDays,
          requiredParticipationCount: meeting.config.requiredParticipationCount,
          holdsInSections: meeting.config.holdsInSections,
          hasOfferings: meeting.config.hasOfferings,
          requiredApprovalTypes: meeting.config.requiredApprovalTypes,
          reportEditAllowableHours: meeting.config.reportEditAllowableHours,
          reportingType: meeting.config.reportingType,
          isAccessibleToAll: meeting.config.isAccessibleToAll
        }
      });
  }

  public loadSelectedMeetingConfig(meeting: Lookup) {
    this.selectedMeeting = meeting;
    this.api
      .getAll(ApiRoutes.meetings.get_meeting_with_config + "/" + meeting.id)
      .subscribe(
        (response: MeetingSetup) => {
          this.patchConfigForm(response);
        },
        error => {
          this.formGroup.reset();
        }
      );
  }

  private updateMeetingDetails(meeting: Lookup) {
    this.sweetAlertService.showConfirmUpdate("Confirm Action").then(value => {
      if (value.value)
        this.api
          .patch(ApiRoutes.meetings.meetings, meeting.id, meeting)
          .subscribe((response: ResponseModel) => {
            meeting.id = response.data.id;
            meeting.isInEditMode = false;
            this.sweetAlertService.showSuccess(response.message);
          });
    });
  }

  private createNewMeeting(meeting: Lookup) {
    this.sweetAlertService.showConfirmUpdate("Confirm Action").then(value => {
      if (value.value)
        this.api
          .post(ApiRoutes.meetings.meetings, meeting)
          .subscribe((response: ResponseModel) => {
            meeting.id = response.data.id;
            meeting.isInEditMode = false;
            this.sweetAlertService.showSuccess(response.message);
          });
    });
  }

  public saveDetailsChanges(meeting: Lookup) {
    if (meeting.id == 0) {
      this.createNewMeeting(meeting);
    } else {
      this.updateMeetingDetails(meeting);
    }
  }

  public saveMeetingWithConfig() {
    const config = Object.assign({}, this.formGroup.value);
    this.sweetAlertService.showConfirmUpdate("Confirm Action").then(value => {
      if (value.value)
        this.api
          .put(ApiRoutes.meetings.meetings, this.selectedMeeting.id, config)
          .subscribe((response: ResponseModel) => {
            this.sweetAlertService.showSuccess(response.message);
          });
    });
  }

  public deleteItem(meeting: Lookup) {
    this.sweetAlertService.showConfirmUpdate("Confirm Action").then(value => {
      if (value.value)
        this.api
          .delete(ApiRoutes.meetings.meetings, meeting.id)
          .subscribe((response: ResponseModel) => {
            const index = this.meetings.indexOf(meeting);
            this.meetings.slice(index, 0);
            this.sweetAlertService.showSuccess(response.message);
          });
    });
  }

  public addItem() {
    const lookup = { id: 0, name: "", description: "", isInEditMode: true };
    this.meetings.unshift(lookup);
  }
}
