import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "../../services/guards/auth-guard.service";
import { ApprovalForCombinedMeetingsComponent } from "./approval-for-combined-meetings/approval-for-combined-meetings.component";
import { ReportsMenuComponent } from "./reports-menu/reports-menu.component";
import { ViewSubmittedReportsComponent } from "./view-submitted-reports/view-submitted-reports.component";
import { ReportsAnalysisForAttendanceComponent } from "./analysis-and-summary/reports-analysis-for-attendance/reports-analysis-for-attendance.component";
import { AttendanceReportComponent } from "./attendance-report/attendance-report.component";
import { MultipleParticipationsReportComponent } from "./multiple-participations-report/multiple-participations-report.component";
import { SingleParticipationReportComponent } from "./single-participation-report/single-participation-report.component";
import { ReportsAnalysisForMultipleParticipationsComponent } from "./analysis-and-summary/reports-analysis-for-multiple-participations/reports-analysis-for-multiple-participations.component";
import { ReportsAnalysisOnFinancialInflowComponent } from "./analysis-and-summary/reports-analysis-on-financial-inflow/reports-analysis-on-financial-inflow.component";
import { DelegatedAttendanceReportComponent } from "./delegated-attendance-report/delegated-attendance-report.component";

const routes: Routes = [
  {
    path: "menu/:actionType",
    component: ReportsMenuComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "attendance",
    component: AttendanceReportComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "delegated-attendance-report",
    component: DelegatedAttendanceReportComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "multiple-participations",
    component: MultipleParticipationsReportComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "single-participation",
    component: SingleParticipationReportComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "analysis/financial",
    component: ReportsAnalysisOnFinancialInflowComponent,
    data: {
      title: "Financial"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "approval-for-combined-meetings",
    component: ApprovalForCombinedMeetingsComponent,
    data: {
      title: "Approval For Combined Meetings"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "view-submitted-reports/:id",
    component: ViewSubmittedReportsComponent,
    data: {
      title: "View Submitted Report"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "reports-analysis-for-multiple-participations/:id",
    component: ReportsAnalysisForMultipleParticipationsComponent,
    data: {
      title: "Reports Analysis for Participants"
    }
    // canActivate: [AuthGuard]
  },
  /*{
    path: "reports-analysis-for-single-participation/:id",
    component: ReportsAnalysisForSingleParticipationComponent,
    data: {
      title: "Reports Analysis for Participants"
    }
    // canActivate: [AuthGuard]
  },*/
  {
    path: "reports-analysis-for-attendance/:id",
    component: ReportsAnalysisForAttendanceComponent,
    data: {
      title: "Reports Analysis for Attendance"
    }
    // canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportingRoutingModule {}
