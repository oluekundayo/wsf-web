import { finalize } from "rxjs/operators";
import { Component, OnInit, OnDestroy } from "@angular/core";

import {
  FormGroup,
  Validators,
  FormControl,
  FormBuilder,
  Form
} from "@angular/forms";

//import * as _ from "lodash";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { ExcelService } from "../../../services/utils/excel.service";
import { Observable, SubscriptionLike as ISubscription } from "rxjs";
import {
  CenterDataFromExcel,
  CenterSearchResult,
  Center,
  PositionHolder,
  CenterType
} from "../../../models/centers.models";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import {
  Lookup,
  ResponseModel,
  ApiUrlParam
} from "../../../models/utilities.models";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { FindACenterDialogComponent } from "../../dialog/find-a-center-dialog/find-a-center-dialog.component";
import { filter, some, isEmpty } from "lodash";
import { UtilitiesService } from "../../../services/utils/utilities.service";

@Component({
  selector: "app-register-existing-centers",
  templateUrl: "./register-existing-centers.component.html",
  styleUrls: ["./register-existing-centers.component.css"]
})
export class RegisterExistingCentersComponent implements OnInit {
  loading = false;
  pageTitle: string;
  centerTypes: CenterType[];
  centerStartDate: Date;
  //churchSystems$: Observable<Lookup[]>;
  //selectedChurchSystemsIds: number[];
  selectedCenterType: CenterType;
  positionLevelsOfSelectedCenterType: Lookup[] = [];
  excelServiceSubscriptions: ISubscription[] = [];
  centersDataExcelKeys: any;
  selectedPositionLevelId: number;
  centersData: CenterDataFromExcel[];
  bsModalRef: BsModalRef;
  parentCenter: CenterSearchResult;
  sheetNamesInSelectedExcelFile: string[] = [];
  selectedSheetName: string = "";
  excelFileEvent$: any;
  pickParentIdFromExcel: boolean = false;
  selectedActiveStatus: string = "";
  pagingCurrentPage: number = 1;
  pagingItemsPerPage: number = 20;
  searchFilter: string = "";

  constructor(
    private api: APIService,
    private excelService: ExcelService,
    private formBuilder: FormBuilder,
    private modalService: BsModalService,
    private sweetAlertService: SweetAlertService,
    private utilitiesService: UtilitiesService
  ) {
    this.pageTitle = "Register Existing Centers";

    // sheetname, parentcenter id
    // chruch systems
    //
  }

  ngOnInit() {
    //this.loadChurchSystems();
    this.loadCenterTypes();

    this.centersDataExcelKeys = [
      { field: "CenterNumber", label: "Number" },
      { field: "CenterAddress", label: "Address" },
      {
        field: "CenterShortNameFromAddress",
        label: "Short Address"
      },
      /*{
        field: "Center_type",
        label: "Church Systems"
      },
      {
        field: "ChurchSystemsTags",
        label: "Church Systems"
      },*/
      { field: "MinisterPrefix", label: "Prefix" },
      { field: "MinisterLastname", label: "Lastname" },
      { field: "MinisterFirstname", label: "Firstname" },
      { field: "MinisterOthername", label: "Othername" },
      { field: "MinisterPhone", label: "Phone" },
      { field: "MinisterEmail", label: "Email" },
      { field: "MinisterSex", label: "Sex" },
      { field: "MinisterAddress", label: "Address" }
    ];
  }

  /* ... (within the component class definition) ... */
  public onFileChange(evt: any) {
    /* wire up file reader */
    const target: DataTransfer = <DataTransfer>evt.target;

    if (target.files.length !== 1) {
      //throw new Error("Cannot use multiple files");
      alert("Cannot use multiple files");
      try {
        evt.srcElement.value = null;
        evt = null;
      } catch (e) {}

      return;
    }

    this.excelFileEvent$ = target;

    const sub = this.excelService.GetAllSheetNames(target).subscribe(names => {
      this.sheetNamesInSelectedExcelFile = names;
      //console.log(this.centersData);
      // Clear the input
    });

    this.excelServiceSubscriptions.push(sub);
  }

  public onsheetNamesInSelectedExcelFileChange() {
    //console.log(this.selectedSheetName);

    this.loadSelectedExcelSheet(this.selectedSheetName);
  }

  private loadSelectedExcelSheet(sheetName: string) {
    const sub = this.excelService
      .ReadExcelFile(this.excelFileEvent$, sheetName)
      .subscribe(data => {
        this.centersData = data;
        //console.log(this.centersData);
        // Clear the input
        try {
          this.excelFileEvent$.srcElement.value = null;
          this.excelFileEvent$ = null;
        } catch (e) {}
      });

    this.excelServiceSubscriptions.push(sub);
  }

  private loadCenterTypes() {
    this.loading = true;
    this.api
      .getAll<CenterType[]>(ApiRoutes.centers.get_assigned_centers_types)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        // console.log(response);
        this.centerTypes = response;
      });
  }

  /*private loadChurchSystems() {
    this.loading = true;
    this.churchSystems$ = this.api
      .getAll<Lookup[]>(
        ApiRoutes.church_setups.church_operational_systems_lookup
      )
      .pipe(finalize(() => (this.loading = false)));
  }
    */

  public onSelectCenterType() {
    this.selectedPositionLevelId = null;

    if (this.selectedCenterType && this.selectedCenterType.id) {
      const params: ApiUrlParam[] = [
        { name: "centerTypeId", value: this.selectedCenterType.id }
      ];

      this.loading = true;
      this.api
        .getAll<Lookup[]>(
          ApiRoutes.position_levels
            .get_assigned_position_levels_to_a_center_type,
          //+ "/" + this.selectedCenterType.id
          params
        )
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          this.positionLevelsOfSelectedCenterType = response;
        });
    }
  }

  public removeCenterFromList(center: CenterDataFromExcel) {
    const index = this.centersData.indexOf(center, 0);
    if (index > -1) {
      this.centersData.splice(index, 1);
    }
    // this.centersData.splice(center);
  }

  public openModalToSelectParentCenter() {
    if (!this.selectedCenterType || !this.selectedCenterType.id) {
      alert("Please select the Center Type you want to Register.");
      return;
    }

    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      animated: true,
      initialState: {
        returnAncestorsCenterTypes: true,
        selectedCenterTypeId: this.selectedCenterType.id
      }
    };

    this.bsModalRef = this.modalService.show(
      FindACenterDialogComponent,
      config
    );
    this.bsModalRef.content.action.subscribe((value: CenterSearchResult) => {
      // console.log(value); // here you will get the value
      if (value) {
        this.parentCenter = value;
      }
    });
  }

  public registerExistingCenters() {
    const validate = this.validateBeforeSubmission();
    if (!validate.isOk) {
      this.sweetAlertService.showError(validate.error, true);
      return;
    }

    const centers: Center[] = [];
    let newCenter: Center;
    let positionHolder: PositionHolder;
    //console.log(this.centersData.some(v => v.CenterNumber));

    this.centersData.forEach(_center => {
      newCenter = new Center();
      positionHolder = new PositionHolder();
      positionHolder.address = this.trimString(_center.MinisterAddress);
      positionHolder.firstname = this.trimString(_center.MinisterFirstname);
      positionHolder.lastname = this.trimString(_center.MinisterLastname);
      positionHolder.fullname =
        positionHolder.lastname + " " + positionHolder.firstname;
      positionHolder.email = this.trimString(_center.MinisterEmail);
      positionHolder.phone = this.trimString(_center.MinisterPhone);
      positionHolder.prefix = this.trimString(_center.MinisterPrefix);
      positionHolder.isCentersContact = true;
      if (
        (_center.MinisterSex &&
          _center.MinisterSex.trim().toUpperCase() == "M") ||
        "MALE"
      ) {
        positionHolder.gender = "Male";
      } else if (
        (_center.MinisterSex &&
          _center.MinisterSex.trim().toUpperCase() == "F") ||
        "FEMALE"
      ) {
        positionHolder.gender = "Female";
      }

      positionHolder.maritalStatus = "";
      positionHolder.othername = this.trimString(_center.MinisterOthername);
      positionHolder.positionLevelId = this.selectedPositionLevelId;

      newCenter.address = this.trimString(_center.CenterAddress);
      newCenter.churchSystemsIds = null; //this.selectedChurchSystemsIds;
      newCenter.parentId = this.pickParentIdFromExcel
        ? _center.ParentCenterId
        : this.parentCenter.centerId;
      newCenter.centerTypeId = this.selectedCenterType.id;
      newCenter.number = _center.CenterNumber;
      newCenter.activeStatus = this.selectedActiveStatus;
      newCenter.addCenterUser = true;

      /* newCenter.centerStartDate = this.utilitiesService.createDateAsUTC(
        this.centerStartDate
      );*/

      newCenter.shortNameFromAddress = this.trimString(
        _center.CenterShortNameFromAddress
      );

      newCenter.useSystemCenterNumbering = this.pickParentIdFromExcel;
      newCenter.positionHolder = positionHolder;

      /*if (_center.Center_type) {
        newCenter.churchSystemsTags = _center.Center_type.split(",");
      } else */ 
      
      if (_center.ChurchSystemsTags) {
        newCenter.churchSystemsTags = _center.ChurchSystemsTags.split(",");
      } else {
        newCenter.churchSystemsTags = [];
      }

      //console.log(_center.Center_type);

      centers.push(newCenter);
    });

    this.sweetAlertService
      .showConfirm("These Centers will be Registered")
      .then(response => {
        if (response.value) {
          this.loading = true;
          this.api
            .post<ResponseModel>(
              ApiRoutes.centers.register_existing_centers,
              centers
            )
            .pipe(finalize(() => (this.loading = false)))
            .subscribe(response => {
              this.resetPage();
              this.sweetAlertService.showSuccess(response.message);
            });
          //console.log(response.value);
        }
      });
  }

  private trimString(_string: string): string {
    if (_string && typeof _string === "string") {
      return _string.trim();
    } else return "";
  }

  private resetPage() {
    this.centersData = [];
    this.selectedCenterType = null;
    //this.selectedChurchSystemsIds = [];
    this.selectedPositionLevelId = null;
    this.parentCenter = new CenterSearchResult();
    this.parentCenter.displayAddress = "";
    this.selectedSheetName = "";
    this.pickParentIdFromExcel = false;
  }

  public clearScreen() {
    this.resetPage();
    this.sheetNamesInSelectedExcelFile = [];
    this.excelFileEvent$ = null;
  }

  private validateBeforeSubmission(): ResponseModel {
    let error = new ResponseModel();
    error.isOk = true;
    error.error = "";

    if (!this.selectedCenterType || !this.selectedCenterType.id) {
      error.isOk = false;
      error.error += "Please select Center Type.<br/>";
    }

    if (!this.pickParentIdFromExcel) {
      if (!this.parentCenter || !this.parentCenter.centerId) {
        error.isOk = false;
        error.error += "Please select Parent Center.<br/>";
      }
    }

    if (!this.selectedPositionLevelId) {
      error.isOk = false;
      error.error += "Please select User Role.<br/>";
    }
    if (!this.selectedActiveStatus) {
      error.isOk = false;
      error.error += "Please select Centers' Active Status.<br/>";
    }

    /*if (!this.selectedChurchSystemsIds) {
      error.isOk = false;
      error.error += "Please select at least one Church System.<br/>";
    }*/

    /*const _findEmptyAddresses = filter(
      this.centersData,
      (center: CenterDataFromExcel) => {
        return (
          !center.CenterAddress ||
          !center.Center_type ||
          !(center.MinisterLastname + center.MinisterFirstname)
        );
      }
    );

      if (_findEmptyAddresses && _findEmptyAddresses.length > 0) {
      error.isOk = false;
      error.error +=
        "Center's Address, Church Services/Programs and Minister's Lastname or Firstname are required for each record.<br/>";
    }

    */

    const _findEmptyAddresses = filter(
      this.centersData,
      (center: CenterDataFromExcel) => {
        return !center.CenterAddress;
      }
    );

    if (_findEmptyAddresses && _findEmptyAddresses.length > 0) {
      error.isOk = false;
      error.error += "Center Address is required for each record.<br/>";
    }

    if (this.pickParentIdFromExcel) {
      const _findEmptyParentCenterId = filter(
        this.centersData,
        (center: CenterDataFromExcel) => {
          return !center.ParentCenterId;
        }
      );

      if (_findEmptyParentCenterId && _findEmptyParentCenterId.length > 0) {
        error.isOk = false;
        error.error += "Parent Center ID is required for each record.<br/>";
      }
    }

    return error;
  }

  ngOnDestroy(): void {
    try {
      this.excelServiceSubscriptions.forEach(sub => {
        sub.unsubscribe();
      });
    } catch (e) {}

    try {
      this.bsModalRef.content.action.unsubscribe();
    } catch (e) {}
  }

  /*
private getFormData(field) {
  return this.modalForm.get(field).value;
}

get description() {
  return this.modalForm.get("description");
}

get name() {
  return this.modalForm.get("name");
}
*/
}
