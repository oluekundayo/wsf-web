import { Component, OnInit, OnDestroy } from "@angular/core";
import { CenterType, PositionLevel } from "../../../models/centers.models";
import { Observable } from "rxjs";
import { finalize, filter, take } from "rxjs/operators";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { FormBuilder } from "@angular/forms";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import {
  AssignableResource,
  AssignableResourceGroup
} from "../../../models/resources.models";

import { groupBy, map, chain } from "lodash";
import { PrivilegesDialogComponent } from "../../dialog/privileges-dialog/privileges-dialog.component";
import { Meeting } from "../../../models/meetings.models";
import {
  AppResourceType,
  Lookup,
  ApprovalTypeList
} from "../../../models/utilities.models";
import { ResourcesSetupDialogComponent } from "../../dialog/resources-setup-dialog/resources-setup-dialog.component";
import {
  ChildActivationEnd,
  Router,
  ActivationStart,
  RouterState,
  RouterStateSnapshot
} from "@angular/router";

@Component({
  selector: "app-manage-privileges",
  templateUrl: "./manage-privileges.component.html",
  styleUrls: ["./manage-privileges.component.scss"]
})
export class ManagePrivilegesComponent implements OnInit, OnDestroy {
  //centerTypes$: Observable<CenterType[]>;
  //centerTypes: CenterType[];
  bsModalRef: BsModalRef;
  loading: boolean = false;
  assignableResourcesGroup: AssignableResourceGroup[];
  // allAssignablePositionLevels: PositionLevel[] = [];
  meetings: AssignableResource[] = [];
  approvals: AssignableResource[] = [];
  isSuperUser: boolean = false;

  allAccessPrivileges: { meetings: string[]; resources: string[] } = {
    meetings: [],
    resources: []
  };

  constructor(
    private router: Router,
    private api: APIService,
    private formBuilder: FormBuilder,
    private modalService: BsModalService,
    private sweetAlertService: SweetAlertService
  ) {
    const state: RouterState = router.routerState;
    const snapshot: RouterStateSnapshot = state.snapshot;
    //console.log(snapshot);
    if (snapshot.url == ApiRoutes.super_user.setup_access_privileges) {
      this.isSuperUser = true;
    }
  }

  ngOnInit() {
    //this.loadCenterTypes();

    if (this.isSuperUser) {
      this.loadAllResources();
    } else {
      this.loadActiveAssignableResources();
    }
    this.getAllAvailableAccessPrivileges();
  }

  private loadActiveAssignableResources() {
    this.loading = true;
    this.api
      .getAll<AssignableResource[]>(ApiRoutes.resources.assignable_resources)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        const group = chain(response)
          .groupBy(x => x.categoryName)
          .map((value, key) => ({ category: key, resources: value }))
          .value();
        //console.log(group);
        this.assignableResourcesGroup = group;
      });
  }

  private loadAllResources() {
    this.loading = true;
    this.api
      .getAll<AssignableResource[]>(ApiRoutes.resources.get_all_resources)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        const group = chain(response)
          .groupBy(x => x.categoryName)
          .map((value, key) => ({ category: key, resources: value }))
          .value();
        //console.log(group);
        this.assignableResourcesGroup = group;
      });
  }

  public getAllAvailableAccessPrivileges() {
    this.loading = true;
    this.api
      .getAll<{ meetings: string[]; resources: string[] }>(
        ApiRoutes.resources.resources_sharing_get_access_privileges
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.allAccessPrivileges = response;
      });
  }

  public onSelectMeetingsTab(ev?: any) {
    if (!this.meetings.length) {
      this.loading = true;
      this.api
        .getAll<AssignableResource[]>(
          ApiRoutes.resources.get_all_meetings_as_resources
        )
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          this.meetings = response;
        });
    }
  }

  public onSelectApprovalsTab() {
    if (!this.approvals.length) {
      this.loading = true;
      this.api
        .getAll<AssignableResource[]>(
          ApiRoutes.resources.get_all_approvals_list_as_resources
        )
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          this.approvals = response;
        });
    }
  }

  public openModalToAssignResourcePrivileges(resource: AssignableResource) {
    //console.log(resource);
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      initialState: {
        title: resource.name,
        selectedResourceId: resource.id,
        appResourceType: resource.resourceType,
        appApprovalType: resource.approvalType,
        // allAssignablePositionLevels: this.allAssignablePositionLevels,
        allAssignablePrivileges: this.allAccessPrivileges.resources
      }
    };

    this.bsModalRef = this.modalService.show(PrivilegesDialogComponent, config);
    this.bsModalRef.content.action.subscribe(value => {
      if (value) {
        resource.hasBeenAssignedToAnyId = true;
      }
    });
  }

  public openModalToAssignMeetingsPrivileges(resource: AssignableResource) {
    //console.log(resource);
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      initialState: {
        title: resource.name,
        selectedResourceId: resource.id,
        appResourceType: AppResourceType.Meeting,
        // allAssignablePositionLevels: this.allAssignablePositionLevels,
        allAssignablePrivileges: this.allAccessPrivileges.meetings
      }
    };

    this.bsModalRef = this.modalService.show(PrivilegesDialogComponent, config);
    this.bsModalRef.content.action.subscribe(value => {
      // console.log(value); // here you will get the value

      if (value) {
        resource.hasBeenAssignedToAnyId = true;
      }
    });
  }

  public openModalToAssignApprovalsPrivileges(resource: AssignableResource) {
    //console.log(resource);
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      initialState: {
        title: resource.name,
        selectedResourceId: resource.id,
        appApprovalType: resource.approvalType,
        appResourceType: AppResourceType.Approval,
        allAssignablePrivileges: ["CanApprove"]
      }
    };
    this.bsModalRef = this.modalService.show(PrivilegesDialogComponent, config);
    this.bsModalRef.content.action.subscribe(value => {
      // console.log(value); // here you will get the value
      if (value) {
        resource.hasBeenAssignedToAnyId = true;
      }
    });
  }

  ngOnDestroy(): void {
    try {
      this.bsModalRef.content.action.unsubscribe();
    } catch (e) {}
  }
}
