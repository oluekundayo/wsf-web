import { finalize } from "rxjs/operators";
import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy
} from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";

import { CenterMemberPostModel } from "../../../models/centers.models";
import { BsModalRef } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import {
  MeetingParticipantGetModel,
  MeetingReportToSubmit,
  MeetingParticipantRecordedAttendance,
  MeetingDashboardItem
} from "../../../models/reporting.models";
import { ResponseModel } from "../../../models/utilities.models";
import { ReportingService } from "../../../services/components-services/reporting.service";

@Component({
  selector: "app-mark-attendance-dialog",
  templateUrl: "./mark-attendance-dialog.component.html",
  styleUrls: ["./mark-attendance-dialog.component.scss"]
})
export class MarkAttendanceDialogComponent implements OnInit, OnDestroy {
  loading: boolean = false;
  attendee: MeetingParticipantGetModel;
  meeting: MeetingDashboardItem;
  meetingDate: Date;
  showPreviousAttendance: boolean = false;
  experiencedHolyGhostBaptism: boolean = false;
  allAttendanceRecorded: MeetingParticipantRecordedAttendance[] = [];

  @Output() action = new EventEmitter<MeetingParticipantGetModel>();

  constructor(
    private api: APIService,
    public bsModalRef: BsModalRef,
    private reportingService: ReportingService,
    private sweetAlertService: SweetAlertService
  ) {}

  ngOnInit() {
    this.reportingService
      .getAllAttendanceRecordedForAParticipant(
        this.meeting.id,
        this.attendee.centerMemberId
      )
      .subscribe(response => {
        this.allAttendanceRecorded = response;
      });
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
  }

  public markAttendance() {
    const report = new MeetingReportToSubmit();
    report.meetingId = this.meeting.id;
    report.meetingDate = this.meetingDate;
    this.attendee.isPresent = true;
    this.attendee.experiencedHolyGhostBaptism = this.experiencedHolyGhostBaptism;
    report.meetingParticipant = this.attendee;
    report.meetingReportType = this.meeting.meetingReportType;

    this.sweetAlertService
      .showConfirm(
        "New Attendance will be marked as being Present for this Meeting."
      )
      .then(a => {
        if (a.value) {
          this.loading = true;
          this.reportingService
            .submitParticipantsAttendanceReport(report)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              if (response.isOk) {
                // this.formGroup.reset();
                //this.resetForm();
                //console.log(response);
                this.sweetAlertService.showSuccess(
                  "Record saved successfully."
                );
                this.attendee = response.data;
                this.closeModal();
                //this.action.emit(response.data);
                //this.bsModalRef.hide();
              }
            });
        }
      });
  }

  public unmarkAttendance(index: number) {
    const attendance: MeetingParticipantRecordedAttendance = this
      .allAttendanceRecorded[index];

    this.sweetAlertService
      .showConfirm(
        "This Attendance will be unmarked as being Absent for this Meeting."
      )
      .then(a => {
        if (a.value) {
          this.loading = true;
          this.reportingService
            .deleteParticipantsAttendanceReport(attendance.id, this.attendee)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              if (response.isOk) {
                const data = response.data as MeetingParticipantGetModel;
                this.attendee.participationCount = data.participationCount;
                this.attendee.participationStatus = data.participationStatus;
                this.allAttendanceRecorded.splice(index, 1);
                // this.formGroup.reset();
                //this.resetForm();
                this.sweetAlertService.showSuccess(
                  "Record updated successfully."
                );
              }
            });
        }
      });
  }

  public closeModal() {
    this.action.emit(this.attendee);
    this.bsModalRef.hide();
  }

  ngOnDestroy(): void {}
}
