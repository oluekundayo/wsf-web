import { Component, OnInit, TemplateRef } from "@angular/core";
import { finalize } from "rxjs/operators";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { MeetingSetup, Meeting } from "../../../models/meetings.models";
import { ResponseModel, Lookup } from "../../../models/utilities.models";
import { CenterType, ChurchStructuralDivision } from "app/models/setups.models";

@Component({
  selector: "app-center-types-setup",
  templateUrl: "./center-types-setup.component.html",
  styleUrls: ["./center-types-setup.component.scss"]
})
export class CenterTypesSetupComponent implements OnInit {
  loading: boolean = false;
  formGroup: FormGroup;
  selectedCenterType: CenterType;
  centerTypes: CenterType[] = [];
  churchStructuralDivisions: Lookup[] = [];
  churchsystems: Lookup[];

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    private modalService: BsModalService,
    private sweetAlertService: SweetAlertService
  ) {
    this.createConfigForm();
  }

  ngOnInit() {
    this.loadCenterTypes();
    this.loadChurchSystems();
    this.loadChurchStructuralDivision();
  }

  private loadCenterTypes() {
    this.loading = true;
    this.api
      .getAll<CenterType[]>(ApiRoutes.church_setups.center_types)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.centerTypes = response;
      });
  }

  private loadChurchSystems() {
    this.loading = true;
    this.api
      .getAll<Lookup[]>(
        ApiRoutes.church_setups.church_operational_systems_lookup
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.churchsystems = response;
      });
  }

  private loadChurchStructuralDivision() {
    this.loading = true;
    this.api
      .getAll<Lookup[]>(ApiRoutes.church_setups.structural_divisions)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.churchStructuralDivisions = response;
      });
  }

  private createConfigForm() {
    this.formGroup = this.fb.group({
      id: [null],
      name: ["", Validators.required],
      description: [""],
      churchStructuralDivisionId: [null, Validators.required],
      churchSystemsIds: [0],
      defaultChurchSystemsIdsForAllCenters: [0, Validators.required],
      parentCenterTypeId: [0],
      orderBy: [0],
      centersNamePrefix: [""],
      centersAliasPrefix: [""],
      includeInFamilyTreeName: [false],
      maxAllowablePositionLevels: [0],
      showToFindCenterOnSignUp: [false],
      showCentersAsTransportationCentralLocation: [false],
      belongsToChurchRoot: [false],
      belongsToStructuralDivisionRoot: [false]
    });
  }

  private patchConfigForm(centerType: CenterType) {
    if (centerType == null) {
      this.formGroup.reset();
      return;
    }

    this.formGroup.patchValue({
      id: centerType.id,
      name: centerType.name,
      description: centerType.description,
      churchStructuralDivisionId: centerType.churchStructuralDivisionId,
      defaultChurchSystemsIdsForAllCenters:
        centerType.defaultChurchSystemsIdsForAllCenters,
      churchSystemsIds: centerType.churchSystemsIds,
      parentCenterTypeId: centerType.parentCenterTypeId,
      orderBy: centerType.orderBy,
      centersNamePrefix: centerType.centersNamePrefix,
      centersAliasPrefix: centerType.centersAliasPrefix,
      includeInFamilyTreeName: centerType.includeInFamilyTreeName,
      maxAllowablePositionLevels: centerType.maxAllowablePositionLevels,
      showToFindCenterOnSignUp: centerType.showToFindCenterOnSignUp,
      showCentersAsTransportationCentralLocation:
        centerType.showCentersAsTransportationCentralLocation,
      belongsToChurchRoot: centerType.belongsToChurchRoot,
      belongsToStructuralDivisionRoot:
        centerType.belongsToStructuralDivisionRoot
    });
  }

  private updateCenterType(centerType: CenterType) {
    const data = Object.assign({}, this.formGroup.value) as CenterType;

    this.sweetAlertService.showConfirmUpdate("Confirm Action").then(value => {
      if (value.value)
        this.api
          .put(ApiRoutes.church_setups.center_types, centerType.id, data)
          .subscribe((response: ResponseModel) => {
            centerType.id = response.data.id;
            this.sweetAlertService.showSuccess(response.message);
          });
    });
  }

  private createNewCenterType(centerType: CenterType) {
    const data = Object.assign({}, this.formGroup.value) as CenterType;
    this.sweetAlertService.showConfirmUpdate("Confirm Action").then(value => {
      if (value.value)
        this.api
          .post(ApiRoutes.church_setups.center_types, data)
          .subscribe((response: ResponseModel) => {
            centerType.id = response.data.id;
            this.centerTypes.unshift(centerType);
            this.sweetAlertService.showSuccess(response.message);
          });
    });
  }

  public saveDetailsChanges() {
    if (this.selectedCenterType.id == 0) {
      this.createNewCenterType(this.selectedCenterType);
    } else {
      this.updateCenterType(this.selectedCenterType);
    }
  }

  public deleteItem(centerType: CenterType) {
    this.sweetAlertService.showConfirmUpdate("Confirm Action").then(value => {
      if (value.value)
        this.api
          .delete(ApiRoutes.church_setups.center_types, centerType.id)
          .subscribe((response: ResponseModel) => {
            const index = this.centerTypes.indexOf(centerType);
            this.centerTypes.slice(index, 0);
            this.sweetAlertService.showSuccess(response.message);
          });
    });
  }

  public addItem() {
    this.createConfigForm();
  }

  public editItem(centerType: CenterType) {
    this.selectedCenterType = centerType;
    this.patchConfigForm(centerType);
  }
}
