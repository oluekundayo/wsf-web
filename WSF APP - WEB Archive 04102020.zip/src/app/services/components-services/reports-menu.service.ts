import { Injectable } from "@angular/core";
import { Subject, Observable, BehaviorSubject } from "rxjs";
import { MenuInfo } from "../../models/menu.models";
import { MeetingDashboardItem } from "../../models/reporting.models";

@Injectable({
  providedIn: "root"
})
export class ReportsMenuService {
  private subject = new BehaviorSubject<MeetingDashboardItem[]>([]);

  constructor() {}

  // submit

  public SetMeetingsMenu(menu: MeetingDashboardItem[]) {
    this.subject.next(menu);
  }

  public GetMeetingsMenu(): Observable<MeetingDashboardItem[]> {
    return this.subject.asObservable();
  }

  public HasValue(): boolean {
    return this.subject.value.length > 0;
  }

  public GetValue(): MeetingDashboardItem[] {
    return this.subject.value;
  }
}
