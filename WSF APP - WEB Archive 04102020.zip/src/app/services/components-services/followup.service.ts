import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { catchError, map, tap } from "rxjs/operators";

import { Observable, of } from "rxjs";
import { APIService } from "../api.service";
import {
  CenterMemberPostModel,
  CenterMemberGetModel
} from "../../models/centers.models";
import { ApiRoutes } from "../api.routes";
import {
  Lookup,
  ResponseModel,
  SimpleFilter,
  SmsRecipientOptions,
  CenterMemberConversionStatus
} from "../../models/utilities.models";
import { ReportFilter } from "../../models/reporting.models";
import {
  FollowUpDataSummary,
  ApprovedSmsSenderIds,
  SmsMessaging,
  SmsMessagingDraft,
  FollowUpDataSummaryPerCenter,
  TransportationLoadingHub,
  TransportationCentralLocation,
  TransportationLoadingPoint
} from "../../models/follow_up.models";
import { chain, includes, concat, filter, reduce } from "lodash";

@Injectable()
export class FollowUpService {
  constructor(private http: HttpClient, private apiService: APIService) {}

  saveNewConvert(body: CenterMemberPostModel) {
    return this.apiService.post<ResponseModel>(
      ApiRoutes.follow_up.new_converts_and_first_timers,
      body
    );
  }

  getNewConverts(filter: ReportFilter): Observable<CenterMemberGetModel[]> {
    return this.apiService.find<CenterMemberGetModel[]>(
      ApiRoutes.follow_up.new_converts_and_first_timers,
      filter
    );
  }

  getFollowUpDataSummary(
    filter: ReportFilter
  ): Observable<FollowUpDataSummary> {
    return this.apiService.find<FollowUpDataSummary>(
      ApiRoutes.follow_up.get_follow_up_data_summary,
      filter
    );
  }

  getFollowUpDataSummaryPerCenter(
    filter: ReportFilter
  ): Observable<FollowUpDataSummaryPerCenter[]> {
    return this.apiService.find<FollowUpDataSummaryPerCenter[]>(
      ApiRoutes.follow_up.get_follow_up_data_summary_per_center,
      filter
    );
  }

  getSmsDrafts(): Observable<SmsMessagingDraft[]> {
    return this.apiService.getAll<SmsMessagingDraft[]>(
      ApiRoutes.sms.get_sms_drafts
    );
  }

  getApprovedSenderIds(): Observable<ApprovedSmsSenderIds> {
    return this.apiService.getAll<ApprovedSmsSenderIds>(
      ApiRoutes.sms.get_approved_sms_sender_ids
    );
  }

  saveSmsDrafts(message: SmsMessagingDraft): Observable<ResponseModel> {
    return this.apiService.post<ResponseModel>(
      ApiRoutes.sms.save_sms_draft,
      message
    );
  }

  deleteSmsDraft(id: number): Observable<ResponseModel> {
    return this.apiService.delete<ResponseModel>(
      ApiRoutes.sms.delete_sms_drafts,
      id
    );
  }

  sendMessage(message: SmsMessaging): Observable<ResponseModel> {
    return this.apiService.post<ResponseModel>(ApiRoutes.sms.send_sms, message);
  }

  /*findNewConverts(filter: ReportFilter): Observable<CenterMemberGetModel[]> {
    return this.apiService.find<CenterMemberGetModel[]>(
      ApiRoutes.follow_up.find_new_converts_and_first_timers,
      filter
    );
  }*/

  getAssignedMeetingsToSubmit(): Observable<Lookup[]> {
    return this.apiService.getAll<Lookup[]>(
      ApiRoutes.resources.resources_sharing_get_assigned_meetings +
        "/CanSubmit" +
        "/false"
    );
  }

  getAssignedMeetingsToView(): Observable<Lookup[]> {
    return this.apiService.getAll<Lookup[]>(
      ApiRoutes.resources.resources_sharing_get_assigned_meetings +
        "/CanView" +
        "/false"
    );
  }

  filterCenterMembers = (
    smsRecipientOptionsKey: string,
    members: CenterMemberGetModel[]
  ): Observable<CenterMemberGetModel[]> => {
    if (!smsRecipientOptionsKey || !members || !members.length) {
      return of([] as CenterMemberGetModel[]);
    }

    if (smsRecipientOptionsKey == SmsRecipientOptions.All) {
      return of(members);
    }

    const ff = chain(members)
      .filter((e: CenterMemberGetModel) => {
        if (smsRecipientOptionsKey == SmsRecipientOptions.Selected) {
          return e.isSelected;
        } else if (smsRecipientOptionsKey == SmsRecipientOptions.FirstTimers) {
          return (
            e.memberConversionStatus == CenterMemberConversionStatus.FirstTimer
          );
        } else if (smsRecipientOptionsKey == SmsRecipientOptions.NewBirths) {
          return (
            e.memberConversionStatus == CenterMemberConversionStatus.NewConvert
          );
        } else if (
          smsRecipientOptionsKey == SmsRecipientOptions.HolyGhostBaptism
        ) {
          return e.experiencedHolyGhostBaptism;
        } else {
          return false;
        }
      })
      .value();

    return of(ff);
  };

  searchCenterMemebers = (
    query: string,
    members: CenterMemberGetModel[]
  ): Observable<CenterMemberGetModel[]> => {
    if (query && members && members.length) {
      const ff = filter(members, (e: CenterMemberGetModel) => {
        //console.log(e);
        return includes(e.fullName.toLowerCase(), query.toLowerCase());
      });
      return of(ff);
    } else {
      return of([] as CenterMemberGetModel[]);
    }
  };

  getCentralLocations(
    includeLoadingHubs: boolean = false
  ): Observable<TransportationCentralLocation[]> {
    return this.apiService.getAll<TransportationCentralLocation[]>(
      ApiRoutes.transportation.get_central_locations + "/" + includeLoadingHubs
    );
  }

  getLoadingHubsWithoutPoints(): Observable<TransportationLoadingHub[]> {
    return this.apiService.getAll<TransportationLoadingHub[]>(
      ApiRoutes.transportation.get_loading_hubs
    );
  }

  getLoadingPointsInAHub(
    hubId: number
  ): Observable<TransportationLoadingPoint[]> {
    return this.apiService.get<TransportationLoadingPoint[]>(
      ApiRoutes.transportation.get_loading_points_in_a_hub,
      hubId
    );
  }

  getLoadingPointsInALocation(
    centralLocationId: number = 0
  ): Observable<TransportationLoadingPoint[]> {
    return this.apiService.get<TransportationLoadingPoint[]>(
      ApiRoutes.transportation.get_loading_points_in_a_central_location,
      centralLocationId
    );
  }

  getLoadingHubsWithPoints(
    centralLocationId: number
  ): Observable<TransportationLoadingHub[]> {
    return this.apiService.get<TransportationLoadingHub[]>(
      ApiRoutes.transportation.get_loading_hubs +
        "/" +
        centralLocationId +
        "/" +
        true,
      centralLocationId
    );
  }

  saveLoadingBays(
    hub: TransportationLoadingHub
  ): Observable<TransportationLoadingHub> {
    return this.apiService.post<TransportationLoadingHub>(
      ApiRoutes.transportation.transportation,
      hub
    );
  }
}
