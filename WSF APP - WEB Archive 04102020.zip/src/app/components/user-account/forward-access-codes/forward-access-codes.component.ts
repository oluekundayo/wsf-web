import { finalize } from "rxjs/operators";
import { Component, OnInit, OnDestroy } from "@angular/core";

import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Lookup, ResponseModel } from "../../../models/utilities.models";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { Observable } from "rxjs";
import { AccessCodeList } from "../../../models/user_account.models";
import { CenterType, PositionLevel } from "../../../models/centers.models";

@Component({
  selector: "app-forward-access-codes",
  templateUrl: "./forward-access-codes.component.html",
  styleUrls: ["./forward-access-codes.component.scss"]
})
export class ForwardAccessCodesComponent implements OnInit {
  loading = false;
  pageTitle: string;
  centerTypes: CenterType[] = [];
  //accessCodes$: Observable<AccessCodeList[]>;
  accessCodes: AccessCodeList[] = [];
  //selectedChurchSystemsIds: number[] = [];
  //selectedCenterType: CenterType;
  selectedPositionLevelId: number;
  positionLevels: PositionLevel[] = [];

  constructor(
    private api: APIService,
    private sweetAlertService: SweetAlertService
  ) {}

  ngOnInit() {
    this.getPositionLevelsAssignedToManage();
  }

  private getPositionLevelsAssignedToManage() {
    this.loading = true;
    this.api
      .getAll<PositionLevel[]>(
        ApiRoutes.position_levels.get_assigned_position_levels_to_manage
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.positionLevels = response;
        //console.log(response);
      });
  }

  public onChangePositionLevel() {
    //console.log(this.selectedPositionLevelId);

    this.loadAccessCodes();
  }

  public loadAccessCodes() {
    this.loading = true;
    /*
    this.accessCodes$ = this.api
      .getAll<AccessCodeList[]>(
        ApiRoutes.user_account.get_access_codes + "/" + positionLevelId
      )
      .pipe(finalize(() => (this.loading = false)));
      */

    this.api
      .getAll<AccessCodeList[]>(
        ApiRoutes.user_account.get_access_codes +
          "/" +
          this.selectedPositionLevelId
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.accessCodes = response;
      });
  }

  public forwardAccessCode(code: AccessCodeList) {}

  ngOnDestroy(): void {}
}
