import { finalize } from "rxjs/operators";
import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy,
  ViewChild
} from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import {
  Lookup,
  ApiUrlParam,
  ResponseModel,
  ReadOnlyItemsGroup
} from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Center, CenterProfile } from "../../../models/centers.models";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { TabsetComponent, TabDirective } from "ngx-bootstrap/tabs";
import { UserProfile } from "../../../models/user_account.models";
import { UserAccountService } from "../../../services/components-services/user-account.service";

@Component({
  selector: "app-my-center",
  templateUrl: "./my-center.component.html",
  styleUrls: ["./my-center.component.scss"]
})
export class MyCenterComponent implements OnInit, OnDestroy {
  loading = false;
  formGroup: FormGroup;
  prefixList: string[] = [];
  myCenterProfile: CenterProfile;
  isInEditMode: boolean = false;

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    private userAccountService: UserAccountService,
    private sweetAlertService: SweetAlertService
  ) {}
  ngOnInit() {
    this.prefixList = ["Pastor", "Elder", "Dcn.", "Dcns.", "Bro.", "Sis."];
    this.createForm();
    this.loadProfile();
  }

  public loadProfile() {
    this.loading = true;
    this.userAccountService
      .getCenterProfile()
      //.pipe(finalize(() => (this.loading = false)))
      .subscribe(
        (response: CenterProfile) => {
          if (response) {
            this.myCenterProfile = response;
            //console.log(response);
            this.patchForm();
          }
          this.loading = false;
        },
        error => {
          this.loading = false;
        }
      );
  }

  private createForm() {
    this.formGroup = this.fb.group({
      centerAddress: ["", Validators.required],
      centeShortAddress: [""],
      contactLastname: ["", Validators.required],
      contactFirstname: ["", Validators.required],
      contactEmail: [""],
      contactPhone: [""],
      contactPrefix: [""],
      contactAddress: [""],
      contactGender: [""]
    });
  }

  private patchForm() {
    this.formGroup.patchValue({
      centerAddress: this.myCenterProfile.centerAddress,
      centeShortAddress: this.myCenterProfile.centeShortAddress,
      contactLastname: this.myCenterProfile.contactLastname,
      contactFirstname: this.myCenterProfile.contactFirstname,
      contactEmail: this.myCenterProfile.contactEmail,
      contactPhone: this.myCenterProfile.contactPhone,
      contactPrefix: this.myCenterProfile.contactPrefix,
      contactAddress: this.myCenterProfile.centerAddress,
      contactGender: this.myCenterProfile.contactGender
    });
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
  }

  updateProfile() {
    if (this.formGroup.valid) {
      this.sweetAlertService
        .showConfirm("Your Center's Profile will be updated.")
        .then(a => {
          if (a.value) {
            this.loading = true;
            this.userAccountService
              .updateCenterProfile(this.formGroup.value)
              .pipe(finalize(() => (this.loading = false)))
              .subscribe((response: ResponseModel) => {
                if (response.isOk) {
                  this.myCenterProfile = Object.assign(
                    {},
                    this.formGroup.value
                  );
                  //console.log(response);
                  this.isInEditMode = false;
                  this.sweetAlertService.showSuccess(
                    "Your Center's Profile has been updated successfully"
                  );
                }
              });
          }
        });
    }
  }

  public toggleEditMode() {
    this.isInEditMode = !this.isInEditMode;
    this.patchForm();
  }

  ngOnDestroy(): void {}
}
