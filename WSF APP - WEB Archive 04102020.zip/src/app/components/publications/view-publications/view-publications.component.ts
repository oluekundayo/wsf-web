import {
  Component,
  OnInit,
  Input,
  OnDestroy,
  AfterViewInit
} from "@angular/core";
import { PublicationService } from "../../../services/components-services/publications.service";
import {
  finalize,
  debounceTime,
  distinctUntilChanged,
  tap,
  switchMap,
  catchError,
  filter,
  findIndex
} from "rxjs/operators";
import {
  Publication,
  PaginatedPublications,
  PublicationPageType,
  PublicationTimeline,
  PublicationAttachment
} from "../../../models/publications.models";
import {
  PaginatorFilter,
  Lookup,
  DataCacheMode,
  PageDirection,
  ResponseModel,
  PageFilterDescription,
  BookmarkPost,
  SimpleFilter,
  SimpleFilterHolderWithDescription
} from "../../../models/utilities.models";
import { Router } from "@angular/router";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Observable, Subject, of, concat } from "rxjs";
import { UtilitiesService } from "../../../services/utils/utilities.service";
import { find, map } from "lodash";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
@Component({
  selector: "app-view-publication",
  templateUrl: "./view-publications.component.html",
  styleUrls: ["./view-publications.component.scss"]
})
export class ViewPublications implements OnInit, OnDestroy, AfterViewInit {
  loading: boolean = false;
  //searchResults$: Observable<Publication[]>;
  //searchQuery$ = new Subject<string>();
  //selectedSearchItemIdKey: string;
  //isSearchLoading: boolean = false;
  pageListMode: DataCacheMode = DataCacheMode.Approved;
  cachedPageListModeBeforeSearch: DataCacheMode = DataCacheMode.Approved;
  publicationsTimelines: PublicationTimeline[] = [];
  bookmarkedPublications: Publication[] = [];
  searchedPublications: Publication[] = [];
  cachedTimelinePaginator: PaginatorFilter;
  cachedBookmarkedPaginator: PaginatorFilter;
  currentPageTitle: string = "All Publications";

  PAGINATOR_PAGE_SIZE: number = 20;
  //selectedPublicationId: number = 0;
  hasSelectedPublicationBeenBookmarked: boolean = false;
  //scrollPosition: [number, number];
  selectedPublicationDetails: Publication = new Publication();
  public bsModalRef: BsModalRef;
  //showLimitSection: boolean = false;
  public publicationsCategories: Lookup[] = [];
  //simpleFilterHolder: SimpleFilterHolderWithDescription;
  simpleFilterDescription: PageFilterDescription;
  currentYear: number = new Date().getFullYear();

  constructor(
    private publicationService: PublicationService,
    //private dataCache: DataCachePublicationsService,
    //private pagerService: PagerService,
    private utilitiesService: UtilitiesService,
    private modalService: BsModalService,
    private sweetAlertService: SweetAlertService,
    //private fb: FormBuilder,
    private router: Router // private loc: Location, //public bsModalRef: BsModalRef // private viewportScroller: ViewportScroller //private fetcher: ListFetcher
  ) {
    this.initPaginators();

    /*if (!this.simpleFilterHolder) {
      this.simpleFilterHolder = new SimpleFilterHolderWithDescription();
    }

    if (!this.simpleFilterHolder.description) {
      this.simpleFilterHolder.description = new PageFilterDescription();
    }*/
  }

  ngOnInit() {
    //this.pageListMode = this.dataCache.getLastSelectedPageMode();
    //this.changePageMode(this.pageListMode);
    this.loadNextItems(true);

    //this.initSearch();
  }

  private initPaginators() {
    //this.currentFilterDescription.hasFilterRunning = false;

    this.cachedTimelinePaginator = new PaginatorFilter();
    this.cachedTimelinePaginator.direction = PageDirection.NEXT;
    this.cachedTimelinePaginator.lastMaxId = 0;
    this.cachedTimelinePaginator.totalItemsCount = 0;
    this.cachedTimelinePaginator.currentPageStart = 0;
    this.cachedTimelinePaginator.currentPageEnd = 0;
    this.cachedTimelinePaginator.limitToBookmarks = false;

    this.cachedBookmarkedPaginator = new PaginatorFilter();
    this.cachedBookmarkedPaginator.pageSize = this.PAGINATOR_PAGE_SIZE;
    this.cachedBookmarkedPaginator.direction = PageDirection.NEXT;
    this.cachedBookmarkedPaginator.lastMaxId = 0;
    this.cachedBookmarkedPaginator.totalItemsCount = 0;
    this.cachedBookmarkedPaginator.currentPageStart = 0;
    this.cachedBookmarkedPaginator.currentPageEnd = 0;
    this.cachedTimelinePaginator.limitToBookmarks = true;

    this.changePageMode(this.pageListMode);
  }

  ngAfterViewInit() {
    this.getPublicationsCategories();
    //console.log(this.scrollPosition);
    //this.viewportScroller.scrollToPosition(this.scrollPosition);
  }

  loadNextItems(
    isInitLoad: boolean = false
    //cachedPublicationsInstance: Publication[],
    //paginator: PaginatorFilter
  ) {
    // connect to api on first page to update data

    this.loading = true;
    if (isInitLoad) {
      this.cachedTimelinePaginator.direction = PageDirection.CURRENT;
      this.publicationService.injectPaginatorDatesRange(
        this.cachedTimelinePaginator
      );
    } else {
      this.cachedTimelinePaginator.direction = PageDirection.NEXT;
      this.publicationService.injectPaginatorDatesRange(
        this.cachedTimelinePaginator
      );
    }

    this.publicationService
      .getPublicationsTimeline(this.cachedTimelinePaginator)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        // console.log(response);
        this.publicationsTimelines = response;
      });
  }

  loadPreviousItems() //cachedPublicationsInstance: Publication[],
  //paginator: PaginatorFilter
  {
    // connect to api on first page to update data
    this.loading = true;
    this.cachedTimelinePaginator.direction = PageDirection.PREVIOUS;
    this.publicationService.injectPaginatorDatesRange(
      this.cachedTimelinePaginator
    );
    this.publicationService
      .getPublicationsTimeline(this.cachedTimelinePaginator)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.publicationsTimelines = response;
      });
  }

  loadMoreBookmarkedItems() {
    // connect to api on first page to update data
    this.loading = true;
    this.publicationService
      .getAllBookmarkedPublications(this.cachedBookmarkedPaginator)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        // console.log(response);
        response.publications.forEach(element => {
          try {
            element.publicationCategoryName = (find(
              this.publicationsCategories,
              e => {
                return (e.id = element.publicationCategoryId);
              }
            ) as Lookup).name;
          } catch (e) {}
        });

        this.cachedBookmarkedPaginator = response.paginator;
        this.bookmarkedPublications = response.publications;
      });
  }

  public changePageMode(pageMode: string) {
    if (pageMode == DataCacheMode.Approved) {
      this.pageListMode = DataCacheMode.Approved;
      this.currentPageTitle = "All Publications";
      this.cachedTimelinePaginator.limitToBookmarks = false;
      if (!this.publicationsTimelines.length) {
        this.loadNextItems(true);
      }
    } else if (pageMode == DataCacheMode.Bookmarked) {
      this.pageListMode = DataCacheMode.Bookmarked;
      this.currentPageTitle = "Starred Publications";
      this.cachedBookmarkedPaginator.limitToBookmarks = true;
      if (!this.bookmarkedPublications.length) {
        this.loadMoreBookmarkedItems();
      }
    }
  }

  /*private initSearch() {
    this.searchResults$ = concat(
      of([] as Publication[]), // default items
      this.searchQuery$.pipe(
        debounceTime(200),
        distinctUntilChanged(),
        tap(() => (this.isSearchLoading = true)),
        switchMap(term =>
          this.publicationService
            .searchPublications(term, this.publicationsTimelines)
            .pipe(
              catchError(() => of([] as Publication[])), // empty list on error
              tap(() => (this.isSearchLoading = false))
            )
        )
      )
    );
  }*/

  private getPublicationsCategories() {
    this.publicationService
      .getPublicationCategories()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        /*  this.publicationsCategories.push({
          name: "All",
          description: "All Categories",
          id: 0
        });*/
        this.publicationsCategories.push(...response);
      });
  }

  trackerFn(index, item) {
    //do what ever logic you need to come up with the unique identifier of your item in loop, I will just return the object id.
    return index;
  }

  public getPublicationsTimelineItems(timeline: PublicationTimeline) {
    if (!timeline.publications || !timeline.publications.length) {
      this.loading = true;
      this.publicationService
        .getPublicationsTimelineItems(timeline)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          //console.log(response);
          response.forEach(element => {
            try {
              element.publicationCategoryName = (find(
                this.publicationsCategories,
                e => {
                  return (e.id = element.publicationCategoryId);
                }
              ) as Lookup).name;
            } catch (e) {}
          });
          timeline.publications = response;
        });
    }
  }

  navigateToDetails(
    pub: Publication,
    template: any,
    isBookmarkItem: boolean = false
  ) {
    if (pub) {
      this.loading = true;
      this.publicationService
        .getPublicationDetail(pub.idKey)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(publication => {
          this.selectedPublicationDetails = publication;
          this.selectedPublicationDetails.publicationCategoryName =
            pub.publicationCategoryName;
          this.selectedPublicationDetails.hasBeenBookmarked =
            pub.hasBeenBookmarked;

          //console.log(publication);
          this.bsModalRef = this.modalService.show(template, {
            ignoreBackdropClick: true,
            class: "modal-lg"
          });
        });
    }
  }

  public downloadAttachment(attachment: PublicationAttachment) {
    this.loading = true;
    this.publicationService
      .downloadAttachment(attachment.fileName, attachment.fileMimeType)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(blob => {
        /*console.log(blob);

        //var blob = new Blob([blob], { type: attachment.fileMimeType });
        var filename = "file.pdf";
        saveAs(blob, filename);

        //console.log(blob);
        //saveAs(blob, attachment.fileName); //attachment.fileName

        //var urlCreator = window.URL;
        //return this._sanitizer.bypassSecurityTrustUrl(
        //  urlCreator.createObjectURL(blob)
        // );*/

        //console.log(blob);
        var newBlob = new Blob([blob], { type: attachment.fileMimeType });
        //saveAs(blob, attachment.fileName);

        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(newBlob, attachment.fileName);
        } else {
          // For other browsers:
          // Create a link pointing to the ObjectURL containing the blob.
          const href = window.URL.createObjectURL(newBlob);

          var link = document.createElement("a");
          link.href = href;
          link.download = attachment.fileName;
          try {
            document.getElementById("domReferenceToModal").appendChild(link);
          } catch (e) {}
          // this is necessary as link.click() does not work on the latest firefox
          link.dispatchEvent(
            new MouseEvent("click", {
              bubbles: true,
              cancelable: true,
              view: window
            })
          );

          setTimeout(function() {
            // For Firefox it is necessary to delay revoking the ObjectURL
            try {
              document.getElementById("domReferenceToModal").removeChild(link);
              // document.removeChild(link);
            } catch (e) {
              console.error(e);
            }
            try {
              window.URL.revokeObjectURL(href);
            } catch (e) {}
          }, 100);
        }
      });
  }

  public bookmarkItem() {
    this.loading = true;
    const bookmark = new BookmarkPost();
    bookmark.itemIdKey = this.selectedPublicationDetails.idKey;
    bookmark.itemId = 0;
    bookmark.flagAsBookmark = !this.selectedPublicationDetails
      .hasBeenBookmarked;
    this.publicationService
      .bookmarkItem(bookmark)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((response: ResponseModel) => {
        if (response.isOk) {
          this.selectedPublicationDetails.hasBeenBookmarked =
            bookmark.flagAsBookmark;
          if (bookmark.flagAsBookmark) {
            this.bookmarkedPublications.push(this.selectedPublicationDetails);
            this.cachedBookmarkedPaginator.totalItemsCount += 1;
          } else {
            const index = this.bookmarkedPublications.indexOf(
              this.selectedPublicationDetails,
              0
            );
            if (index > -1) {
              this.bookmarkedPublications.splice(index, 1);
              this.cachedBookmarkedPaginator.totalItemsCount -= 1;
            }
          }
        }
      });
  }

  public onApplyFilter(filterHolder: SimpleFilterHolderWithDescription) {
    this.simpleFilterDescription = filterHolder.description;
    this.cachedPageListModeBeforeSearch = this.pageListMode;

    //console.log(term);
    this.publicationService
      .searchPublications(filterHolder.filter)
      .pipe(
        finalize(() => {
          this.loading = false;
          this.pageListMode = DataCacheMode.Search;
          if (filterHolder.isAdvancedSearch && filterHolder.bsModalRef)
            filterHolder.bsModalRef.hide();
        })
      )
      .subscribe(response => {
        //this.removeRunningFilter();
        this.searchedPublications = response;
      });
  }
  ngOnDestroy(): void {}
}
