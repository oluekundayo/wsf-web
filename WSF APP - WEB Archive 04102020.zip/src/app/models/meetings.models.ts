import { Time } from "@angular/common";
import { CenterType, PositionHolder } from "./centers.models";
import { Lookup, MeetingReportingType } from "./utilities.models";

export class Meeting {
  id: number;
  name: string;
  description: string;
  status: string;
  //centerTypeHoldingMeetingId: number;
  churchSystemId: number;
  postUrlOnWeb: string;
  postUrlOnMobile: string;
  getUrlOnWeb: string;
  getUrlOnMobile: string;
  totalCentersCount: number;
  meetingReportType: MeetingReportingType;
  createdAt: Date;
  createdBy: string;
  updatedAt: Date;
  updatedBy: string;
}

export class MeetingSetup {
  id: number;
  details: Meeting;
  config: MeetingSetupConfig;
  //reportsPrivileges: MeetingSetupReportPrivilege;
}

export class MeetingSetupConfig {
  meetingWeekDays: string[];
  requiredParticipationCount: number;
  holdsInSections: boolean;
  hasOfferings: boolean;
  requiredApprovalTypes: string[];
  reportEditAllowableHours: number;
  reportingType: string;
  isAccessibleToAll: boolean;
}

export class MeetingSetupReportPrivilege {
  canSubmit: boolean;
  canView: boolean;
  canViewOfferings: boolean;
  canEdit: boolean;
  canDelete: boolean;
}

export class MeetingAbsenceReason {
  id: number;
  name: string;
  description: string;
  usageRequiresComment: boolean;
  createdAt: Date;
  createdBy: string;
}

export class MeetingSection {
  id: number;
  name: string;
  description: string;
  meetingId: number;
  isDefault: boolean;
}

export class CenterTypesPerMeeting {
  centerTypeId: number;
  centerType: string;
  allCentersCount: number;
  itemOrder: number;
  meetingsCenters: CentersPerMeeting[];
}

export class CentersPerMeeting {
  meetingId: number;
  meeting: string;
  centersCount: number;
}

export class CenterDescendantsPerMeeting {
  meetings: Meeting[];
  descendantsTypeCountsPerMeeting: CenterTypesPerMeeting[];
}
