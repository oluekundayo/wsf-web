import { Component, OnInit } from "@angular/core";
import {
  Lookup,
  MeetingReportingType,
  ApprovalStatus,
  Privilege
} from "../../../models/utilities.models";
import { ApiRoutes } from "../../../services/api.routes";
import { finalize } from "rxjs/operators";
//import { BsModalService } from "ngx-bootstrap/modal";
import { APIService } from "../../../services/api.service";
import { MeetingDashboardItem } from "../../../models/reporting.models";
import { Router, ActivatedRoute } from "@angular/router";
import { ReportsMenuService } from "../../../services/components-services/reports-menu.service";
import { includes } from "lodash";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { ReportPageActionType } from "../../../models/utilities.models";
import { ReportingService } from "../../../services/components-services/reporting.service";

@Component({
  selector: "app-reports-menu",
  templateUrl: "./reports-menu.component.html",
  styleUrls: ["./reports-menu.component.scss"]
})
export class ReportsMenuComponent implements OnInit {
  loading = false;
  pageTitle: string;
  meetings: MeetingDashboardItem[] = [];
  pageActionType: ReportPageActionType;
  doneLoadingMeetings: boolean = false;

  constructor(
    private router: Router,
    private activeRoute: ActivatedRoute,
    private reportingService: ReportingService,
    private sweetAlert: SweetAlertService
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  ngOnInit() {
    try {
      const routeParams = this.activeRoute.snapshot.params;
      this.pageActionType = routeParams.actionType as ReportPageActionType;
    } catch (e) {}

    /* if (this.reportMenuService.HasValue()) {
      this.meetings = this.reportMenuService.GetValue();
    } else {
      this.getAssignedMeetingsReportsToSubmit();
    }*/

    this.getAssignedMeetingsReportsToSubmit();
  }

  private getAssignedMeetingsReportsToSubmit() {
    let privilege = Privilege.CanSubmit;
    if (this.pageActionType == ReportPageActionType.Analyze) {
      privilege = Privilege.CanView;
    } else if (this.pageActionType == ReportPageActionType.Submit) {
      privilege = Privilege.CanSubmit;
    }

    this.loading = true;
    this.reportingService
      .getAssignedMeetings(privilege)
      .pipe(
        finalize(() => {
          this.loading = false;
          this.doneLoadingMeetings = true;
        })
      )
      .subscribe(response => {
        //console.log(response);
        this.meetings = response;
        //this.reportMenuService.SetMeetingsMenu(response);
        if (!response.length) {
          /* this.sweetAlert.showMessage(
            "There are no Reports assigned to you. Kindly contact your Admin."
          );*/
        }
      });
  }

  public navigateToReport(meeting: MeetingDashboardItem) {
    this.reportingService.navigateToReport(this.pageActionType, meeting);
  }

  public navigateToDelegatedReportSubmission() {
    this.router.navigateByUrl("/app/reports/delegated-attendance-report");
  }

  private canSubmit(item: MeetingDashboardItem): boolean {
    return (
      this.pageActionType == ReportPageActionType.Submit &&
      includes(item.privileges, "CanSubmit")
    );
  }

  private canView(item: MeetingDashboardItem): boolean {
    return (
      this.pageActionType == ReportPageActionType.Analyze &&
      includes(item.privileges, "CanView")
    );
  }
}
