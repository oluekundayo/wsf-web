import { FileAttachment } from "./church_broadcasts.models";
import {
  PaginatorFilter,
  Lookup,
  Contact,
  ApprovalStatus,
  VisibilityStatus,
  StatusReport
} from "./utilities.models";
import { CenterContact } from "./centers.models";
import { ObjectProperty } from "./reporting.models";

export class PaginatedTestimonies {
  testimonies: Testimony[] = [];
  paginator: PaginatorFilter;
}

export class Testimony {
  centerId?: number;
  details: string;
  detailsBeforeProofReading: string;
  id?: number;
  sharedAt?: Date;
  testifier?: Contact;
  testimoniesClassificationsIds?: number[];
  title: string;
  center?: Contact;
  //status?: ApprovalStatus;
  approvalStatus?: ApprovalStatus;
  visibilityStatus?: VisibilityStatus;
  comment?: string;
  approvalComment?: string;
  centerAddress?: string;
  centerShortNameFromAddress?: string;
  centerContactFullName?: string;
  centerContactPhone?: string;
  imageUrl?: string;
  exclaimText?: string;
}

export class TestimonyApproval {
  details?: string;
  id: number;
  testimoniesClassificationsIds?: number[];
  title?: string;
  approvalStatus: ApprovalStatus;
  approvalComment?: string;
}

export class StarredTestimony {
  testimony_id: number;
  testimonies_ids: number[];
  created_at: Date;
  created_by: string;
  updated_at: Date;
  updated_by: string;
}

/*export class SearchTestimoniesResult {
  id: number;
  title: string;
  details: string;
  sharedAt: Date;
  imageUrl: string;
  exclaim: string;
}*/

export class TestimonyEditHistory {
  testimony_id: number;
  previous_title: string;
  current_title: string;
  previous_details: string;
  current_details: string;
  created_at: Date;
  created_by: string;
}

export class TestimonyClassification {
  id: number;
  name: string;
  description: string;
}

export class TestimoniesStatusReport {
  counts: StatusReport;
  trends: StatusReport[];
  expectedPeriodKeys: ObjectProperty[];
}

/*

export class TestimnoiesRoutes {
    static testimonies = "testimonies";
    static testimoniesEditHistories = "testimonies_edit_histories";
    static starredTestimonies = "starred_testimonies";
   
  }*/
