import { Component, OnInit } from "@angular/core";
import { Lookup, ResponseModel } from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import {
  CenterType,
  CenterSearchResult,
  PositionLevel,
  Center,
  PositionHolder,
  AssignedPositionLevelPrivileges
} from "../../../models/centers.models";
import { APIService } from "../../../services/api.service";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { ApiRoutes } from "../../../services/api.routes";
import { finalize } from "rxjs/operators";
import { FindACenterDialogComponent } from "../../dialog/find-a-center-dialog/find-a-center-dialog.component";
import { UtilitiesService } from "../../../services/utils/utilities.service";
import { cloneDeep, filter, map } from "lodash";
import { ChurchSystem } from "app/models/setups.models";

@Component({
  selector: "app-create-new-centers",
  templateUrl: "./create-new-centers.component.html",
  styleUrls: ["./create-new-centers.component.css"]
})
export class CreateNewCentersComponent implements OnInit {
  formGroup: FormGroup;
  loading = false;
  pageTitle: string;
  assignedPositionLevelPrivileges: AssignedPositionLevelPrivileges;
  centerTypes: CenterType[] = [];
  selectedCenterTypeChurchSystems: ChurchSystem[] = [];
  selectedCenterTypePositionLevels: PositionLevel[] = [];
  selectedPositionLevel: PositionLevel;
  parentCenter: CenterSearchResult;
  bsModalRef: BsModalRef;
  genderList: Lookup[] = [];
  prefixes: Lookup[] = [];
  //churchPrograms: Lookup[] = [];

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    private modalService: BsModalService,
    private sweetAlertService: SweetAlertService,
    private utilitiesService: UtilitiesService
  ) {
    this.formGroup = fb.group({
      centerTypeId: [null, Validators.required],
      parentCenterId: [0, Validators.required],
      centerAddress: ["", Validators.required],
      shortNameAddress: [""],
      addCenterUser: [false],
      positionLevelId: [null, Validators.required],
      prefix: [null],
      lastname: [""],
      firstname: ["", Validators.required],
      phone: [""],
      gender: [null],
      email: ["", Validators.email],
      address: [""],
      centerStartDate: [null],
      churchSystemIds: [null]
    });
  }

  ngOnInit() {
    this.prefixes = this.getPrefixes();
    this.genderList = this.getGenderList();
    this.getAssignedPositionLevelPrivileges();
  }

  private getAssignedPositionLevelPrivileges() {
    this.loading = true;
    this.api
      .getAll<AssignedPositionLevelPrivileges>(
        ApiRoutes.position_levels.get_assigned_position_level_privileges
      )

      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.assignedPositionLevelPrivileges = response;
        this.centerTypes = cloneDeep(response.assignedCenterTypes);
      });
  }

  /*private loadCenterTypes() {
    this.loading = true;
    this.api
      .getAll<CenterType[]>(ApiRoutes.centers.get_assigned_centers_types)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        console.log(response);
        this.centerTypes = response;
      });
  }*/

  private getPrefixes(): Lookup[] {
    const prefixes: Lookup[] = [];

    const pp = ["Pastor", "Elder", "Dcn.", "Dcns.", "Bro.", "Sis."];

    pp.forEach(p => {
      prefixes.push({ id: 1, name: p });
    });

    return prefixes;
  }

  private getGenderList(): Lookup[] {
    const genders: Lookup[] = [];

    const pp = ["Male", "Female"];

    pp.forEach(p => {
      genders.push({ id: 1, name: p });
    });

    return genders;
  }

  public onSelectCenterType(selectedCenterType: CenterType) {
    this.formGroup.patchValue({
      positionLevelId: null
    });

    if (selectedCenterType) {
      this.getChurchSystems(selectedCenterType);
    } else {
      this.selectedCenterTypePositionLevels = [];
      this.selectedCenterTypeChurchSystems = [];
    }
  }

  public onSelectPositionLevel(positionLevel: PositionLevel) {
    if (positionLevel) {
      this.selectedPositionLevel = positionLevel;
      //console.log(this.selectedPositionLevel);
    }
  }

  private getChurchSystems(selectedCenterType: CenterType) {
    /*this.loading = true;
    this.api
      .getAll<Lookup[]>(
        ApiRoutes.centers.centers_types_church_systems + "/" + centerTypeId
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.churchPrograms = response;
      });*/

    /*this.selectedCenterTypeChurchSystems = filter(
      this.assignedPositionLevelPrivileges.assignedChurchSystems,
      (a: ChurchSystem) => {
        return a.associatedCenterTypeId == centerTypeId;
      }
    );*/

    this.selectedCenterTypeChurchSystems = selectedCenterType.churchSystems;

    this.selectedCenterTypePositionLevels = filter(
      this.assignedPositionLevelPrivileges.assignedPositionLevels,
      (a: PositionLevel) => {
        return a.centerTypeId == selectedCenterType.id;
      }
    );
  }

  public openModalToSelectParentCenter() {
    const selectedCenterTypeId = this.getFormControlValue("centerTypeId");

    if (!selectedCenterTypeId) {
      alert("Please select the Center Type you want to Create.");
      return;
    }

    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      initialState: {
        returnAncestorsCenterTypes: true,
        selectedCenterTypeId: selectedCenterTypeId
      }
    };

    this.bsModalRef = this.modalService.show(
      FindACenterDialogComponent,
      config
    );
    this.bsModalRef.content.action.subscribe((value: CenterSearchResult) => {
      // console.log(value); // here you will get the value
      if (value) {
        this.parentCenter = value;

        this.formGroup.patchValue({
          parentCenterId: this.parentCenter.centerId
        });

        //this.survey.controls['account'].patchValue(survey.account);
        //https://toddmotto.com/angular-2-form-controls-patch-value-set-value
      }
    });
  }

  private getCenterDataToSave(): Center {
    let newCenter: Center;
    let positionHolder: PositionHolder;

    newCenter = new Center();
    positionHolder = new PositionHolder();

    newCenter.address = this.getFormControlValue("centerAddress");
    newCenter.parentId = this.getFormControlValue("parentCenterId");
    newCenter.centerTypeId = this.getFormControlValue("centerTypeId");

    if (
      this.selectedCenterTypeChurchSystems &&
      this.selectedCenterTypeChurchSystems.length > 0
    ) {
      newCenter.churchSystemsIds = map(
        this.selectedCenterTypeChurchSystems,
        (item: ChurchSystem) => {
          return item.id;
        }
      );
    }

    newCenter.centerStartDate = this.utilitiesService.createDateAsUTC(
      this.getFormControlValue("centerStartDate")
    );

    newCenter.shortNameFromAddress = this.getFormControlValue(
      "shortNameAddress"
    );

    newCenter.addCenterUser = true;
    newCenter.useSystemCenterNumbering = true;

    positionHolder.address = this.getFormControlValue("address");
    positionHolder.firstname = this.getFormControlValue("firstname");
    positionHolder.lastname = this.getFormControlValue("lastname");
    positionHolder.fullname =
      positionHolder.lastname + " " + positionHolder.firstname;
    positionHolder.email = this.getFormControlValue("email");
    positionHolder.phone = this.getFormControlValue("phone");
    positionHolder.prefix = this.getFormControlValue("prefix");
    positionHolder.gender = this.getFormControlValue("gender");
    positionHolder.centerTypeId = newCenter.centerTypeId;
    positionHolder.maritalStatus = "";
    positionHolder.othername = "";
    positionHolder.positionLevelId = this.getFormControlValue(
      "positionLevelId"
    );
    positionHolder.isCentersContact = this.selectedPositionLevel.isCentersContactLevel;

    newCenter.positionHolder = positionHolder;

    return newCenter;
  }

  private validateBeforeSubmission(center: Center): ResponseModel {
    let error = new ResponseModel();
    error.isOk = true;
    error.error = "";

    if (!this.parentCenter || !this.parentCenter.centerId) {
      error.isOk = false;
      error.error += "Please select Parent Center.<br/>";
    }

    if (!center.address) {
      error.isOk = false;
      error.error += "Center Address is required for each record.<br/>";
    }

    if (!center.centerTypeId) {
      error.isOk = false;
      error.error += "Please select a Center Type to create.<br/>";
    }

    if (
      !this.selectedPositionLevel.centerTypeId ||
      this.selectedPositionLevel.centerTypeId != center.centerTypeId
    ) {
      error.isOk = false;
      error.error +=
        "Selected Role does not function under the selected Center Type.<br/>";
    }

    return error;
  }

  public createNewCenter() {
    const center = this.getCenterDataToSave();

    if (center == null) {
      this.sweetAlertService.showError(
        "Invalid New Center Details. Please check and try again."
      );
      return;
    }

    const validate = this.validateBeforeSubmission(center);
    if (!validate.isOk) {
      this.sweetAlertService.showError(validate.error, true);
      return;
    }

    this.sweetAlertService
      .showConfirm("This New Center will be submitted for creation")
      .then(response => {
        if (response.value) {
          this.loading = true;
          console.log(center);
          this.api
            .post<ResponseModel>(ApiRoutes.centers.create_new_center, center)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe(response => {
              this.resetPage();
              this.sweetAlertService.showSuccess(response.message);
            });
          //console.log(response.value);
        }
      });
  }

  private trimString(_string: string): string {
    if (_string) return _string.trim();
    else return "";
  }

  private getFormControlValue(key: string) {
    return this.formGroup.get(key).value;
  }

  private resetPage() {
    this.parentCenter = new CenterSearchResult();
    this.parentCenter.displayAddress = "";
    this.formGroup.reset();
  }

  ngOnDestroy(): void {
    try {
      this.bsModalRef.content.action.unsubscribe();
    } catch (e) {}
  }
}
