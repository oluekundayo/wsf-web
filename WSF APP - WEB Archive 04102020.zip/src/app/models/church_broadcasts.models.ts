export class ChurchMaterial {
  id: number;
  category: string;
  note: string;
  title: string;
  download_starts_at: Date;
  download_ends_at: Date;
  status: string;
  created_at: Date;
  created_by: string;
  attachments: FileAttachment[];
}

export class ChurchMaterialCategory {
  id: number;
  name: string;
  description: string;
  created_at: Date;
  created_by: string;
}

export class ChurchPost {
  id: number;
  category: string;
  message: string;
  title: string;
  display_starts_at: Date;
  display_ends_at: Date;
  status: string;
  created_at: Date;
  created_by: string;
  attachments: FileAttachment[];
}

export class FileAttachment {
  id: number;
  file_name: string;
  file_path: string;
  file_mime_type: string;
  file_extension: string;
  file_size: string;
  file_date_modified_timestamp: number;
  file_date_modified: Date;
  created_at: Date;
  created_by: string;
}

export class ChurchPostCategory {
  id: number;
  name: string;
  description: string;
  created_at: Date;
  created_by: string;
}

/*
export class ChurchBroadcastsRoutes {
  static materials = "church_materials";
  static materialsCategories = "church_materials_categories";
  static materialsDownloaded = "church_downloaded_materials";
  static posts = "church_posts";
  static postsCategories = "church_posts_categories";
  static postsRead = "church_posts_read";
}
*/
