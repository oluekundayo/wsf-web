import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-centers-data-download',
  templateUrl: './centers-data-download.component.html',
  styleUrls: ['./centers-data-download.component.css']
})
export class CentersDataDownloadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
