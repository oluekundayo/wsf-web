import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import {
  SubmittedReportItem,
  MeetingReportToSubmit
} from "../../../models/reporting.models";
import { APIService } from "../../../services/api.service";
import { finalize } from "rxjs/operators";
import { ApiRoutes } from "../../../services/api.routes";
import { ReportAttendanceDialogComponent } from "../../dialog/report-attendance-dialog/report-attendance-dialog.component";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { ReportPageActionType } from "../../../models/utilities.models";

@Component({
  selector: "app-view-submitted-reports",
  templateUrl: "./view-submitted-reports.component.html",
  styleUrls: ["./view-submitted-reports.component.scss"]
})
export class ViewSubmittedReportsComponent implements OnInit {
  submittedReports: SubmittedReportItem[] = [];
  reportsKeys: any;
  loading: boolean = false;
  meetingId: number;
  bsModalRef: BsModalRef;

  //Pagination
  public pagingCurrentPage: number = 1;
  public pagingItemsPerPage: number = 10;

  constructor(
    private router: Router,
    private activeRoute: ActivatedRoute,
    private api: APIService,
    private modalService: BsModalService
  ) {}

  ngOnInit() {
    try {
      const routeParams = this.activeRoute.snapshot.params;
      this.meetingId = routeParams.id;
    } catch (e) {}

    this.reportsKeys = this.getReportsKeys();
    this.loadSubmittedReports();
  }

  navigateBackToReportsList() {
    this.router.navigate(["app/reports/menu/" + ReportPageActionType.Submit]);
  }

  private getReportsKeys() {
    return [
      { field: "males", label: "Males" },
      { field: "females", label: "Females" },
      {
        field: "children",
        label: "Children"
      },
      { field: "totalAdults", label: "Total Adults" },
      { field: "totalAttendance", label: "Total Attend." },
      { field: "newConverts", label: "New Converts" },
      { field: "firstTimers", label: "First Timers" },
      { field: "testimonies", label: "Testimonies" },
      { field: "meetingDate", label: "Meeting Date" },
      { field: "reportedAt", label: "Reported At" }
    ];
  }

  private loadSubmittedReports() {
    this.loading = true;
    this.api
      .getAll<SubmittedReportItem[]>(
        ApiRoutes.reports.load_submitted_reports + "/" + this.meetingId
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.submittedReports = response;
      });
  }

  public openModalToEditReport(index: number) {
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      //class: "modal-sm",
      initialState: {
        report: this.submittedReports[index],
        meetingId: this.meetingId,
        pageActionType: ReportPageActionType.Edit
      }
    };

    this.bsModalRef = this.modalService.show(
      ReportAttendanceDialogComponent,
      config
    );
    this.bsModalRef.content.action.subscribe((value: SubmittedReportItem) => {
      //console.log(value); // here you will get the value
      if (value) {
        this.submittedReports[index] = value as SubmittedReportItem;
      }
    });
  }
}
