import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "../../services/guards/auth-guard.service";
import { CentersDataDownloadComponent } from "./centers-data-download/centers-data-download.component";
import { CentersDataUpdateComponent } from "./centers-data-update/centers-data-update.component";
import { CreateNewCentersComponent } from "./create-new-centers/create-new-centers.component";
import { RegisterExistingCentersComponent } from "./register-existing-centers/register-existing-centers.component";
import { CreateNewCenterPositionHolderComponent } from "./create-new-center-position-holder/create-new-center-position-holder.component";
import { ViewRegisteredCentersComponent } from "./view-registered-centers/view-registered-centers.component";
import { MyCenterComponent } from "./my-center/my-center.component";
import { FindACenterComponent } from "./find-a-center/find-a-center.component";
import { RemoveCenterComponent } from "./remove-center/remove-center.component";
import { MoveCenterComponent } from "./move-center/move-center.component";

const routes: Routes = [
  {
    path: "centers-data-download",
    component: CentersDataDownloadComponent,
    data: {
      title: "Centers Data Download"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "centers-data-update",
    component: CentersDataUpdateComponent,
    data: {
      title: "Centers Data Update"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "create-new-center",
    component: CreateNewCentersComponent,
    data: {
      title: "Create New Center"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "create-new-center-position-holder",
    component: CreateNewCenterPositionHolderComponent,
    data: {
      title: "Create New Center's Position Holder"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "register-existing-centers",
    component: RegisterExistingCentersComponent,
    data: {
      title: "Register Existing Centers"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "view-registered-centers",
    component: ViewRegisteredCentersComponent,
    data: {
      title: "View Registered Centers"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "my-center",
    component: MyCenterComponent,
    data: {
      title: "My Center"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "find-a-center",
    component: FindACenterComponent,
    data: {
      title: "Find a Center"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "remove-center",
    component: RemoveCenterComponent,
    data: {
      title: "Remove a Center"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "move-center",
    component: MoveCenterComponent,
    data: {
      title: "Move a Center"
    },
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CentersRoutingModule {}
