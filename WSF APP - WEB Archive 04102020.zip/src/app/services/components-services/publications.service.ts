import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";

import { APIService } from "../api.service";
import { ApiRoutes } from "../api.routes";
import { Observable, of } from "rxjs";
import {
  Publication,
  PublicationCategory,
  PaginatedPublications,
  PublicationTimeline,
  PublicationsStatusReport
} from "../../models/publications.models";
import {
  Lookup,
  ApiUrlParam,
  MyHttpOptions,
  ResponseModel,
  VisibilityStatus,
  ApprovalPost,
  ApprovalStatus,
  PaginatorFilter,
  PageDirection,
  SimpleFilter,
  BookmarkPost
} from "../../models/utilities.models";
import { ResponseContentType, RequestOptions } from "@angular/http";
import { environment } from "environments/environment";
import { ReportFilter } from "../../models/reporting.models";
import * as moment from "moment";
import { UtilitiesService } from "../utils/utilities.service";
import { filter, chain, map, includes, reduce } from "lodash";

@Injectable()
export class PublicationService {
  private url = ApiRoutes;
  constructor(
    private http: HttpClient,
    private apiservice: APIService,
    private utilitiesService: UtilitiesService
  ) {}

  getPublicationCategories() {
    return this.apiservice.getAll<Lookup[]>(
      this.url.church_publication.publication_category
    );
  }

  getPublicationsTimeline = paginator => {
    paginator.approvalStatus = ApprovalStatus.Approved;
    return this.apiservice.find<PublicationTimeline[]>(
      this.url.church_publication.get_paginated_publications,
      paginator
    );
  };

  getPublicationsTimelineItems = (timeline: PublicationTimeline) => {
    const params = { itemsKeys: timeline.itemsKeys, pKey: timeline.pKey };
    return this.apiservice.post<Publication[]>(
      this.url.church_publication.get_publications_timeline_items,
      params
    );
  };

  getAllBookmarkedPublications = paginator => {
    /*const _paginator: PaginatorFilter = {
      pageSize: paginator.pageSize,
      lastMaxId: paginator.lastMaxId,
      lastMinId: paginator.lastMinId,
      limitToBookmarks: paginator.limitToBookmarks
    };*/

    paginator.approvalStatus = ApprovalStatus.Approved;
    paginator.limitToBookmarks = true;

    return this.apiservice.find<PaginatedPublications>(
      this.url.church_publication.get_paginated_publications,
      paginator
    );
  };

  getAllUnapprovedPublications = paginator => {
    /*const _paginator: PaginatorFilter = {
      pageSize: paginator.pageSize,
      lastMaxId: paginator.lastMaxId,
      lastMinId: paginator.lastMinId,
      limitToBookmarks: paginator.limitToBookmarks
    };*/

    paginator.approvalStatus = ApprovalStatus.Unapproved;

    return this.apiservice.find<Publication[]>(
      this.url.church_publication.get_paginated_publications,
      paginator
    );
  };

  // getAllActivePublications = (pageSize: any, lastMinId: any) => {
  //   return this.apiservice.getAll<PaginatedPublications>(
  //     `${
  //       this.url.church_publication.get_paginated_publications
  //     }/${pageSize}/${lastMinId}`
  //   );
  // };

  searchPublications = (
    filter: SimpleFilter
  ): Observable<Publication[]> => {
    return this.apiservice.post<Publication[]>(
      `${this.url.church_publication.search_publications}`,
      filter
    );

    /*if (query && publicationsTimelines && publicationsTimelines.length) {
      const ff = chain(publicationsTimelines)
        .reduce(
          (e, value) => {
            return e.concat(value.publications);
          },
          [] as Publication[]
        )
        .filter((e: Publication) => {
          // console.log(e);
          if (e && e.subject) {
            return includes(e.subject.toLowerCase(), query.toLowerCase());
          } else {
            return false;
          }
        })
        .value();

      return of(ff);
    } else {
      return of([] as Publication[]);
    }*/
  };

  getPublicationDetail = (idKey: string) => {
    return this.apiservice.get<Publication>(
      this.url.church_publication.publication,
      0,
      [{ name: "idKey", value: idKey }]
    );
  };

  public bookmarkItem(bookmark: BookmarkPost) {
    return this.apiservice.put(
      this.url.church_publication.bookmark_publication,
      0,
      bookmark
    );
  }

  public approveItem(itemId: number, approvalStatus: ApprovalPost) {
    return this.apiservice.put(
      this.url.church_publication.approve_publication,
      0,
      approvalStatus
    );
  }

  public saveNewCategory(classif: Lookup) {
    return this.apiservice.post(
      this.url.testimonies.save_new_classification,
      classif
    );
  }

  getPreviousPublications = (filter: SimpleFilter) => {
    return this.apiservice.find<Publication[]>(
      this.url.church_publication.get_previous_publications,
      filter
    );
  };

  deletePreviousAttachment(id: number, fileName: string) {
    return this.apiservice.delete<ResponseModel>(
      this.url.church_publication.delete_previous_publication_attachment,
      id,
      [{ name: "fileName", value: fileName } as ApiUrlParam]
    );
  }

  publish(data: FormData): Observable<any> {
    const headers = new HttpHeaders({
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
    });

    const options: MyHttpOptions = {
      headers: headers
    };

    //return this.apiservice.post(this.url.church_publication.publication, data);

    return this.apiservice.post<ResponseModel>(
      this.url.church_publication.publication,
      data
    );
  }

  downloadAttachment(fileName: string, mimeType: string) {
    //http://javabypatel.blogspot.com/2017/11/download-file-in-angular2.html

    const headers = new HttpHeaders({
      "Content-Type": mimeType,
      Accept: mimeType
    });

    const options: MyHttpOptions = {
      headers: headers,
      responseType: "blob" as "json" // arrayBuffer
    };

    return this.http.get<Blob>(
      `${environment.API_BASE_URL}/${this.url.church_publication
        .publication_download +
        "/" +
        fileName}`,
      options
    );
  }

  public getPublicicationsReport(filter: SimpleFilter) {
    return this.apiservice.find<PublicationsStatusReport>(
      this.url.church_publication.get_publications_reports,
      filter
    );
  }

  public updateVisibilityStatus(id: number, status: ApprovalPost) {
    return this.apiservice.patch(
      this.url.church_publication.patch_visibility_status,
      id,
      status
    );
  }

  /*getZip(path: string, params: URLSearchParams = new URLSearchParams()): Observable<any> {
    let headers = this.setHeaders({
         'Content-Type': 'application/zip',
         'Accept': 'application/zip'
       });
   
    return this.http.get(`${environment.apiUrl}${path}`, { 
      headers: headers, 
      search: params, 
      responseType: ResponseContentType.ArrayBuffer //magic
    })
             .catch(this.formatErrors)
             .map((res:Response) => res['_body']);
   }*/

  public injectPaginatorDatesRange(
    paginator: PaginatorFilter,
    dateFormat: string = null
  ) {
    if (!dateFormat) {
      dateFormat = "YYYY-MMMM-DD";
    }

    if (paginator.direction == PageDirection.CURRENT) {
      const _today = moment();

      paginator.filterEndDate = this.utilitiesService.createDateStringAsUTCDate(
        _today.format(dateFormat)
      );

      paginator.filterStartDate = this.utilitiesService.createDateStringAsUTCDate(
        _today.startOf("year").format(dateFormat)
      );
    }
    if (paginator.direction == PageDirection.PREVIOUS) {
      const mom1 = moment(paginator.filterStartDate);
      const mom2 = moment(paginator.filterStartDate);

      paginator.filterStartDate = this.utilitiesService.createDateStringAsUTCDate(
        mom1
          .subtract(1, "years")
          .startOf("year")
          .format(dateFormat)
      );

      paginator.filterEndDate = this.utilitiesService.createDateStringAsUTCDate(
        mom2
          .subtract(1, "years")
          .endOf("year")
          .format(dateFormat)
      );
    }

    if (paginator.direction == PageDirection.NEXT) {
      const mom1 = moment(paginator.filterStartDate);
      const mom2 = moment(paginator.filterStartDate);

      paginator.filterStartDate = this.utilitiesService.createDateStringAsUTCDate(
        mom1
          .add(1, "years")
          .startOf("year")
          .format(dateFormat)
      );

      paginator.filterEndDate = this.utilitiesService.createDateStringAsUTCDate(
        mom2
          .add(1, "years")
          .endOf("year")
          .format(dateFormat)
      );
    }

    //console.log(paginator);
  }
}
