import { Component, OnDestroy } from "@angular/core";
// import { DatePipe, ViewportScroller, Location } from "@angular/common";
import { Router, Scroll } from "@angular/router";
import { filter } from "rxjs/operators";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnDestroy {
  ngOnDestroy(): void {
    //alert("Oops");
  }
}
