import { Component, OnInit } from "@angular/core";
import { ReportingService } from "app/services/components-services/reporting.service";
import { finalize } from "rxjs/operators";
import {
  ReportFilter,
  SimpleAttendanceReport,
  MeetingReportToSubmit
} from "app/models/reporting.models";
import { AttendanceReportsAnalysisDetailsByCenter } from "app/models/reports.analysis.models";
import { Meeting } from "app/models/meetings.models";
import { LookupViewModel } from "../../../../../models/wsftypes";
import { map, cloneDeep, filter, uniq, isEqual, chain } from "lodash";
import { ReportAttendanceDialogComponent } from "app/components/dialog/report-attendance-dialog/report-attendance-dialog.component";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { ReportPageActionType } from "app/models/utilities.models";

@Component({
  selector: "app-delegated-attendance-report",
  templateUrl: "./delegated-attendance-report.component.html",
  styleUrls: ["./delegated-attendance-report.component.scss"]
})
export class DelegatedAttendanceReportComponent implements OnInit {
  public loading: boolean = false;
  public meetings: Meeting[] = [];
  filter: ReportFilter = new ReportFilter();
  public reportingCentersStore: AttendanceReportsAnalysisDetailsByCenter[] = [];
  public reportingCenters: AttendanceReportsAnalysisDetailsByCenter[] = [];
  private selectedMeeting: Meeting;
  public runSomeFilters: boolean = false;
  public parentCenters: LookupViewModel[] = [];
  public selectedParent: LookupViewModel;
  public selectedCenter: AttendanceReportsAnalysisDetailsByCenter;
  public selectedMeetingDate: Date;
  bsModalRef: BsModalRef;
  //Pagination
  public pagingCurrentPage: number = 1;
  public pagingItemsPerPage: number = 10;

  constructor(
    private reportingService: ReportingService,
    private modalService: BsModalService
  ) {}

  ngOnInit() {
    this.getAllMeetings();
  }

  private getAllMeetings() {
    this.loading = true;
    this.reportingService
      .getAllMeetings()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((response: Meeting[]) => {
        this.meetings = response;
      });
  }

  private loadData() {
    this.reportingCenters = [];
    this.loading = true;
    this.reportingService
      .getReportingCentersUnderARole(this.filter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((response: AttendanceReportsAnalysisDetailsByCenter[]) => {
        this.reportingCenters = response;
        this.reportingCentersStore = cloneDeep(response);
        if (this.reportingCenters && this.reportingCenters.length)
          this.parentCenters = chain(this.reportingCenters)
            .map((item: AttendanceReportsAnalysisDetailsByCenter) => {
              return {
                id: item.parentCenterId,
                name: item.parentCenterName
              } as LookupViewModel;
            })
            .uniqWith(isEqual)
            .value();
      });
  }

  public onSelectMeeting(meeting: Meeting) {
    this.selectedMeeting = meeting;
    this.updateReportFilter();
    this.loadData();
  }

  private updateReportFilter() {
    this.filter.meetingDate = null;
    this.filter.meetingChurchSystemId = this.selectedMeeting.churchSystemId;
    this.filter.meetingId = this.selectedMeeting.id;
    //this.filter.meetingSectionId = null;
  }

  public onSelectParentFilter(parentCenter: LookupViewModel) {
    this.reportingCenters = filter(
      this.reportingCentersStore,
      (item: AttendanceReportsAnalysisDetailsByCenter) => {
        return item.parentCenterId == parentCenter.id;
      }
    );
  }

  public onCheckRunSomeFilter(checked: boolean) {
    this.runSomeFilters = checked;
    this.selectedParent = null;
    this.reportingCenters = cloneDeep(this.reportingCentersStore);
  }

  public onSelectMeetingDateFilter() {
    this.filter.meetingDate = this.selectedMeetingDate;
    this.loadData();
  }

  public openModalToSubmitReport(
    item: AttendanceReportsAnalysisDetailsByCenter
  ) {
    //this.selectedCenter = this.reportingCenters[index];

    this.selectedCenter = item;

    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      //class: "modal-sm",
      initialState: {
        report: this.selectedCenter.report,
        meetingId: this.selectedMeeting.id,
        pageActionType: ReportPageActionType.Submit,
        center: this.selectedCenter,
        meetingReportType: this.selectedMeeting.meetingReportType
      }
    };

    this.bsModalRef = this.modalService.show(
      ReportAttendanceDialogComponent,
      config
    );

    this.bsModalRef.content.action.subscribe(
      (value: AttendanceReportsAnalysisDetailsByCenter) => {
        //console.log(value); // here you will get the value
        if (value) {
          // alert("here")
          //  this.submreittedReports[index] = value as SubmittedReportItem;
          //change to row update
          this.loadData();
        }
      }
    );
  }
}
