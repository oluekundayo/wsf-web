import { Component, OnInit, EventEmitter, Output } from "@angular/core";
import { Observable } from "rxjs";
import {
  Lookup,
  ResponseModel,
  ApiUrlParam
} from "../../../models/utilities.models";
import { ApiRoutes } from "../../../services/api.routes";
import { finalize } from "rxjs/operators";
import { APIService } from "../../../services/api.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { BsModalRef } from "ngx-bootstrap/modal";
import {
  Center,
  PositionHolder,
  CenterSearchResult,
  PositionLevel
} from "../../../models/centers.models";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";

@Component({
  selector: "app-edit-center-dialog",
  templateUrl: "./edit-center-dialog.component.html",
  styleUrls: ["./edit-center-dialog.component.scss"]
})
export class EditCenterDialogComponent implements OnInit {
  //loaded from parent window
  selectedCenter: CenterSearchResult;
  editType: string = "";
  //////////////////////////////

  formGroup: FormGroup;
  churchSystems: Lookup[] = [];
  loading: boolean = false;
  positionLevels$: Observable<PositionLevel[]>;
  prefixList: string[] = [];
  @Output() action = new EventEmitter<any>();
  isHolderDetailsLoaded: boolean = false;

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    private sweetAlertService: SweetAlertService,
    public bsModalRef: BsModalRef
  ) {
    this.prefixList = ["Pastor", "Elder", "Dcn.", "Dcns.", "Bro.", "Sis."];
    this.createForm();
  }

  ngOnInit() {
    if (this.editType == "CENTER") {
      this.loadChurchSystemsAssignedToManage();
    } else if (this.editType == "USER") {
      this.loadPositionLevels();
    }
  }

  private loadChurchSystemsAssignedToManage() {
    this.loading = true;
    this.api
      .getAll<Lookup[]>(
        ApiRoutes.church_setups.church_operational_systems_assigned_to_manage
      )
      .pipe(
        finalize(() => {
          this.loading = false;
          this.loadCentersDetails();
        })
      )
      .subscribe(response => {
        this.churchSystems = response;
      });
  }

  private loadPositionLevels() {
    this.loading = true;
    const params: ApiUrlParam[] = [
      { name: "centerTypeId", value: this.selectedCenter.centerTypeId }
    ];
    this.positionLevels$ = this.api
      .getAll<PositionLevel[]>(
        ApiRoutes.position_levels.get_assigned_position_levels_to_a_center_type,
        // + "/" + this.selectedCenter.centerTypeId
        params
      )
      .pipe(finalize(() => (this.loading = false)));
  }

  private loadCentersDetails() {
    this.loading = true;
    this.api
      .get<Center>(ApiRoutes.centers.centers, this.selectedCenter.centerId)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((response: Center) => {
        this.patchCenter(response);
      });
  }

  private createForm() {
    this.formGroup = this.fb.group({
      centersDetails: this.fb.group({
        id: [null, Validators.required],
        churchSystemsIds: [null],
        address: [""],
        shortNameFromAddress: [""],
        name: [""],
        chartLabel: [""]
      }),
      centersPositionHoldersDetails: this.fb.group({
        id: [null, Validators.required],
        positionLevelId: [null],
        prefix: [null],
        lastname: [""],
        firstname: [""],
        phone: [""],
        gender: [null],
        email: ["", Validators.email],
        address: [""],
        centerId: [null, Validators.required],
        isCentersContact: [false]
      })
    });
  }

  private patchCenter(center: Center) {
    this.formGroup.patchValue({
      centersDetails: {
        churchSystemsIds: center.churchSystemsIds,
        address: center.address,
        shortNameFromAddress: center.shortNameFromAddress,
        id: center.id,
        name: center.name,
        chartLabel: center.chartLabel
      }
    });
  }

  private patchPositionHolder(holder: PositionHolder) {
    this.formGroup.patchValue({
      centersPositionHoldersDetails: {
        id: holder.id,
        positionLevelId: holder.positionLevelId,
        prefix: holder.prefix,
        lastname: holder.lastname,
        firstname: holder.firstname,
        phone: holder.phone,
        gender: holder.gender,
        email: holder.email,
        address: holder.address,
        centerId: this.selectedCenter.centerId,
        isCentersContact: holder.isCentersContact
      }
    });
  }

  public onChangePositionLevel(positionLevel: PositionLevel) {
    if (positionLevel) {
      this.loading = true;
      this.api
        .getAll<PositionHolder>(
          ApiRoutes.centers.centers_position_holders +
            "/" +
            this.selectedCenter.centerId +
            "/" +
            positionLevel.id
        )
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(
          (response: PositionHolder) => {
            response.isCentersContact = positionLevel.isCentersContactLevel;
            this.isHolderDetailsLoaded = true;
            this.patchPositionHolder(response);
          },
          error => {
            this.patchPositionHolder(new PositionHolder());
          }
        );
    }
  }

  private getCenterDataToUpdate(): Center {
    const center: Center = new Center();

    center.id = this.formGroup.value.centersDetails.id;

    /*if (this.churchSystems && this.churchSystems.length > 0) {
      center.churchSystemsIds = this.formGroup.value.centersDetails.churchSystemsIds;
    } else {
      center.churchSystemsIds = null;
    }*/

    center.churchSystemsIds = this.formGroup.value.centersDetails.churchSystemsIds;
    center.address = this.formGroup.value.centersDetails.address;
    center.shortNameFromAddress = this.formGroup.value.centersDetails.shortNameFromAddress;
    center.centerAlias = this.selectedCenter.centerAlias;

    return center;
  }

  public updateRecord() {
    if (this.editType == "CENTER") {
      this.updateCentersRecord();
    } else if (this.editType == "USER") {
      this.updatePositionHoldersRecord();
    }
  }

  private updateCentersRecord() {
    const center: Center = this.getCenterDataToUpdate();

    if (!center.id) {
      alert("Invalid Center's Identity.");
      return;
    }

    if (!center.address) {
      alert("Center's Address is required.");
      return;
    }

    this.sweetAlertService
      .showConfirm("Center's Details will be updated.")
      .then(a => {
        if (a.value) {
          this.loading = true;
          this.api
            .patch(
              ApiRoutes.centers.centers,
              this.selectedCenter.centerId,
              center
            )
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              if (response.isOk) {
                // this.formGroup.reset();
                //this.resetForm();
                //console.log(response.data);
                this.sweetAlertService.showSuccess(response.message);
                this.closeModal(response.data);
              }
            });
        }
      });
  }

  private updatePositionHoldersRecord() {
    const holder: PositionHolder = this.formGroup.value
      .centersPositionHoldersDetails;

    if (!holder.id) {
      alert("Invalid User's Identity.");
      return;
    }

    if (!holder.positionLevelId) {
      alert("Invalid User's Role.");
      return;
    }

    if (!holder.lastname && !holder.firstname) {
      alert("User's Name is required.");
      return;
    }

    this.sweetAlertService
      .showConfirm("User's Details will be updated.")
      .then(a => {
        if (a.value) {
          this.loading = true;
          this.api
            .patch(
              ApiRoutes.centers.centers_position_holders,
              holder.id,
              holder
            )
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              if (response.isOk) {
                // this.formGroup.reset();
                //this.resetForm();
                //console.log(response.data);
                this.sweetAlertService.showSuccess(response.message);
                this.closeModal(response.data);
              }
            });
        }
      });
  }

  public closeModal(data: any) {
    this.action.emit(data);
    this.bsModalRef.hide();
  }
}
