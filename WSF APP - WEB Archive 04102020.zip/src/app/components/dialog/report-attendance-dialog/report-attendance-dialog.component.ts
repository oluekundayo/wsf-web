import { Component, OnInit, EventEmitter, Output } from "@angular/core";
import { Validators, FormBuilder, FormGroup } from "@angular/forms";
import {
  SimpleAttendanceReport,
  MeetingReportToSubmit,
  SubmittedReportItem
} from "../../../models/reporting.models";
import { Router, ActivatedRoute } from "@angular/router";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { UtilitiesService } from "../../../services/utils/utilities.service";
import { finalize } from "rxjs/operators";
import {
  ResponseModel,
  ReportPageActionType
} from "../../../models/utilities.models";
import { BsModalRef } from "ngx-bootstrap/modal";
import { DatePipe } from "@angular/common";
import { ReportingService } from "../../../services/components-services/reporting.service";
import { Meeting } from "app/models/meetings.models";
import { AttendanceReportsAnalysisDetailsByCenter } from "app/models/reports.analysis.models";

@Component({
  selector: "app-report-attendance-dialog",
  templateUrl: "./report-attendance-dialog.component.html",
  styleUrls: ["./report-attendance-dialog.component.scss"]
})
export class ReportAttendanceDialogComponent implements OnInit {
  meetingId: number = 0;
  meetingReportType: string = "Attendance";
  center: AttendanceReportsAnalysisDetailsByCenter;
  report: SubmittedReportItem;
  simpleReportForm: FormGroup;
  pageActionType: ReportPageActionType;
  loading: boolean = false;
  pageTitle: string = "";
  actionButtonText: string = "";
  @Output() action = new EventEmitter<any>();

  constructor(
    private formBuilder: FormBuilder,
    private reportingServce: ReportingService,
    private sweetAlertService: SweetAlertService,
    private utilitiesService: UtilitiesService,
    public bsModalRef: BsModalRef
  ) {
    this.createForm();
  }

  ngOnInit() {
    if (this.pageActionType == ReportPageActionType.Edit) {
      this.actionButtonText = "Update";
      this.pageTitle = "Edit Report - " + this.center.centerName;
      this.patchForm();
      /*this.simpleReportForm.valueChanges.subscribe(val => {
      console.log(val);

      // if(val == )
      const total = val.males + val.females + val.children;
      this.simpleReportForm.controls.totalAttendance.patchValue(total, {
        emitEvent: false
      });
    });*/
    } else {
      this.actionButtonText = "Submit";
      this.pageTitle = "Submit Report - " + this.center.centerName;
    }
  }

  public createForm() {
    this.simpleReportForm = this.formBuilder.group({
      id: [0],
      meetingDate: ["", Validators.required],
      meetingId: [0],
      males: [0],
      females: [0],
      children: [0],
      totalAttendance: [0, Validators.required],
      totalAdults: [0],
      newConverts: [0],
      firstTimers: [0],
      testimonies: [0],
      coordinatedBy: [""]
    });
  }

  public patchForm() {
    var datePipe = new DatePipe("en-US");
    const mDate = datePipe.transform(this.report.meetingDate, "dd-MMM-yyyy");
    //console.log(this.report);

    this.simpleReportForm.patchValue({
      id: this.report.id,
      meetingDate: mDate,
      meetingId: this.report.meetingId,
      males: this.report.males,
      females: this.report.females,
      children: this.report.children,
      totalAttendance: this.report.totalAttendance,
      totalAdults: this.report.totalAdults,
      newConverts: this.report.newConverts,
      firstTimers: this.report.firstTimers,
      testimonies: this.report.testimonies,
      coordinatedBy: this.report.coordinatedBy
    });
  }

  public performAction() {
    if (this.pageActionType == ReportPageActionType.Edit) {
      this.updateSimpleReportForm();
    } else if (this.pageActionType == ReportPageActionType.Submit) {
      this.submitSimpleReportForm();
    }
  }

  updateSimpleReportForm() {
    if (this.simpleReportForm.valid) {
      var report: SimpleAttendanceReport = Object.assign(
        {},
        this.simpleReportForm.value
      );

      /*const report: MeetingReportToSubmit = {
        meetingId: this.meetingId,
        meetingAttendance: meeting,
        meetingParticipant: null
      };*/

      /* meeting.meetingDate = this.utilitiesService.createDateAsUTC(
        meeting.meetingDate
      );*/

      this.sweetAlertService.showConfirm("Report will be updated.").then(a => {
        if (a.value) {
          this.loading = true;
          this.reportingServce
            .updateAttendanceReport(this.report.id, report)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((data: ResponseModel) => {
              this.sweetAlertService.showSuccess(data.message);

              //console.log(data);
              // this.submitted = false;
              this.action.emit(report); //<< here you can send object  instead of true
              this.simpleReportForm.reset();
            });
        }
      });
    } else {
      this.sweetAlertService.showMessage(
        "Report Data is not Correct, please check and try again."
      );
    }
  }

  submitSimpleReportForm() {
    // console.log(this.simpleReportForm.value);
    if (this.simpleReportForm.valid) {
      var _meeting: SimpleAttendanceReport = Object.assign(
        {},
        this.simpleReportForm.value
      );

      _meeting.meetingId = this.meetingId;
      _meeting.centerId = this.center.centerId;

      // console.log(_meeting.meetingDate);
      // _meeting.meetingDate = new Date(_meeting.meetingDate);
      // console.log(_meeting.meetingDate);

      //console.log(_meeting.meetingDate);
      //_meeting.meetingDate = new Date(_meeting.meetingDate);
      // console.log(_meeting.meetingDate);

      const report: MeetingReportToSubmit = {
        meetingId: this.meetingId,
        meetingAttendance: _meeting,
        centerId: this.center.centerId,
        meetingParticipant: null,
        meetingReportType: this.meetingReportType,
        meetingDate: _meeting.meetingDate,
        coordinatedBy: _meeting.coordinatedBy
      };

      this.sweetAlertService
        .showConfirm("Report will be submitted.")
        .then(a => {
          if (a.value) {
            this.loading = true;
            this.reportingServce
              .submitAttendanceReport(report)
              .pipe(finalize(() => (this.loading = false)))
              .subscribe((data: ResponseModel) => {
                this.sweetAlertService.showSuccess(data.message);
                this.action.emit(report); //<< here you can send object  instead of true
                //console.log(data);
                // this.submitted = false;
                //this.simpleReportForm.reset();
                this.closeModal();
              });
          }
        });
    }
  }

  public getInt(value: any) {
    return Number.parseInt(value);
  }

  onDatePickerValueChange($event) {}

  public closeModal() {
    //this.action.emit(attendee);
    this.bsModalRef.hide();
  }
}
