import { CenterMemberPostModel } from "./centers.models";
import {
  ReportAnalysisPeriodType,
  ReportAnalysisResultsGroupingType,
  Lookup,
  ReportAnalysisResultsType
} from "./utilities.models";
import { MeetingSection } from "./meetings.models";
import { PrivilegesDialogComponent } from "../components/dialog/privileges-dialog/privileges-dialog.component";

export class SimpleAttendanceReport {
  meetingId: number;
  centerId?: number;
  meetingDate: Date;
  males: number;
  females: number;
  children: number;
  totalAttendance: number;
  totalAdults?: number;
  newConverts: number;
  firstTimers: number;
  testimonies: number;
  coordinatedBy: string;
}

export class MeetingReportToSubmit {
  meetingId: number;
  meetingAttendance?: SimpleAttendanceReport;
  meetingParticipant?: MeetingParticipantGetModel;
  meetingDate?: Date;
  coordinatedBy?: string;
  centerId?: number;
  meetingReportType?: string;
}

export class MeetingParticipantGetModel {
  centerMemberId: number;
  participantStatusId: number;
  meetingId: number;
  fullName: string;
  gender: string;
  phone: string;
  ageGroup: string;
  prefix: string;
  isPresent?: boolean;
  participationStatus: string;
  participationCount: number;
  startDate?: Date;
  completionDate?: Date;
  experiencedHolyGhostBaptism?: boolean;
}

export class MeetingParticipantRecordedAttendance {
  id?: number;
  meetingParticipationStatusId: number;
  centerMemberId: number;
  meetingId: number;
  year?: number;
  meetingDate: Date;
  isPresent?: boolean;
  CoordinatedBy?: string;
}

export class CombinedMeetingRequest {
  id: number;
  meetingType: string;
  theme: string;
  requestNote: string;
  proposedDate: Date;
  hostingCentre: string;
  coordinatedBy: string;
}

export class MeetingDashboardItem {
  id: number;
  name: string;
  description?: string;
  churchSystemId?: number;
  postUrlOnWeb?: string;
  getUrlOnWeb?: string;
  meetingReportType?: string;
  meetingSections?: MeetingSection[];
  privileges?: string[];
  hasOfferings?: boolean;
  holdsInSections?: boolean;
  meetingSectionIdsHavingOfferings?: number[];
}

export class MeetingAttendedByNewCenterMember {
  meetingDate?: Date;
  meetingId?: number;
  meetingCoordinatedBy?: string;
  meetingReportType: string;
  experiencedHolyGhostBaptism: boolean;
}

export class SubmittedReportItem {
  id: number;
  meetingId: number;
  coordinatedBy: string;
  males: number;
  females: number;
  children: number;
  totalAdults: number;
  totalAttendance: number;
  newConverts: number;
  firstTimers: number;
  testimonies: number;
  meetingDate: Date;
  reportedAt: Date;
}

export class ReportFilter {
  periodType: ReportAnalysisPeriodType;
  resultsGroupingType?: ReportAnalysisResultsGroupingType;
  meetingId: number = 0;
  meetingDate?: Date;
  startDate?: Date;
  endDate?: Date;
  previousDataStartDate?: Date;
  status?: string;
  descendantDepthToShow?: number;
  meetingChurchSystemId?: number;
  resultsType?: ReportAnalysisResultsType;
  fromStartTillDate?: boolean = false;
  loadAllMeetingCenters?: boolean = false;
  loadAssignedMeetingsAsReference?: boolean = false;
  meetingSectionId?: number;
  descendantsCenterTypeId?: number;
  //needed for centers drilldown
  userCenterId?: number;
  userCenterTypeId?: number;
  //meetingsIdsAlternative?: string;
}

export class ObjectProperty {
  displayName: string;
  key: string;
  value: any;
  dataPeriodLabel: string;
  valuePrefix: string;
  parentKey: string;
  parentValue: any;
  gParentKey: string;
  gParentValue: any;
  gGParentKey: string;
  gGParentValue: any;
}

/*
export class ReportPivotConfig {
  key: string;
  type: string;
  level: string;
  hierarchy: string;
  parent: string;
  caption: string;
}

export class ReportPivotConfigTransform {
  type?: string;
  level?: string;
  hierarchy?: string;
  parent?: string;
  caption?: string;
}

export class ReportPivotSlicer {
  rows: ReportPivotSlicerKeys;
  columns: ReportPivotSlicerKeys;
  measures: ReportPivotSlicerKeys[];
}

class ReportPivotSlicerKeys {
  uniqueName: string;
  aggregation: string;
}

export class ReportAttendanceAnalysisPivot {
  config: ReportPivotConfig[];
  data: ReportAttendanceAnalysisData[];
  slicer: ReportPivotSlicer;
}

export class ReportAttendanceAnalysisData {
  id: number;
  parentCenterId: number;
  parentCenter: string;
  centerId: number;
  centerName: string;
  centerChartLabel: string;
  contactFullName: string;
  contactPhone: string;
  meetingDate: string;
  day: Date;
  week: number;
  month: string;
  monthYear: string;
  quarter: string;
  year: number;
  displayOrder: number;
  meetingId: number;
  sectionId: number;
  males: number;
  females: number;
  children: number;
  totalAdults: number;
  totalAttendance: number;
  newConverts: number;
  firstTimers: number;
  testimonies: number;
  holyGhostBaptism: number;
  reportedAt: Date;
  isReportingACombinedMeeting: boolean;
  remarks: string;
  coordinatedBy: string;
  offerings: any[];
  createdAt: Date;
  createdBy: string;
}*/

/*
export class ReportAnalysisBaseModel {
  meetingDate: Date;
  week: number;
  month: number;
  monthYear: string;
  quarter: number;
  year: number;
  displayOrder: number;
  meetingId: number;
  sectionId: number;
  reportedAt: Date;
  remarks: string;
  coordinatedBy: string;
  offerings: any[];
  createdAt: Date;
  createdBy: string;
  reportedCenters: number;
}

export class ReportAttendanceAnalysisItem extends ReportAnalysisBaseModel {
  males: number = 0;
  females: number = 0;
  children: number = 0;
  totalAdults: number = 0;
  totalAttendance: number = 0;
  newConverts: number = 0;
  firstTimers: number = 0;
  testimonies: number = 0;
  holyGhostBaptism: number = 0;
  isReportingACombinedMeeting: boolean = false;
  totalSmsReports: number = 0;
}

export class ReportParticipantsAnalysisItem extends ReportAnalysisBaseModel {
  completed: number;
  registered: number;
  started: number;
}

export class OverallParticipantsStatus {
  allCompleted: number;
  allInProgress: number;
  allStarted: number;
  allRegistered: number;
}

export class TotalMeetingCenters {
  allMeetingCenters: number;
  newCenters: number;
  deactivatedCenters: number;
  replicationsDue: number;
  likelyInactiveCenters: number;
}

export class ReportAnalysisDataBaseModel {
  parentCenterId: number;
  parentCenterName: string;
  centerId: number;
  centerAddress: string;
  centerChartLabel: string;
  centerName: string;
  contactFullName: string;
  contactPhone: string;
  totalMeetingCenters: TotalMeetingCenters;
}

export class AnalysisAttendanceCenters extends ReportAnalysisDataBaseModel {
  reports: ReportAttendanceAnalysisItem[];

  // Used only in front
  currentCummulativeReport: ReportAttendanceAnalysisItem;
  previousCummulativeReport: ReportAttendanceAnalysisItem;
  currentReports: ReportAttendanceAnalysisItem[];
  previousReports: ReportAttendanceAnalysisItem[];
}

export class AnalysisParticipantsCenters extends ReportAnalysisDataBaseModel {
  overallParticipationStatus: OverallParticipantsStatus;
  reports: ReportParticipantsAnalysisItem[];
}

export class ReportAnalysisData {
  centersAttendanceReports: AnalysisAttendanceCenters[];
  centersParticipantsReports: AnalysisParticipantsCenters[];
  expectedPeriodKeys: ObjectProperty[];

  //reportsGroupingKeys: string[];
}

export class AnalysisDashboardParams {
  label: string;
  value: number = 0;
  percentage: number = 0;
  description?: string;
  isEmphasized?: boolean = false;
}

export class AnalysisDashboardItems {
  totalMeetingCenters: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalNewCenters: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalDeactivatedCenters: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalReplicationsDue: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalLikelyInactiveCenters: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalCentersWithReports: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalCentersWithNoReports?: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalAdults: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalAttendance: AnalysisDashboardParams = new AnalysisDashboardParams();
  newConverts: AnalysisDashboardParams = new AnalysisDashboardParams();
  firstTimers: AnalysisDashboardParams = new AnalysisDashboardParams();
  testimonies: AnalysisDashboardParams = new AnalysisDashboardParams();
  males: number = 0;
  females: number = 0;
  children: number = 0;
}
*/
