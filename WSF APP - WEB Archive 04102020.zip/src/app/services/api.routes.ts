export class ApiRoutes {
  static church_setups = {
    cities: "church_setup/chuch_cities",
    states: "church_setup/church_states",
    countries: "church_setup/church_countries",
    church_operational_systems: "church_setup/church_operational_systems",
    church_operational_systems_lookup: "church_setup/church_systems/lookup",
    church_operational_systems_assigned_to_manage:
      "church_setup/church_systems/get_assigned_church_systems_to_manage",
    structural_divisions: "church_setup/church_structural_divisions",
    churches: "church_setup/churches",
    church_systems: "church_setup/church_systems",
    center_types: "church_setup/centers_types"
  };

  static approval = {
    approval_requests: "approval/approval_requests",
    approval_types: "approval/approval_types",
    approve_combined_meeting_requests:
      "approval/approve_combined_meeting_requests",
    approve_new_centers: "approval/approve_new_centers",
    approve_testimonies: "approval/approve_testimonies",
    approve_wsf_Update: "approval/approve_wsf_updates"
  };

  static centers = {
    center_members: "centers/center_members",
    centers_types: "centers/center_types",
    download_centers_data: "centers/download_center_data",
    update_centers_data: "centers/update_center_data",
    create_new_center: "centers/create_new_center",
    register_existing_centers: "centers/register_existing_centers",
    centers_locations: "centers/center_locations",
    centers: "centers",
    centers_types_lookup: "church_setup/centers_types/lookup",
    centers_types_lookup_with_default_position_level:
      "church_setup/centers_types/lookup_with_default_position_level",
    get_assigned_centers_types:
      "church_setup/centers_types/get_assigned_centers_types",
    //centers_types_assigned_with_default_position_level:"church_setup/centers_types/centers_types_assigned_with_default_position_level",
    centers_types_church_systems:
      "church_setup/centers_types/get_available_church_systems",
    //find_descendants_centers: "centers/find_descendants_centers",
    search: "centers/search",
    drill_down_centers: "centers/drill_down_centers",
    remove_center: "centers/remove_center",
    //find_any_center: "centers/find_any_center",
    centers_position_holders: "centers/centers_positions_holders",
    get_descendants_counts_per_church_system:
      "centers/get_descendants_counts_per_church_system",
    get_descendants_counts_per_meeting:
      "centers/get_descendants_counts_per_meeting",
    get_parent_centers_list_for_sign_up:
      "centers/get_parent_centers_list_for_sign_up"
  };

  static church_broadcast = {
    materials: "church_broadcast/church_materials",
    materials_categories: "church_broadcast/church_material_categories",
    materials_downloaded: "church_broadcast/church_downloaded_materials",
    posts: "church_broadcast/church_posts",
    posts_categories: "church_broadcast/church_posts_categories",
    posts_read: "church_broadcast/church_posts_read"
  };

  static departments = {
    departments: "department",
    departments_members: "departments/department_members"
  };

  static meetings = {
    meetings: "meetings",
    meetings_sections: "meetings/meetings_sections",
    get_meeting_with_config: "meetings/get_meeting_with_config",
    meetings_absence_reasons: "meetings/meeting_absence_reasons"
    //get_assigned_meetings_list: "meetings/get_assigned_meetings_list"
    //meeting_attendance: "meetings/meeting_attendance",
    //meeting_attendance_sheets: "meetings/meeting_attendance_sheet",
    //combined_meeting_requests: "meetings/combined_meeting_requests",
    //centers_absent_for_a_meeting: "meetings/meeting_centers_absent",
    //centers_in_a_combined_meeting: "meetings/centers_in_a_combined_meeting",
  };

  static position_levels = {
    //position_levels_lookup: "church_setup/position_levels/lookup",
    position_modification_types: "positions/position_modification_types",
    position_levels: "church_setup/position_levels",
    get_position_levels_with_config_data:
      "church_setup/position_levels/get_position_levels_with_config_data",
    get_assigned_position_levels_to_manage:
      "church_setup/position_levels/get_assigned_position_levels_to_manage",
    //position_levels_by_center_type: "church_setup/position_levels/lookup",
    get_assigned_position_levels_to_a_center_type:
      "church_setup/position_levels/get_assigned_position_levels_to_a_center_type",
    get_assigned_position_level_privileges:
      "church_setup/position_levels/get_assigned_position_level_privileges"
  };

  static resources = {
    my_downloads: "resources/my_download",
    my_inbox: "resourcse/my_inbox",
    my_reports: "resources/my_reports",
    my_approvals: "resources/my_approvals",
    resources: "resources",
    resources_categories: "resources/resource_categories",
    //assign_resources: "resources/assign_resources",
    //assign_approvals: "resources/assign_approvals",
    //assign_reports: "resources/assign_reports",
    assignable_resources: "resources/get_assignable_resources",
    get_all_resources: "resources/get_all_resources",
    get_all_meetings_as_resources: "resources/get_all_meetings_as_resources",
    get_all_approvals_list_as_resources:
      "resources/get_all_approvals_list_as_resources",
    resources_sharing_get_assigned_meetings:
      "resources/resources_sharing/get_assigned_meetings",
    //get_resource_assigned_accessors:
    // "resources/resources_sharing/get_resource_assigned_accessors",
    resources_sharing_get_access_privileges:
      "resources/resources_sharing/get_access_privileges",
    //resources_sharing_get_meetings_and_reports_privileges:
    //  "resources/resources_sharing/get_meetings_and_reports_privileges",
    resource_sharing: "resources/resources_sharing",
    resources_sharing_get_all_position_levels_with_assigned_privileges_to_a_resource:
      "resources/resources_sharing/get_all_position_levels_with_assigned_privileges_to_a_resource",
    get_dashboard_items: "resources/resources_sharing/get_dashboard_items"
  };

  static user_account = {
    login: "login",
    sign_up: "users_accounts/sign_up/create_new_account",
    sign_up_verify_otp: "users_accounts/sign_up/verify_otp",
    validate_access_code: "users_accounts/sign_up/validate_access_code",
    sign_up_profiling: "users_accounts/sign_up/sign_up_profiling",
    get_access_codes: "users_accounts/access_codes/get_access_codes",
    profile: "users_accounts/profile",
    update_user_profile_on_login:
      "users_accounts/profile/update_user_profile_on_login",
    get_user_profile_on_login:
      "users_accounts/profile/get_user_profile_on_login",
    center_profile: "users_accounts/center_profile",
    confirm_access_code: "users_accounts/sign_up/confirm_access_code",
    change_password: "users_accounts/password/change_password",
    forgot_password_reset: "users_accounts/password/reset_password",
    forgot_password_verify_otp:
      "users_accounts/password/forgot_password/verify_otp",
    forgot_password_confirm_user_profile:
      "users_accounts/password/forgot_password/confirm_user_profile"
  };

  static follow_up = {
    setup_feedback_parameters: "follow_up/setup_feedback_parameters",
    setup_establishment_parameters: "follow_up/setup_establishment_parameters",
    setup_task_status_parameters: "follow_up/setup_task_status_parameters",
    setup_outreach_operations: "follow_up/setup_outreach_operations",
    setup_communication_platforms: "follow_up/setup_communication_platforms",
    new_converts_and_first_timers: "follow_up",
    //find_new_converts_and_first_timers: "follow_up/find_attendee",
    get_follow_up_data_summary: "follow_up/get_follow_up_data_summary",
    get_follow_up_data_summary_per_center:
      "follow_up/get_follow_up_data_summary_per_center"
  };

  static transportation = {
    transportation: "follow_up/transportation",
    get_loading_hubs: "follow_up/transportation/get_loading_hubs",
    get_loading_points_in_a_hub:
      "follow_up/transportation/get_loading_points_in_a_hub",
    get_loading_points_in_a_central_location:
      "follow_up/transportation/get_loading_points_in_a_central_location",
    get_central_locations: "follow_up/transportation/get_central_locations"
  };

  static sms = {
    sms_messaging: "sms_messaging",
    get_sms_drafts: "sms_messaging/get_sms_drafts",
    save_sms_draft: "sms_messaging/save_sms_draft",
    get_approved_sms_sender_ids: "sms_messaging/get_approved_sms_sender_ids",
    send_sms: "sms_messaging/send_sms",
    delete_sms_drafts: "sms_messaging/delete_sms_drafts"
  };

  static reports = {
    meeting_reports: "meetings/reports",
    update_meeting_report_attendance:
      "meetings/reports/update_meeting_report_attendance",
    delete_meeting_participant_attendance:
      "meetings/reports/delete_meeting_participant_attendance",
    meeting_participants_all:
      "meetings/participants/all_participants_in_a_center",
    meeting_participants_current:
      "meetings/participants/all_current_participants_in_a_center",
    all_attendance_recorded_for_a_participant:
      "meetings/participants/all_attendance_recorded_for_a_participant",
    all_participants_in_current_month:
      "meetings/participants/all_participants_in_current_month",
    //meetings: "meetings",
    //combined_meeting_requests: "meetings/combined_meeting_requests",
    //meetings_list_with_total_attendance:
    // "meetings/reports/meetings_list_with_total_attendance",
    load_submitted_reports: "meetings/reports/get_submitted_reports",
    attendance_report_submitted_for_a_center:
      "attendance_report_submitted_for_a_center",
    get_attendance_analysis_data:
      "meetings/reports/analysis/get_attendance_analysis_data",
    get_participants_analysis_data:
      "meetings/reports/analysis/get_participants_analysis_data",
    get_financial_reports: "meetings/reports/analysis/get_financial_reports",
    get_financial_constants:
      "meetings/reports/analysis/get_financial_constants",
    get_reporting_centers_under_a_role:
      "meetings/reports/get_reporting_centers_under_a_role"
  };

  static testimonies = {
    testimonies: "testimonies",
    get_testimonies_classifications:
      "testimonies/testimonies_classifications/lookup",
    get_paginated_testimonies: "testimonies/get_paginated_testimonies",
    bookmark_testimony: "testimonies/bookmark_testimony",
    approve_testimony: "testimonies/approve_testimony",
    search_testimonies: "testimonies/search_testimonies",
    advance_filter_testimonies: "testimonies/advance_filter_testimonies",
    get_testimonies_reports: "testimonies/get_testimonies_reports",
    get_my_previous_testimonies: "testimonies/get_my_previous_testimonies",
    patch_visibility_status: "testimonies/patch_visibility_status",
    proofread_testimony: "testimonies/proofread_testimony",
    save_new_classification: "testimonies/save_new_classification"

    /* get_all_approved_paginated_testimonies:
      "testimonies/get_all_approved_paginated_testimonies",
    get_all_unapproved_paginated_testimonies:
      "testimonies/get_all_unapproved_paginated_testimonies",
    get_all_active_paginated_testimonies:
      "testimonies/get_all_active_paginated_testimonies",*/
    //get_bookmarked_testimonies:
    //"testimonies/get_bookmarked_testimonies",
    //testimonies_edit_histories: "testimonies/testimonies_edit_histories",
    //starred_testimonies: "testimonies/starred_testimonies"
  };

  static church_publication = {
    publication_category: "publications/publications_categories/lookup",
    publication: "publications",
    publication_download: "publications/download",
    get_paginated_publications: "publications/get_paginated_publications",
    get_publications_timeline_items:
      "publications/get_publications_timeline_items",
    bookmark_publication: "publications/bookmark_publication",
    approve_publication: "publications/approve_publication",
    search_publications: "publications/search_publications",
    get_publications_reports: "publications/get_publications_reports",
    patch_visibility_status: "publications/patch_visibility_status",
    save_new_category: "publications/save_new_category",
    get_previous_publications: "publications/get_previous_publications",
    delete_previous_publication_attachment:
      "publications/delete_previous_publication_attachment"
    //get_bookmarked_publications: "publications/get_bookmarked_publications",
    /*get_all_approved_paginated_publications:
      "publications/get_all_approved_paginated_publications",
    get_all_unapproved_paginated_publications:
      "publications/get_all_unapproved_paginated_publications",
    get_all_active_paginated_publications:
      "publications/get_all_active_paginated_publications",
      */
  };

  static super_user = {
    setup_access_privileges: "/app/setups/2a09F4805c9f7aC8Rmh95e33e64805G95e3",
    setup_access_privileges_code: "2a09F4805c9f7aC8Rmh95e33e64805G95e3"
  };
}
