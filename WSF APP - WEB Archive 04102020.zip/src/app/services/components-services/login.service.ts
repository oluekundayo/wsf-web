import { Injectable } from "@angular/core";
import {
  LoggedInUser,
  LoginDetails,
  NewUserDetails,
  SignUpUserProfiling,
  ForgotPasswordDetails,
  ChangePasswordDetails,
  VerifyUserOtp
} from "../../models/user_account.models";
import { ApiRoutes } from "../api.routes";
import { Observable, of } from "rxjs";
import { delay } from "rxjs/operators";
import { MenuInfo, DashboardItem } from "../../models/menu.models";
import {
  ResponseModel,
  Lookup,
  ApiUrlParam
} from "../../models/utilities.models";
import { APIService } from "../api.service";

@Injectable({
  providedIn: "root"
})
export class LoginService {
  constructor(private api: APIService) {}

  public login(loginDetails: LoginDetails): Observable<LoggedInUser> {
    return this.api.post<LoggedInUser>(
      ApiRoutes.user_account.login,
      loginDetails
    );
    //return of({ token: "jwt", menu: this.getMenu() }).pipe(delay(500));
  }

  public register(userDetails: NewUserDetails): Observable<ResponseModel> {
    return this.api.post<ResponseModel>(
      ApiRoutes.user_account.sign_up,
      userDetails
    );
  }

  public validateAccessCode(
    userDetails: NewUserDetails
  ): Observable<ResponseModel> {
    return this.api.post<ResponseModel>(
      ApiRoutes.user_account.validate_access_code,
      userDetails
    );
  }

  public getDashboardItems(): Observable<DashboardItem[]> {
    return this.api.getAll<DashboardItem[]>(
      ApiRoutes.resources.get_dashboard_items
    );
  }

  public signUpProfiling(): Observable<SignUpUserProfiling> {
    return this.api.find<SignUpUserProfiling>(
      ApiRoutes.user_account.sign_up_profiling
    );
  }

  public getParentCenters(centerTypeId: number): Observable<Lookup[]> {
    //const param = { centerTypeId: centerTypeId };
    return this.api.findWithId<Lookup[]>(
      ApiRoutes.centers.get_parent_centers_list_for_sign_up,
      centerTypeId
    );
  }

  public validateUserProfile(
    password: ForgotPasswordDetails
  ): Observable<ResponseModel> {
    return this.api.post<ResponseModel>(
      ApiRoutes.user_account.forgot_password_confirm_user_profile,
      password
    );
  }

  public verifyOtpForForgotPassword(
    otp: VerifyUserOtp
  ): Observable<ResponseModel> {
    return this.api.post<ResponseModel>(
      ApiRoutes.user_account.forgot_password_verify_otp,
      otp
    );
  }

  public verifyOtpForSignUp(otp: VerifyUserOtp): Observable<ResponseModel> {
    return this.api.post<ResponseModel>(
      ApiRoutes.user_account.sign_up_verify_otp,
      otp
    );
  }

  public resetPassword(
    password: ForgotPasswordDetails
  ): Observable<ResponseModel> {
    return this.api.post<ResponseModel>(
      ApiRoutes.user_account.forgot_password_reset,
      password
    );
  }

  public changePassword(details: ChangePasswordDetails) {
    return this.api.post<ResponseModel>(
      ApiRoutes.user_account.change_password,
      details
    );
  }

  public getMenu(): MenuInfo[] {
    //Menu Items
    return [
      {
        id: 1,
        url: "/app/dashboard",
        name: "Dashboard",
        type: "link",
        icon: "pe-7s-graph"
      },
      {
        id: 2,
        url: "/app/centers",
        name: "Centers",
        type: "sub",
        icon: "pe-7s-plugin",
        children: [
          {
            url: "/app/centers/register-existing-centers",
            name: "Register Existing Centers",
            ab: "RC",
            id: 13,
            type: "link"
          },
          {
            url: "/app/centers/create-new-center",
            name: "Create New Center",
            ab: "CNC",
            id: 14,
            type: "link"
          },
          {
            url: "/app/centers/create-new-center-position-holder",
            name: "Create New User",
            ab: "CNU",
            id: 15,
            type: "link"
          },
          {
            url: "/app/centers/view-registered-centers",
            name: "View Registered Centers",
            ab: "VRC",
            id: 16,
            type: "link"
          },
          {
            url: "/app/centers/find-a-center",
            name: "Find a Center",
            ab: "FaC",
            id: 17,
            type: "link"
          },
          {
            url: "/app/centers/move-center",
            name: "Move a Center",
            ab: "MaC",
            id: 18,
            type: "link"
          },
          {
            url: "/app/centers/remove-center",
            name: "Remove a Center",
            ab: "RaC",
            id: 18,
            type: "link"
          }
        ]
      },
      /*{
        id: 3,
        url: "/app/reports",
        name: "Reports",
        type: "link",
        icon: "pe-7s-graph"
      },
      {
        url: "/app/reports-analysis/view",
        name: "Reports Analysis",
        icon: "pe-7s-graph",
        id: 90,
        type: "link"
      },*/
      {
        id: 670,
        url: "/app/reports",
        name: "Reports",
        type: "sub",
        icon: "pe-7s-graph",
        children: [
          {
            id: 1,
            name: "Submit Reports",
            url: "/app/reports/menu/Submit",
            ab: "SR",
            type: "link"
          },
          /*{
            id: 5,
            name: "Submit Reports for Others",
            url: "/app/reports/delegated-attendance-report",
            ab: "SRO",
            type: "link"
          },*/
          {
            id: 2,
            name: "Reports Summary",
            url: "/app/reports/menu/Analyze",
            ab: "RS",
            type: "link"
          },
          {
            id: 3,
            name: "Financial Reports",
            url: "/app/reports/analysis/financial",
            ab: "FA",
            type: "link"
          }
        ]
      },
      {
        id: 67,
        url: "/app/publications",
        name: "Church Publications",
        type: "sub",
        icon: "pe-7s-graph",
        children: [
          {
            id: 1,
            name: "Read Publications",
            url: "/app/publications/publications",
            ab: "RP",
            type: "link"
          },
          {
            id: 2,
            name: "Send Publications",
            url: "/app/publications/send-out-publications",
            ab: "SP",
            type: "link"
          },
          /*{
            id: 3,
            name: "Approve New Publications",
            url: "/app/publications/publications-report/approval",
            ab: "FT",
            type: "link"
          },*/
          {
            id: 4,
            name: "Reports & Approvals",
            url: "/app/publications/publications-report",
            ab: "RA",
            type: "link"
          }
        ]
      },
      {
        id: 10,
        url: "/app/testimonies",
        name: "Testimonies",
        type: "sub",
        icon: "pe-7s-graph",
        children: [
          {
            id: 1,
            name: "Read Testimonies",
            url: "/app/testimonies/testimonies",
            ab: "RT",
            type: "link"
          },
          {
            id: 2,
            name: "Send your Testimony",
            url: "/app/testimonies/send-testimonies",
            ab: "ST",
            type: "link"
          },
          {
            id: 3,
            name: "Reports & Approvals",
            url: "/app/testimonies/testimonies-report",
            ab: "PR",
            type: "link"
          }
        ]
      },
      {
        id: 678,
        url: "/app/follow-up",
        name: "Follow Up",
        type: "sub",
        icon: "pe-7s-graph",
        children: [
          {
            id: 1,
            name: "Add New Contacts",
            url: "/app/follow-up/register-new-converts",
            ab: "NC",
            type: "link"
          },
          {
            id: 2,
            name: "Contacts List & Reports",
            url: "/app/follow-up/contact-new-converts",
            ab: "MC",
            type: "link"
          }
        ]
      },
      {
        id: 6799,
        url: "/app/transportation-system",
        name: "Transportation System",
        type: "sub",
        icon: "pe-7s-graph",
        children: [
          {
            id: 1,
            name: "View Loading Bays",
            url: "/app/transportation-system/view-loading-bays",
            ab: "LB",
            type: "link"
          },
          {
            id: 2,
            name: "Create Loading Bays",
            url: "/app/transportation-system/create-loading-bays",
            ab: "CL",
            type: "link"
          }
        ]
      },
      {
        id: 69,
        url: "/app/super-admin",
        name: "Church Admin",
        type: "sub",
        icon: "pe-7s-graph",
        children: [
          {
            id: 2,
            name: "Forward Access Codes",
            url: "/app/user-account/forward-access-codes",
            ab: "FA",
            type: "link"
          },
          {
            id: 3,
            name: "Setup Roles",
            url: "/app/setups/manage-position-levels",
            ab: "MU",
            type: "link"
          },
          {
            id: 1,
            name: "Setup Roles' Access",
            url: "/app/setups/manage-privileges",
            ab: "AR",
            type: "link"
          }
        ]
      },
      {
        id: 690,
        url: "/app/setups",
        name: "Super User",
        type: "sub",
        icon: "pe-7s-graph",
        children: [
          {
            id: 4,
            name: "Setup Center Types",
            url: "/app/setups/setup-center-types",
            ab: "CT",
            type: "link"
          },
          {
            id: 1,
            name: "Setup Resources",
            url: "/app/setups/setup-resources",
            ab: "SR",
            type: "link"
          },
          {
            id: 3,
            name: "Setup Meetings",
            url: "/app/setups/setup-meetings",
            ab: "SM",
            type: "link"
          },
          {
            id: 4,
            name: "Setup Roles",
            url: "/app/setups/manage-position-levels",
            ab: "PL",
            type: "link"
          },
          {
            id: 2,
            name: "Setup Roles' Access",
            url: ApiRoutes.super_user.setup_access_privileges, //"/app/resources/2a09F4805c9f7aC8Rmh95e33e64805G95e3",
            ab: "MP",
            type: "link"
          }
        ]
      }
      /*{
        id: 632,
        url: "/app/super-user",
        name: "Super User",
        type: "sub",
        icon: "pe-7s-graph",
        children: [
          {
            id: 1,
            name: "Church Divisions",
            url: "/app/church-publications/read-publications",
            ab: "FT",
            type: "link"
          },
          {
            id: 2,
            name: "Center Types",
            url: "/app/church-publications/send-out-publications",
            ab: "FT",
            type: "link"
          }
        ]
      },*/
      /*{
        id: 4,
        name: "Church Websites",
        type: "sub",
        url: "/dummy_url",
        icon: "pe-7s-plugin",
        children: [
          {
            id: 1,
            name: "Faith Tabernacle",
            url: "http://appsdesk.com.ng",
            ab: "FT",
            type: "external"
          },
          {
            id: 2,
            name: "Domi Radio",
            url: "pages-register",
            ab: "DR",
            type: "external"
          },
          {
            id: 3,
            name: "Dominion Bookstore",
            url: "pages-404",
            ab: "DB",
            type: "external"
          },
          {
            id: 4,
            name: "Pastor Faith Oyedepo",
            url: "pages-500",
            ab: "PFO",
            type: "external"
          }
        ]
      }*/
    ];
  }
}
