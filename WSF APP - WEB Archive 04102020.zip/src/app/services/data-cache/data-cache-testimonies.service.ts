import { Injectable } from "@angular/core";
import {
  Testimony,
  PaginatedTestimonies
} from "../../models/testimonies.models";
import { find } from "lodash";
import {
  DataCacheMode,
  PaginatorFilter,
  PageDirection
} from "../../models/utilities.models";

import { cloneDeep } from "lodash";

@Injectable({
  providedIn: "root"
})
export class DataCacheTestimoniesService {
  PAGE_SIZE: number = 20;
  CURRENT_PAGE: number = 0;
  ITEMS_TO_SHOW: number = 5;

  private cachedBookmarkedTestimonies: PaginatedTestimonies;
  private cachedApprovedTestimonies: PaginatedTestimonies;
  private cachedDisapprovedTestimonies: PaginatedTestimonies;
  private cachedUnapprovedTestimonies: PaginatedTestimonies;
  private cachedNotVisibleTestimonies: PaginatedTestimonies;
  private cachedFilteredTestimonies: Testimony[];
  private lastSelectedPageMode: DataCacheMode;

  constructor() {
    this.initCache();
    //console.log("AM CALLED AGAIN. WHY");
  }

  public getTestimonies(mode: DataCacheMode): Testimony[] {
    let pub: Testimony[];

    if (mode == DataCacheMode.Approved) {
      pub = this.cachedApprovedTestimonies.testimonies;
    } else if (mode == DataCacheMode.Unapproved) {
      pub = this.cachedUnapprovedTestimonies.testimonies;
    } else if (mode == DataCacheMode.Disapproved) {
      pub = this.cachedDisapprovedTestimonies.testimonies;
    } else if (mode == DataCacheMode.Bookmarked) {
      pub = this.cachedBookmarkedTestimonies.testimonies;
    } else if (mode == DataCacheMode.NotVisible) {
      pub = this.cachedNotVisibleTestimonies.testimonies;
    } else if (mode == DataCacheMode.Search) {
      pub = this.cachedFilteredTestimonies;
    }

    return pub;
  }

  public cacheTestimonies(mode: DataCacheMode, response: PaginatedTestimonies) {
    this.lastSelectedPageMode = mode;

    if (mode == DataCacheMode.Approved) {
      this.updateCache(this.cachedApprovedTestimonies, response);
    } else if (mode == DataCacheMode.Unapproved) {
      this.updateCache(this.cachedUnapprovedTestimonies, response);
    } else if (mode == DataCacheMode.Disapproved) {
      this.updateCache(this.cachedDisapprovedTestimonies, response);
    } else if (mode == DataCacheMode.Bookmarked) {
      this.updateCache(this.cachedBookmarkedTestimonies, response);
    } else if (mode == DataCacheMode.NotVisible) {
      this.updateCache(this.cachedNotVisibleTestimonies, response);
    }

    return response.paginator;
  }

  public cacheFilteredTestimonies(mode: DataCacheMode, response: Testimony[]) {
    this.lastSelectedPageMode = mode;
    this.cachedFilteredTestimonies = response;
  }

  private updateCache(
    cacheData: PaginatedTestimonies,
    newData: PaginatedTestimonies
  ) {
    cacheData.testimonies.push(...newData.testimonies);
    cacheData.paginator.lastMaxId = newData.paginator.lastMaxId;
    cacheData.paginator.lastMaxId = newData.paginator.lastMaxId;
    cacheData.paginator.lastMaxDate = newData.paginator.lastMaxDate;
    cacheData.paginator.lastMinDate = newData.paginator.lastMinDate;
    cacheData.paginator.totalItemsCount = newData.paginator.totalItemsCount;
  }

  private initCache() {
    const page: PaginatorFilter = new PaginatorFilter();
    page.pageSize = this.PAGE_SIZE;
    page.direction = PageDirection.NEXT;
    // page.currentPage = this.CURRENT_PAGE;
    // page.noItemsToShow = this.ITEMS_TO_SHOW;

    const pub: PaginatedTestimonies = {
      paginator: Object.assign({}, page),
      testimonies: []
    };

    this.cachedApprovedTestimonies = cloneDeep(pub);
    this.cachedUnapprovedTestimonies = cloneDeep(pub);
    this.cachedDisapprovedTestimonies = cloneDeep(pub);
    this.cachedBookmarkedTestimonies = cloneDeep(pub);
    this.cachedNotVisibleTestimonies = cloneDeep(pub);
    this.cachedFilteredTestimonies = [];

    this.lastSelectedPageMode = DataCacheMode.Approved;
  }

  public getPaginator(mode: DataCacheMode): PaginatorFilter {
    if (mode == DataCacheMode.Approved) {
      return this.cachedApprovedTestimonies.paginator;
    } else if (mode == DataCacheMode.Unapproved) {
      return this.cachedUnapprovedTestimonies.paginator;
    } else if (mode == DataCacheMode.Disapproved) {
      return this.cachedDisapprovedTestimonies.paginator;
    } else if (mode == DataCacheMode.Bookmarked) {
      return this.cachedBookmarkedTestimonies.paginator;
    } else if (mode == DataCacheMode.NotVisible) {
      return this.cachedNotVisibleTestimonies.paginator;
    }
  }

  private resetPaginatorFilter(
    cacheData: PaginatorFilter,
    newData: PaginatorFilter
  ) {
    cacheData.lastMaxId = newData.lastMaxId;
    cacheData.lastMaxId = newData.lastMaxId;
    cacheData.lastMaxDate = newData.lastMaxDate;
    cacheData.lastMinDate = newData.lastMinDate;
    cacheData.totalItemsCount = newData.totalItemsCount;
  }

  public updatePaginator(mode: DataCacheMode, paginator: PaginatorFilter) {
    if (mode == DataCacheMode.Approved) {
      //this.cachedApprovedTestimonies.paginator = paginator;
      this.resetPaginatorFilter(
        this.cachedApprovedTestimonies.paginator,
        paginator
      );
    } else if (mode == DataCacheMode.Unapproved) {
      //this.cachedUnapprovedTestimonies.paginator = paginator;
      this.resetPaginatorFilter(
        this.cachedUnapprovedTestimonies.paginator,
        paginator
      );
    } else if (mode == DataCacheMode.Disapproved) {
      //this.cachedDisapprovedTestimonies.paginator = paginator;
      this.resetPaginatorFilter(
        this.cachedDisapprovedTestimonies.paginator,
        paginator
      );
    } else if (mode == DataCacheMode.Bookmarked) {
      // this.cachedBookmarkedTestimonies.paginator = paginator;
      this.resetPaginatorFilter(
        this.cachedBookmarkedTestimonies.paginator,
        paginator
      );
    } else if (mode == DataCacheMode.NotVisible) {
      //this.cachedNotVisibleTestimonies.paginator = paginator;
      this.resetPaginatorFilter(
        this.cachedNotVisibleTestimonies.paginator,
        paginator
      );
    }
  }

  public setLastSelectedPageMode(pageListMode: DataCacheMode) {
    this.lastSelectedPageMode = pageListMode;
  }

  public getLastSelectedPageMode(): DataCacheMode {
    return this.lastSelectedPageMode;
  }
}
