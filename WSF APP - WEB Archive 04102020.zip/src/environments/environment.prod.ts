export const environment = {
  production: true,
  logToConsole: false,
  API_BASE_URL: "https://wsfportal.lfcww.org/api/v1",
  //API_BASE_URL: "https://wsfapi.appsdesk.com.ng/api/v1",
  //API_BASE_URL: "https://wsfapi-beta.appsdesk.com.ng/api/v1",
  APP_VERSION: "1.0.0",
  APP_TYPE: "web"
};
