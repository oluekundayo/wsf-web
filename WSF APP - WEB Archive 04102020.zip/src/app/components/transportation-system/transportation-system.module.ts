import { NgModule } from "@angular/core";
import { SharedModule } from "../../app.shared.module";
import { LoadingBaysComponent } from "./loading-bays/loading-bays.component";
import { CreateLoadingBaysComponent } from "./create-loading-bays/create-loading-bays.component";
import { TransportationSystemRoutingModule } from "./transportation-system-routing.module";
import { TimeFormatPipe } from "../../pipes/time-format.pipe";

@NgModule({
  imports: [SharedModule, TransportationSystemRoutingModule],
  declarations: [
    LoadingBaysComponent,
    CreateLoadingBaysComponent,
    TimeFormatPipe
  ]
})
export class TransportationSystemModule {}
