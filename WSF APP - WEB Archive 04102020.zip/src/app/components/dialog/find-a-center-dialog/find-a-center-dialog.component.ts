import { finalize } from "rxjs/operators";
import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy
} from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import { Lookup, ApiUrlParam } from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import {
  CenterSearchResult,
  CenterSearchParams
} from "../../../models/centers.models";
import { BsModalRef } from "ngx-bootstrap/modal";
import {
  trigger,
  transition,
  animate,
  style,
  state
} from "@angular/animations";

@Component({
  selector: "app-find-a-center-dialog",
  templateUrl: "./find-a-center-dialog.component.html",
  styleUrls: ["./find-a-center-dialog.component.css"]
})
export class FindACenterDialogComponent implements OnInit, OnDestroy {
  loading = false;
  centerTypes: Observable<Lookup[]>;
  formGroup: FormGroup;
  centerTypePositionLevels: Observable<Lookup[]>;
  centerFinderResults: CenterSearchResult[] = [];
  selectedCenterTypeId: number = 0;
  limitClosureToDepth: number = 1;
  //returnAncestorsCenterTypes: boolean = false;
  noResultsFound: boolean = false;
  //_includePositionHolderInSearch = false;
  //includePHInSearchSubscription: Subscription;

  @Output() action = new EventEmitter();

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    public bsModalRef: BsModalRef
  ) {
    this.formGroup = fb.group({
      centerTypeId: [0, Validators.required],
      searchByAddress: [""],
      searchByMinister: [""],
      limitSearchToDescendants: true,
      limitSearchToACenterType: true
    });
  }

  ngOnInit() {
    this.loading = true;
    this.centerTypes = this.api
      .getAll<Lookup[]>(
        ApiRoutes.centers.centers_types_lookup +
          "/" +
          this.selectedCenterTypeId +
          "/" +
          this.limitClosureToDepth
      )
      .pipe(finalize(() => (this.loading = false)));
    // + "/" + this.returnAncestorsCenterTypes
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
  }

  public findACenter() {
    const finder: CenterSearchParams = this.formGroup.value;

    if (finder == null) {
      alert("Search Criteria not valid.");
      return;
    }

    this.loading = true;
    this.api
      .post<CenterSearchResult[]>(ApiRoutes.centers.search, finder)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.noResultsFound = !response || response.length < 1 ? true : false;
        this.centerFinderResults = response;
      });
  }

  public onCenterTypeChange(selectedType: number) {
    //console.log(this.findPositionHolderValue);

    if (selectedType) {
      const param: ApiUrlParam = new ApiUrlParam();
      param.name = "centerTypeId";
      param.value = selectedType + "";

      //const params: ApiUrlParam[] = [{ name: "centerTypeId", value: 2 }];

      this.loading = true;
      this.centerTypePositionLevels = this.api
        .getAll<Lookup[]>(
          ApiRoutes.position_levels
            .get_assigned_position_levels_to_a_center_type,
          [param]
        )
        .pipe(finalize(() => (this.loading = false)));
    }
  }

  public passSelectedCenter(center: CenterSearchResult) {
    //console.log(center);
    this.action.emit(center);
    this.bsModalRef.hide();
  }

  ngOnDestroy(): void {}
}
