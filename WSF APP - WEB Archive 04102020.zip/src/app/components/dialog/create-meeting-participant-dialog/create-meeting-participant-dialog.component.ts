import { finalize } from "rxjs/operators";
import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy
} from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import {
  Lookup,
  ApiUrlParam,
  ResponseModel,
  CenterMemberShipStatus
} from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { CenterMemberPostModel } from "../../../models/centers.models";
import { BsModalRef } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import {
  MeetingParticipantGetModel,
  MeetingReportToSubmit,
  MeetingDashboardItem,
  MeetingAttendedByNewCenterMember
} from "../../../models/reporting.models";
import { FollowUpService } from "../../../services/components-services/followup.service";
import { ReportingService } from "../../../services/components-services/reporting.service";

@Component({
  selector: "app-create-meeting-participant-dialog",
  templateUrl: "./create-meeting-participant-dialog.component.html",
  styleUrls: ["./create-meeting-participant-dialog.component.scss"]
})
export class CreateMeetingParticipantDialogComponent
  implements OnInit, OnDestroy {
  loading = false;
  formGroup: FormGroup;
  genderList: string[] = [];
  ageGroupList: string[] = [];
  prefixList: string[] = [];
  memberShipStatus: CenterMemberShipStatus;
  meeting: MeetingDashboardItem;
  //markParticipantAttendanceAsPresent: boolean = false;

  @Output() action = new EventEmitter<MeetingParticipantGetModel>();

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    public bsModalRef: BsModalRef,
    private reportingService: ReportingService,
    private sweetAlertService: SweetAlertService
  ) {}

  ngOnInit() {
    this.prefixList = ["Pastor", "Elder", "Dcn.", "Dcns.", "Bro.", "Sis."];
    this.genderList = ["Male", "Female"];
    this.ageGroupList = ["Adult", "Child"];

    this.createForm();
  }

  private createForm() {
    this.formGroup = this.fb.group({
      //membershipType: ["", Validators.required],
      personalDetails: this.fb.group({
        prefix: [""],
        lastname: ["", Validators.required],
        firstname: ["", Validators.required],
        otherName: [""],
        gender: [""],
        address: [""],
        phone: [""],
        email: [""],
        ageGroup: [""]
      }),
      churchDetails: this.fb.group({
        joinedCenterAt: [""],
        convertedAt: [""]
      }),
      invitedBy: this.fb.group({
        fullName: [""],
        phone: [""],
        email: [""],
        address: [""]
      }),
      meetingAttended: this.fb.group({
        meetingDate: ["", Validators.required],
        meetingId: [this.meeting.id, Validators.required],
        meetingCoordinatedBy: [""],
        experiencedHolyGhostBaptism: [false]
      })
    });

    console.log(this.formGroup);
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
  }

  public submitRecord() {
    if (this.formGroup.valid) {
      //const membershipType = this.formGroup.get("membershipType").value;
      const member = Object.assign(
        {},
        this.formGroup.value
      ) as CenterMemberPostModel;

      member.membershipStatus = this.memberShipStatus;
      member.meetingAttended = {
        meetingId: this.meeting.id,
        meetingDate: this.meetingDate,
        meetingCoordinatedBy: this.meetingCoordinatedBy,
        meetingReportType: this.meeting.meetingReportType,
        experiencedHolyGhostBaptism: this.experiencedHolyGhostBaptism
      } as MeetingAttendedByNewCenterMember;

      this.sweetAlertService
        .showConfirm("New Record will be saved.")
        .then(a => {
          if (a.value) {
            this.loading = true;
            this.reportingService
              .createParticipant(member)
              .pipe(finalize(() => (this.loading = false)))
              .subscribe((response: ResponseModel) => {
                if (response.isOk) {
                  // this.formGroup.reset();
                  //this.resetForm();
                  //console.log(response.data);
                  this.sweetAlertService.showSuccess(response.message);
                  this.closeModal(response.data);
                }
              });
          }
        });
    }
  }

  public resetForm() {
    this.formGroup.patchValue({
      membershipType: "",
      personalDetails: {
        prefix: "",
        lastname: "",
        firstname: "",
        otherName: "",
        gender: "",
        address: "",
        phone: "",
        email: "",
        ageGroup: ""
      },
      invitedBy: {
        fullName: "",
        phone: "",
        email: "",
        address: ""
      },
      meetingAttended: {
        meetingDate: "",
        meetingId: this.meeting.id,
        meetingCoordinatedBy: "",
        experiencedHolyGhostBaptism: false
      }
    });
  }

  public closeModal(attendee: MeetingParticipantGetModel) {
    this.action.emit(attendee);
    this.bsModalRef.hide();
  }

  private get meetingDate() {
    return this.formGroup.get("meetingAttended").value.meetingDate as Date;
  }

  private get meetingCoordinatedBy() {
    return this.formGroup.get("meetingAttended").value
      .meetingCoordinatedBy as string;
  }

  private get experiencedHolyGhostBaptism() {
    return this.formGroup.get("meetingAttended").value
      .experiencedHolyGhostBaptism as boolean;
  }

  ngOnDestroy(): void {}
}
