## [1.3.0] 2018-09-06
### Fixes
- update Angular to 6.1.6
- fixed modal on responsive
- fixed scss problem with nghost
- changed the tags style

## [1.2.1] 2017-09-21
- Update Angular to 4.3.1
- Update @angular/cli to 1.4.2
- fixed nouislider bug
- autocompile sass

## [1.2.0] 2017-07-28
- Update to Angular CLI structure
- Update to Angular v4.x.x
- Added Angular Modules for:
   - Switches
   - Maps
   - Tags
   - Sliders  

## [1.0.1] 2017-03-21
- Added "@types/core-js": "0.9.35" in package.json

## [1.0.0] 2017-03-01
- Added Sketch Files

## [1.0.0] 2017-02-22
- Initial Release
