import { Component, OnInit, TemplateRef } from "@angular/core";
import { CenterType, PositionLevel } from "../../../models/centers.models";
import { Observable } from "rxjs";
import { finalize } from "rxjs/operators";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import {
  AssignableResource,
  AssignableResourceGroup
} from "../../../models/resources.models";
import { filter, includes, map } from "lodash";

import { PrivilegesDialogComponent } from "../../dialog/privileges-dialog/privileges-dialog.component";
import { ResourcesSetupDialogComponent } from "../../dialog/resources-setup-dialog/resources-setup-dialog.component";
import { Meeting } from "../../../models/meetings.models";
import {
  Lookup,
  AppResourceType,
  ResponseModel
} from "../../../models/utilities.models";

@Component({
  selector: "app-manage-position-levels",
  templateUrl: "./manage-position-levels.component.html",
  styleUrls: ["./manage-position-levels.component.scss"]
})
export class ManagePositionLevelsComponent implements OnInit {
  bsModalRef: BsModalRef;
  loading: boolean = false;
  allPositionLevels: PositionLevel[] = [];
  allCenterTypes: Lookup[] = [];
  allChurchSystems: Lookup[] = [];
  formGroup: FormGroup;
  currentSelectedIndex: number = 0;

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    private modalService: BsModalService,
    private sweetAlertService: SweetAlertService
  ) {
    this.createFormGroup();
  }

  ngOnInit() {
    this.loadAllPositionLevels();
    this.getAllCenterTypes();
    this.getAllChurchSystems();
  }

  private createFormGroup() {
    this.formGroup = this.fb.group({
      id: [0, Validators.required],
      centerTypeId: [0, Validators.required],
      name: ["", Validators.required],
      description: [""],
      orderBy: [0, Validators.required],
      assignedCenterTypesToManage: [null],
      assignedPositionLevelsToManage: [null],
      assignedChurchSystemsToManage: [null],
      isCentersContactLevel: [false],
      showOnSignUp: [false],
      alternativeCodeForSignUp: [""],
      isDefaultLevel: [false],
      hasSameCenterTypeWithCurrentUser: [false]
    });
  }

  private loadAllPositionLevels() {
    this.loading = true;
    this.api
      .getAll<PositionLevel[]>(
        ApiRoutes.position_levels.get_position_levels_with_config_data
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        // console.log(response);
        this.allPositionLevels = response;
      });
  }

  private patchFormGroup(level: PositionLevel) {
    this.formGroup.patchValue({
      id: level.id,
      centerTypeId: level.centerTypeId,
      name: level.name,
      description: level.description,
      orderBy: level.orderBy,

      assignedCenterTypesToManage: filter(this.allCenterTypes, (a: Lookup) => {
        return includes(level.assignedCenterTypesToManage, a.id);
      }),

      assignedPositionLevelsToManage: filter(
        this.allPositionLevels,
        (a: Lookup) => {
          return includes(level.assignedPositionLevelsToManage, a.id);
        }
      ),

      assignedChurchSystemsToManage: filter(
        this.allChurchSystems,
        (a: Lookup) => {
          return includes(level.assignedChurchSystemsToManage, a.id);
        }
      ),

      isCentersContactLevel: level.isCentersContactLevel,
      showOnSignUp: level.showOnSignUp,
      alternativeCodeForSignUp: level.alternativeCodeForSignUp,
      isDefaultLevel: level.isDefaultLevel
    });
  }

  public getAllCenterTypes() {
    this.loading = true;
    this.api
      .getAll<Lookup[]>(ApiRoutes.centers.centers_types_lookup)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.allCenterTypes = response;
      });
  }

  public getAllChurchSystems() {
    this.loading = true;
    this.api
      .getAll<Lookup[]>(
        ApiRoutes.church_setups.church_operational_systems_lookup
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.allChurchSystems = response;
      });
  }

  openModal(
    template: TemplateRef<any>,
    positionLevel: PositionLevel,
    currentSelectedIndex: number
  ) {
    this.currentSelectedIndex = currentSelectedIndex;

    if (positionLevel) {
      this.patchFormGroup(positionLevel);
    } else {
      this.createFormGroup();
    }
    this.bsModalRef = this.modalService.show(template, {
      backdrop: true,
      ignoreBackdropClick: true
    });
    // (click)="periodTypeSelected('Custom')"
  }

  save() {
    if (this.formGroup.valid) {
      const id: number = this.formGroup.value.id;
      if (id == 0) {
        this.saveNew();
      } else {
        this.saveUpdate(id);
      }
    }
  }

  saveNew() {
    this.loading = true;
    this.api
      .post<ResponseModel>(
        ApiRoutes.position_levels.position_levels,
        this.getPositionLevelInstance()
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.allPositionLevels.push(this.formGroup.value as PositionLevel);
        this.sweetAlertService.showSuccess(response.message);
        this.bsModalRef.hide();
      });
  }

  saveUpdate(id: number) {
    const level = this.getPositionLevelInstance();
    this.loading = true;
    // console.log(this.formGroup.value);
    this.api
      .put<ResponseModel>(ApiRoutes.position_levels.position_levels, id, level)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.sweetAlertService.showSuccess(response.message);
        this.allPositionLevels[this.currentSelectedIndex] = level;
        this.bsModalRef.hide();
      });
  }

  getPositionLevelInstance(): PositionLevel {
    const level = new PositionLevel();
    level.id = this.formGroup.value.id;
    level.centerTypeId = this.formGroup.value.centerTypeId;
    level.name = this.formGroup.value.name;
    level.description = this.formGroup.value.description;
    level.orderBy = this.formGroup.value.orderBy;
    level.assignedCenterTypesToManage = map(
      this.formGroup.value.assignedCenterTypesToManage,
      (a: Lookup) => {
        return a.id;
      }
    );
    level.assignedPositionLevelsToManage = map(
      this.formGroup.value.assignedPositionLevelsToManage,
      (a: Lookup) => {
        return a.id;
      }
    );
    level.assignedChurchSystemsToManage = map(
      this.formGroup.value.assignedChurchSystemsToManage,
      (a: Lookup) => {
        return a.id;
      }
    );
    level.isCentersContactLevel = this.formGroup.value.isCentersContactLevel;
    level.showOnSignUp = this.formGroup.value.showOnSignUp;
    level.alternativeCodeForSignUp = this.formGroup.value.alternativeCodeForSignUp;
    level.isDefaultLevel = this.formGroup.value.isDefaultLevel;

    return level;
  }
}
