import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { NgSelectModule } from "@ng-select/ng-select";

// Import 3rd party components
import { BsDropdownModule } from "ngx-bootstrap/dropdown";
import { TabsModule } from "ngx-bootstrap/tabs";
//import { ChartsModule } from "ng2-charts/ng2-charts";
import { HttpClientModule } from "@angular/common/http";
//import { DialogModule } from "./NgExDialog/dialog.module";

import { ModalModule as BsModalModule } from "ngx-bootstrap/modal";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";
import { NgxLoadingModule } from "ngx-loading";

import { ManagePrivilegesComponent } from "./components/setups/manage-privileges/manage-privileges.component";
import { PrivilegesDialogComponent } from "./components/dialog/privileges-dialog/privileges-dialog.component";
import { NgBootstrapFormValidationModule } from "ng-bootstrap-form-validation";
import { NgxPaginationModule } from "ngx-pagination";
import { MomentModule } from "ngx-moment";
import { ReportsFilterComponent } from "./components/reports/analysis-and-summary/reports-filter/reports-filter.component";
import { AdvancedSearchComponent } from "./components/utilities/advanced-search/advanced-search.component";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    BsDatepickerModule,
    NgxLoadingModule.forRoot({
      primaryColour: "#B22222",
      secondaryColour: "#B22222",
      tertiaryColour: "#B22222"
      //fullScreenBackdrop: true
    }),
    NgSelectModule,
    HttpClientModule,
    TabsModule.forRoot(),
    BsModalModule.forRoot(),
    NgBootstrapFormValidationModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    MomentModule
  ],
  declarations: [
    PrivilegesDialogComponent,
    ReportsFilterComponent,
    AdvancedSearchComponent
  ],
  exports: [
    CommonModule,
    FormsModule,
    BsModalModule,
    BsDatepickerModule,
    ReactiveFormsModule,
    NgxLoadingModule,
    NgSelectModule,
    HttpClientModule,
    NgBootstrapFormValidationModule,
    TabsModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    MomentModule,
    ReportsFilterComponent,
    AdvancedSearchComponent
  ]
})
export class SharedModule {}
