import { finalize } from "rxjs/operators";
import {
  Component,
  OnInit,
  Output,
  // EventEmitter,
  OnDestroy,
  ViewChild
} from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import {
  Lookup,
  ApiUrlParam,
  ResponseModel,
  ReadOnlyItemsGroup,
  CenterMemberShipStatus,
  CenterMemberConversionStatus
} from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { CenterMemberPostModel } from "../../../models/centers.models";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { TabsetComponent, TabDirective } from "ngx-bootstrap/tabs";
import { UserProfile } from "../../../models/user_account.models";
import { UserAccountService } from "../../../services/components-services/user-account.service";

import * as moment from "moment";
import { FollowUpService } from "../../../services/components-services/followup.service";
import { Router } from "@angular/router";
import { UtilitiesService } from "../../../services/utils/utilities.service";

@Component({
  selector: "app-register-new-converts",
  templateUrl: "./register-new-converts.component.html",
  styleUrls: ["./register-new-converts.component.scss"]
})
export class RegisterNewConvertsComponent implements OnInit, OnDestroy {
  loading = false;
  formGroup: FormGroup;
  genderList: string[] = [];
  ageGroupList: string[] = [];
  prefixList: string[] = [];
  centerMember: CenterMemberPostModel;
  meetingList$: Observable<Lookup[]>;

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    private router: Router,
    private followUpService: FollowUpService,
    private sweetAlertService: SweetAlertService,
    private utilitiesService: UtilitiesService
  ) {}
  ngOnInit() {
    this.prefixList = ["Pastor", "Elder", "Dcn.", "Dcns.", "Bro.", "Sis."];
    this.genderList = ["Male", "Female"];
    this.ageGroupList = ["Adult", "Child"];

    this.createForm();
    this.loadMeetings();
  }

  private createForm() {
    this.formGroup = this.fb.group({
      memberConversionType: ["", Validators.required],
      personalDetails: this.fb.group({
        prefix: [""],
        lastname: ["", Validators.required],
        firstname: ["", Validators.required],
        otherName: [""],
        gender: [""],
        address: [""],
        phone: [""],
        email: [""],
        ageGroup: [""]
        //joinedCenterAt: [null],
        //convertedAt: [null]
      }),
      churchDetails: this.fb.group({
        wofbiStatus: [""],
        wofbiStatusDate: [null]
      }),
      invitedBy: this.fb.group({
        fullName: [""],
        phone: [""],
        email: [""],
        address: [""]
      }),
      meetingAttended: this.fb.group({
        meetingDate: [null, Validators.required],
        meetingId: [0, Validators.required],
        meetingCoordinatedBy: [""]
      })
    });
  }

  private loadMeetings() {
    this.meetingList$ = this.followUpService.getAssignedMeetingsToSubmit();
    /*.subscribe(response=> {
      this.meetingList = response;
    })
    */
  }

  public submitRecord() {
    if (this.formGroup.valid) {
      const memberConversionType = this.formGroup.get("memberConversionType")
        .value;

      const member = Object.assign(
        {},
        this.formGroup.value
      ) as CenterMemberPostModel;

      member.meetingAttended.meetingDate = this.utilitiesService.createDateAsUTC(
        member.meetingAttended.meetingDate
      );

      if (memberConversionType == "IsFirstTimer") {
        member.memberConversionStatus = CenterMemberConversionStatus.FirstTimer;
      } else if (memberConversionType == "IsNewConvert") {
        member.memberConversionStatus = CenterMemberConversionStatus.NewConvert;
      }

      member.membershipStatus = CenterMemberShipStatus.CenterMember;
      //console.log(member);

      this.sweetAlertService
        .showConfirm("New Record will be saved.")
        .then(a => {
          if (a.value) {
            this.loading = true;
            this.followUpService
              .saveNewConvert(member)
              .pipe(finalize(() => (this.loading = false)))
              .subscribe((response: ResponseModel) => {
                if (response.isOk) {
                  // this.formGroup.reset();
                  this.resetForm();
                  this.sweetAlertService.showSuccess(
                    "Record saved successfully."
                  );
                }
              });
          }
        });
    }
  }

  public resetForm() {
    this.formGroup.patchValue({
      memberConversionType: "",
      personalDetails: {
        prefix: "",
        lastname: "",
        firstname: "",
        otherName: "",
        gender: "",
        address: "",
        phone: "",
        email: "",
        ageGroup: ""
      },
      churchDetails: {
        //joinedCenterAt: null,
        //convertedAt: null,
        wofbiStatus: "",
        wofbiStatusDate: null
      },
      invitedBy: {
        fullName: "",
        phone: "",
        email: "",
        address: ""
      },
      meetingAttended: {
        meetingDate: null,
        meetingId: 0,
        meetingCoordinatedBy: ""
      }
    });
  }

  public navigateToList() {
    this.router.navigate(["app/follow-up/contact-new-converts"]);
  }

  ngOnDestroy(): void {}
}
