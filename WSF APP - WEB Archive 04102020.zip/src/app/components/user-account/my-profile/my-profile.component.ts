import { finalize } from "rxjs/operators";
import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy,
  ViewChild
} from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import {
  Lookup,
  ApiUrlParam,
  ResponseModel,
  ReadOnlyItemsGroup
} from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { TabsetComponent, TabDirective } from "ngx-bootstrap/tabs";
import { UserProfile } from "../../../models/user_account.models";
import { UserAccountService } from "../../../services/components-services/user-account.service";

import * as moment from "moment";

@Component({
  selector: "app-my-profile",
  templateUrl: "./my-profile.component.html",
  styleUrls: ["./my-profile.component.scss"]
})
export class MyProfileComponent implements OnInit, OnDestroy {
  loading = false;
  formGroup: FormGroup;
  genderList: string[] = [];
  ageGroupList: string[] = [];
  prefixList: string[] = [];
  maritalStatusList: string[] = [];
  qualificationList: string[] = [];
  wofbiStatusList: string[] = [];
  myProfile: UserProfile;

  @ViewChild("staticTabs", {static:true}) staticTabs: TabsetComponent;
  readOnlyGroups: ReadOnlyItemsGroup[] = [];

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    private userAccountService: UserAccountService,
    private sweetAlertService: SweetAlertService
  ) {}
  ngOnInit() {
    this.prefixList = ["Pastor", "Elder", "Dcn.", "Dcns.", "Bro.", "Sis."];
    this.genderList = ["Male", "Female"];
    this.ageGroupList = ["Adult", "Child"];
    this.maritalStatusList = ["Single", "Married"];
    this.wofbiStatusList = ["BCC", "LDC", "LCC"];
    this.qualificationList = [
      "Primary School Certificate",
      "Senior School Certificate (SSE)",
      "National Diploma (ND)",
      "Higher National Diploma (HND)",
      "Bachelor's degree",
      "Postgraduate Diploma (PGD)",
      "Master's Degree",
      "Doctor of Philosophy (Phd)"
    ];

    this.createForm();
    this.loadProfile();
  }

  public loadProfile() {
    this.loading = true;
    this.userAccountService
      .getProfile()
      //.pipe(finalize(() => (this.loading = false)))
      .subscribe(
        (response: UserProfile) => {
          if (response) {
            this.myProfile = response;
            //console.log(response);
            this.prepareReadOnlyData();
            this.patchForm();
          }
          this.loading = false;
        },
        error => {
          this.loading = false;
        }
      );
  }

  private createForm() {
    this.formGroup = this.fb.group({
      prefix: [""],
      lastname: ["", Validators.required],
      firstname: ["", Validators.required],
      otherName: [""],
      gender: [""],
      address: [""],
      phone: [""],
      email: [""],
      dateOfBirth: [""],
      maritalStatus: [""],
      weddingAnniversaryDate: [""],
      joinedChurchAt: [""],
      convertedAt: [""],
      waterBaptismAt: [""],
      holyGhostBaptismAt: [""],
      occupation: [""],
      otherProfessionalSkills: [""],
      churchDepartment: [""],
      joinedChurchDepartmentAt: [""],
      highestQualification: [""],
      highestQualificationAt: [],
      wofbiStatus: [""],
      wofbiStatusAt: [""],
      centerAddress: ["", Validators.required],
      centeShortAddress: [""],
      accessCode: [""],
      username: [""],
      positionLevel: [""]
    });
  }

  private patchForm() {
    this.formGroup.patchValue({
      prefix: this.myProfile.prefix,
      lastname: this.myProfile.lastname,
      firstname: this.myProfile.firstname,
      otherName: this.myProfile.otherName,
      gender: this.myProfile.gender,
      address: this.myProfile.address,
      phone: this.myProfile.phone,
      email: this.myProfile.email,
      dateOfBirth: this.myProfile.dateOfBirth
        ? new Date(this.myProfile.dateOfBirth)
        : "",
      maritalStatus: this.myProfile.maritalStatus,
      weddingAnniversaryDate: this.myProfile.weddingAnniversaryDate
        ? new Date(this.myProfile.weddingAnniversaryDate)
        : "",
      joinedChurchAt: this.myProfile.joinedChurchAt
        ? new Date(this.myProfile.joinedChurchAt)
        : "",
      convertedAt: this.myProfile.convertedAt
        ? new Date(this.myProfile.convertedAt)
        : "",
      waterBaptismAt: this.myProfile.waterBaptismAt
        ? new Date(this.myProfile.waterBaptismAt)
        : "",
      holyGhostBaptismAt: this.myProfile.holyGhostBaptismAt
        ? new Date(this.myProfile.holyGhostBaptismAt)
        : "",
      occupation: this.myProfile.occupation,
      otherProfessionalSkills: this.myProfile.otherProfessionalSkills,
      churchDepartment: this.myProfile.churchDepartment,
      joinedChurchDepartmentAt: this.myProfile.joinedChurchDepartmentAt
        ? new Date(this.myProfile.joinedChurchDepartmentAt)
        : "",
      highestQualification: this.myProfile.highestQualification,
      highestQualificationAt: this.myProfile.highestQualificationAt,
      wofbiStatus: this.myProfile.wofbiStatus,
      wofbiStatusAt: this.myProfile.wofbiStatusAt
        ? new Date(this.myProfile.wofbiStatusAt)
        : "",
      centerAddress: this.myProfile.centerAddress,
      centeShortAddress: this.myProfile.centeShortAddress,
      accessCode: this.myProfile.accessCode,
      username: this.myProfile.username,
      positionLevel: this.myProfile.positionLevel
    });

    this.formGroup.controls["firstname"].markAsTouched();
    this.formGroup.controls["firstname"].markAsDirty();

    this.formGroup.controls["lastname"].markAsTouched();
    this.formGroup.controls["lastname"].markAsDirty();

    this.formGroup.controls["centerAddress"].markAsTouched();
    this.formGroup.controls["centerAddress"].markAsDirty();
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
  }

  updateProfile() {
    if (this.formGroup.valid) {
      this.sweetAlertService
        .showConfirm("Your Profile will be updated.")
        .then(a => {
          if (a.value) {
            this.loading = true;
            this.userAccountService
              .updateProfile(this.formGroup.value)
              .pipe(finalize(() => (this.loading = false)))
              .subscribe((response: ResponseModel) => {
                if (response.isOk) {
                  this.myProfile = Object.assign({}, this.formGroup.value);
                  //console.log(response);
                  this.prepareReadOnlyData();
                  this.formGroup.reset();
                  this.sweetAlertService.showSuccess(
                    "Your Profile has been updated successfully"
                  );
                }
              });
          }
        });
    }
  }

  selectTab(tabId: number) {
    this.staticTabs.tabs[tabId].active = true;
  }

  private prepareReadOnlyData() {
    this.readOnlyGroups = [];
    const profile = Object.assign({}, this.myProfile);

    const group1: ReadOnlyItemsGroup = {
      caption: "Personal Details",
      items: [
        { value: profile.prefix, label: "Prefix" },
        { value: profile.lastname, label: "Last Name" },
        { value: profile.firstname, label: "First Name" },
        { value: profile.gender, label: "Gender" },
        { value: profile.phone, label: "Phone" },
        { value: profile.email, label: "Email" },
        { value: profile.address, label: "Home Address" },
        {
          value: !profile.dateOfBirth
            ? ""
            : moment(profile.dateOfBirth).format("LL"),
          label: "Birthday"
        },
        { value: profile.maritalStatus, label: "Marital Status" },
        {
          value: !profile.weddingAnniversaryDate
            ? ""
            : moment(profile.weddingAnniversaryDate).format("LL"),
          label: "Wedding Anniversary Date"
        }
      ]
    };
    const group2: ReadOnlyItemsGroup = {
      caption: "Qualifications",
      items: [
        { value: profile.occupation, label: "Occupation" },
        {
          value: profile.otherProfessionalSkills,
          label: "Other Professional Skills"
        },
        { value: profile.highestQualification, label: "Highest Qualification" },
        {
          value: profile.highestQualificationAt,
          label: "Highest Qualification At"
        }
      ]
    };

    const group3: ReadOnlyItemsGroup = {
      caption: "Church Membership Details",
      items: [
        {
          value: !profile.joinedChurchAt
            ? ""
            : moment(profile.joinedChurchAt).format("LL"),
          label: "Joined Church On (Date)"
        },
        {
          value: !profile.convertedAt
            ? ""
            : moment(profile.convertedAt).format("LL"),
          label: "Date Converted"
        },
        {
          value: !profile.waterBaptismAt
            ? ""
            : moment(profile.waterBaptismAt).format("LL"),
          label: "Water Baptism Date"
        },
        {
          value: !profile.holyGhostBaptismAt
            ? ""
            : moment(profile.holyGhostBaptismAt).format("LL"),
          label: "Holy Ghost Baptism Date"
        },
        {
          value: profile.churchDepartment,
          label: "Church Department"
        },
        {
          value: !profile.joinedChurchDepartmentAt
            ? ""
            : moment(profile.joinedChurchDepartmentAt).format("LL"),
          label: "Joined Department On (Date)"
        },
        { value: profile.wofbiStatus, label: "WOFBI Status" },
        {
          value: !profile.wofbiStatusAt
            ? ""
            : moment(profile.wofbiStatusAt).format("LL"),
          label: "WOFBI Status Date"
        }
      ]
    };

    const group4: ReadOnlyItemsGroup = {
      caption: "User Account",
      items: [
        { value: profile.positionLevel, label: "Position Level" },
        {
          value: profile.accessCode,
          label: "Access Code",
          type: "code",
          hidden: true
        }
      ]
    };

    this.readOnlyGroups.push(group1);
    this.readOnlyGroups.push(group2);
    this.readOnlyGroups.push(group3);
    this.readOnlyGroups.push(group4);
  }

  onSelectUpdateTab(data: TabDirective): void {
    this.patchForm();
  }

  ngOnDestroy(): void {}
}
