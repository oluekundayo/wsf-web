import { Component, OnInit, ElementRef } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { LoginService } from "../../services/components-services/login.service";
import {
  NewUserDetails,
  SignUpUserProfiling,
  VerifyUserOtp
} from "../../models/user_account.models";
import { finalize } from "rxjs/operators";
import { ResponseModel } from "../../models/utilities.models";
import { SweetAlertService } from "../../services/utils/sweet-alert.service";
import { Router } from "@angular/router";

//declare var $: any;

@Component({
  moduleId: module.id,
  selector: "register-cmp",
  templateUrl: "./register.component.html"
})
export class RegisterComponent implements OnInit {
  test: Date = new Date();
  //type: FormGroup;
  appName: string = "WSF Portal";
  formGroup: FormGroup;
  loading: boolean = false;
  signUpProfiling: SignUpUserProfiling;
  isAccessCodeValid: boolean = false;
  isOtpValid: boolean = false;
  // actionStep: number = 1;
  requiresRoleCode: boolean = false;
  positionHolderId: string = "";

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private loginService: LoginService,
    private sweetAlertService: SweetAlertService
  ) {
    this.createForm();
  }

  ngOnInit() {
    this.getSignUpProfiling();

    //this.checkFullPageBackgroundImage();

    /*setTimeout(function() {
      try {
        // after 1000 ms we add the class animated to the login/register card
        $(".card").removeClass("card-hidden");
      } catch (e) {}
    }, 700);*/
  }

  private createForm() {
    this.formGroup = this.fb.group({
      roleId: [null, Validators.required],
      parentCenterId: [null],
      roleCode: [""],
      accessCode: ["", Validators.required],
      username: [""],
      password: [""],
      otp: [""],
      confirmPassword: [""],
      registeredPhone: [""]
    });
  }

  private getSignUpProfiling() {
    this.loading = true;
    this.loginService
      .signUpProfiling()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        if (response) {
          this.signUpProfiling = response;
          this.signUpProfiling.userRoles.push({ id: 0, name: "Others" });
        }
      });
  }

  private getParentCenters() {
    this.loading = true;
    this.loginService
      .getParentCenters(this.signUpProfiling.parentCenterType.id)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        if (this.signUpProfiling) {
          this.signUpProfiling.parentCenters = response;
        }
      });
  }

  /*checkFullPageBackgroundImage() {
    try {
      var $page = $(".full-page");
      var image_src = $page.data("image");

      if (image_src !== undefined) {
        var image_container =
          '<div class="full-page-background" style="background-image: url(' +
          image_src +
          ') "/>';
        $page.append(image_container);
      }
    } catch (e) {}
  }*/

  public onSelectRole(roleId: number) {
    if (roleId == 0) {
      this.requiresRoleCode = true;
    } else if (roleId > 0) {
      this.requiresRoleCode = false;
      if (!this.signUpProfiling.parentCenters) {
        this.getParentCenters();
      }
    } else {
      this.requiresRoleCode = false;
    }
  }

  private validateUserAccountInputs(user: NewUserDetails): ResponseModel {
    const response = new ResponseModel();

    response.isOk = true;
    response.error = "";

    if (!user.username || user.username.length < 3) {
      response.error += "Username is required. <br/><br/>";
      response.isOk = false;
    }

    if (!user.password || user.password.length < 4) {
      response.error +=
        "Password is required and must be of 4 Characters minimum. <br/><br/>";
      response.isOk = false;
    }

    if (user.password != user.confirmPassword) {
      response.error += "Password and Confirm Password must be thesame. ";
      response.isOk = false;
    }

    return response;
  }

  public createAccount() {
    const user = new NewUserDetails();
    user.accessCode = this.formGroup.value.accessCode;
    user.username = this.formGroup.value.username;
    user.password = this.formGroup.value.password;
    user.confirmPassword = this.formGroup.value.confirmPassword;
    user.positionHolderId = this.positionHolderId;

    const res = this.validateUserAccountInputs(user);

    if (!res.isOk) {
      this.sweetAlertService.showError(res.error, true);
      return;
    }

    /*if (!this.formGroup.valid) {
      this.sweetAlertService.showError(
        "Your Account Informtion are not sufficient"
      );
      return;
    }*/

    this.sweetAlertService
      .showConfirm("Your Account will be created")
      .then(response => {
        if (response.value) {
          this.loading = true;
          this.loginService
            .register(user)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              this.sweetAlertService.showSuccess(response.message);
              this.router.navigate(["auth/user/login"]);
            });
        }
      });
  }

  public validateAccessCode() {
    const user = new NewUserDetails();
    user.accessCode = this.formGroup.value.accessCode;
    user.roleId = this.formGroup.value.roleId;
    user.roleCode = this.formGroup.value.roleCode;
    user.parentCenterId = this.formGroup.value.parentCenterId;

    let error = "";
    if (user.roleId == 0 && !user.roleCode) {
      error += "Your Role Code is Required. <br/>";
    }

    if (user.roleId != 0 && !user.parentCenterId) {
      error += "Your Center is Required. <br/";
    }

    if (error) {
      this.sweetAlertService.showError(error, true);
      return;
    }

    console.log(user);

    this.loading = true;
    this.loginService
      .validateAccessCode(user)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((response: ResponseModel) => {
        // console.log(response);
        this.positionHolderId = response.data;
        this.isAccessCodeValid = response.isOk;

        // remove line if OTP Verification is enabled.
        this.isOtpValid = this.isAccessCodeValid;
        this.sweetAlertService.showMessage(response.message);
      });
  }

  public validateOtp() {
    const user = new VerifyUserOtp();
    user.otp = this.formGroup.value.otp;
    user.positionHolderId = this.positionHolderId;

    let error = "";
    if (!user.otp) {
      error += "The Verification Code sent to your phone is Required. <br/>";
    }

    if (error) {
      this.sweetAlertService.showError(error, true);
      return;
    }

    this.loading = true;
    this.loginService
      .verifyOtpForSignUp(user)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((response: ResponseModel) => {
        // console.log(response);
        this.isOtpValid = response.isOk;
      });
  }

  isFieldValid(form: FormGroup, field: string) {
    return !form.get(field).valid && form.get(field).touched;
  }

  displayFieldCss(form: FormGroup, field: string) {
    return {
      "has-error": this.isFieldValid(form, field),
      "has-success": this.isFieldValid(form, field)
    };
  }
}
