import { Component, OnInit } from "@angular/core";
import {
  Lookup,
  ResponseModel,
  ApiUrlParam
} from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import {
  CenterType,
  CenterSearchResult,
  PositionLevel,
  Center,
  PositionHolder,
  DrillDownCenters
} from "../../../models/centers.models";
import { APIService } from "../../../services/api.service";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { ApiRoutes } from "../../../services/api.routes";
import { finalize } from "rxjs/operators";
import { FindACenterDialogComponent } from "../../dialog/find-a-center-dialog/find-a-center-dialog.component";
import { filter, find } from "lodash";

@Component({
  selector: "app-create-new-center-position-holder",
  templateUrl: "./create-new-center-position-holder.component.html",
  styleUrls: ["./create-new-center-position-holder.component.scss"]
})
export class CreateNewCenterPositionHolderComponent implements OnInit {
  formGroup: FormGroup;

  loading = false;
  pageTitle: string;
  selectedCenter: CenterSearchResult;
  bsModalRef: BsModalRef;
  //selectedCenterTypePositionLevels: PositionLevel[];
  genderList: Lookup[] = [];
  prefixes: Lookup[] = [];
  positionLevels: PositionLevel[] = [];
  isInitPageLoad: boolean = true;
  selectedPositionLevel: PositionLevel;
  drilledDownCenters: DrillDownCenters[] = [];
  centerFinderResults: CenterSearchResult[] = [];
  currentDrillDownIndex: number = 0;

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    private modalService: BsModalService,
    private sweetAlertService: SweetAlertService
  ) {
    this.formGroup = fb.group({
      centerId: [null, Validators.required],
      positionLevel: [null, Validators.required],
      prefix: [null],
      lastname: [""],
      firstname: ["", Validators.required],
      phone: [""],
      gender: [null],
      email: ["", Validators.email],
      address: [""]
      //hasSameCenterTypeWithCurrentUser: [false]
      //isCentersContact: [false, Validators.required]
    });
  }

  ngOnInit() {
    this.prefixes = this.getPrefixes();
    this.genderList = this.getGenderList();
    this.getPositionLevelsAssignedToManage();
    this.drillDownCenters({ centerId: 0 }, false);
  }

  private getPrefixes(): Lookup[] {
    const prefixes: Lookup[] = [];
    const pp = ["Pastor", "Elder", "Dcn.", "Dcns.", "Bro.", "Sis."];

    pp.forEach(p => {
      prefixes.push({ id: 1, name: p });
    });

    return prefixes;
  }

  private getGenderList(): Lookup[] {
    const genders: Lookup[] = [];

    const pp = ["Male", "Female"];

    pp.forEach(p => {
      genders.push({ id: 1, name: p });
    });

    return genders;
  }

  public onSelectPositionLevel(level: PositionLevel) {
    /*if (level && level.hasSameCenterTypeWithCurrentUser) {
      this.patchParentCenter(0);
    } else {
      this.patchParentCenter(null);
    }
    this.isInitPageLoad = false;*/
    this.selectedPositionLevel = level;
  }

  public patchParentCenter(parentId: number) {
    this.formGroup.patchValue({
      centerId: parentId
    });
  }

  public onSelectCenter(center: CenterSearchResult) {
    //console.log(center);
    this.selectedCenter = center;
  }

  public drillDownCenters(
    center: CenterSearchResult,
    isPreviousDirection: boolean = false
  ) {
    //console.log(parentCenter);

    if (center && center.centerId >= 0) {
      this.loading = true;
      this.api
        .get<CenterSearchResult[]>(
          ApiRoutes.centers.drill_down_centers,
          isPreviousDirection ? center.parentCenterId : center.centerId
        )
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          /* this.drilledDownCenters = filter(
            this.drilledDownCenters,
            (a, index) => {
              return index <= selectedIndex;
            }
          );*/
          this.centerFinderResults = response;
          /*
          this.drilledDownCenters.push({
            searchedCenter: center,
            centerTypeId: response[0].centerTypeId,
            parentCenters: response
          } as DrillDownCenters);*/
        });
    } else {
      alert("No records found");
    }
  }

  public nextDrillDown() {
    this.currentDrillDownIndex += 1;
    this.drillDownCenters(this.selectedCenter);
  }

  public previousDrillDown() {
    this.currentDrillDownIndex -= 1;
    this.drillDownCenters(this.selectedCenter, true);
    /*if(this.currentDrillDownIndex >= 0)
    {

    const previousCenter = find(this.drilledDownCenters, (a, index) => {
      return index == this.currentDrillDownIndex;
    });

    this.drillDownCenters(previousCenter.searchedCenter, true);

  }
  else {
    alert("No previuos records found")
  }*/
  }

  public openModalToSelectParentCenter() {
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      initialState: {
        selectedCenterTypeId: this.selectedPositionLevel.centerTypeId
      }
    };

    this.bsModalRef = this.modalService.show(
      FindACenterDialogComponent,
      config
    );
    this.bsModalRef.content.action.subscribe((value: CenterSearchResult) => {
      // console.log(value); // here you will get the value
      if (value) {
        this.selectedCenter = value;
        this.patchParentCenter(value.centerId);

        //this.reloadPositionLevels(value.centerTypeId);

        //this.survey.controls['account'].patchValue(survey.account);
        //https://toddmotto.com/angular-2-form-controls-patch-value-set-value
      }
    });
  }

  /*private reloadPositionLevels(centerTypeId: number) {
    const params: ApiUrlParam = {
      name: "centerTypeId",
      value: centerTypeId + ""
    };
    this.loading = true;
    this.api
      .getAll<PositionLevel[]>(
        ApiRoutes.positions.position_levels_by_center_type,
        [params]
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.selectedCenterTypePositionLevels = response;
      });
  }*/

  private getPositionLevelsAssignedToManage() {
    this.loading = true;
    this.api
      .getAll<PositionLevel[]>(
        ApiRoutes.position_levels.get_assigned_position_levels_to_manage
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.positionLevels = response;
        //console.log(response);
      });
  }

  private getPositionHolderDataToSave(): ResponseModel {
    const response = new ResponseModel();

    let positionHolder: PositionHolder = new PositionHolder();
    positionHolder.address = this.getFormControlValue("address");
    positionHolder.firstname = this.getFormControlValue("firstname");
    positionHolder.lastname = this.getFormControlValue("lastname");
    positionHolder.fullname =
      positionHolder.lastname + " " + positionHolder.firstname;
    positionHolder.email = this.getFormControlValue("email");
    positionHolder.phone = this.getFormControlValue("phone");
    positionHolder.prefix = this.getFormControlValue("prefix");
    positionHolder.gender = this.getFormControlValue("gender");
    positionHolder.isCentersContact = this.selectedPositionLevel.isCentersContactLevel;
    positionHolder.maritalStatus = "";
    positionHolder.othername = "";

    const positionLevel = this.getFormControlValue("positionLevel");
    positionHolder.positionLevelId = positionLevel.id;

    /*if (positionHolder.hasSameCenterTypeWithCurrentUser) {
      positionHolder.centerId = 0;
      positionHolder.centerTypeId = 0;
    } else {*/

    if (!this.selectedCenter) {
      response.isOk = false;
      response.error = "User's Center is required";
    } else {
      positionHolder.centerId = this.selectedCenter.centerId;
      positionHolder.centerTypeId = this.selectedCenter.centerTypeId;
    }
    //}

    if (!positionHolder.lastname && !positionHolder.firstname) {
      response.isOk = false;
      response.error = "Names of the User are required";
    } else {
      response.isOk = true;
      response.data = positionHolder;
    }

    if (
      !this.selectedCenter.centerTypeId ||
      positionLevel.centerTypeId != this.selectedCenter.centerTypeId
    ) {
      response.isOk = false;
      response.error =
        "The selected Role does not function under the selected Center.";
    }

    return response;
  }

  public createNewCenter() {
    const holderResponse = this.getPositionHolderDataToSave();

    if (holderResponse.isOk) {
      this.sweetAlertService
        .showConfirm("New Center User will be saved for Creation")
        .then(response => {
          if (response.value) {
            this.loading = true;
            this.api
              .post<ResponseModel>(
                ApiRoutes.centers.centers_position_holders,
                holderResponse.data
              )
              .pipe(finalize(() => (this.loading = false)))
              .subscribe(response => {
                this.resetPage();
                this.sweetAlertService.showSuccess(response.message);
              });

            //console.log(response.value);
          }
        });
    } else {
      this.sweetAlertService.showError(holderResponse.error);
    }
  }

  private trimString(_string: string): string {
    if (_string) return _string.trim();
    else return "";
  }

  private getFormControlValue(key: string) {
    return this.formGroup.get(key).value;
  }

  private resetPage() {
    this.selectedCenter = new CenterSearchResult();
    this.selectedCenter.displayAddress = "";
    this.formGroup.reset();
  }

  ngOnDestroy(): void {
    try {
      this.bsModalRef.content.action.unsubscribe();
    } catch (e) {}
  }
}
