import { PositionHolder } from "./centers.models";

export class ApprovalRequest {
  id: number;
  approval_type_id: number;
  approval_type: string;
  request_reasons: string;
  item_to_approve_id: number;
  created_at: Date;
  created_by: string;
}

export class ApprovalType {
  id: number;
  name: string;
  description: string;
  item_display_url: string;
  created_at: Date;
  created_by: string;
}

export class NewCenterToApprove {
  parent_center: string;
  center_type: string;
  center_id: number;
  chronological_name: string; //E.g P12D123
  short_center_description: string;
  structural_division: string;
  status: string;
  effective_date: Date;
  date_submitted: Date;
  comment: string;
  position_holder: PositionHolder;
  created_at: Date;
  created_by: string;
}

export class TestimonyToApprove {
  id: number;
  testifier: string;
  center: string;
  title: string;
  details: string;
  original_details: string;
  date_shared: Date;
  minister_name: string;
  minister_phone: string;
  status: string;
  created_at: Date;
  created_by: string;
}

export class WSFUpdateToApprove {
  report_id: number;
  //old_report: MeetingAttendance;
  //new_report: MeetingAttendance;
  reasons: string;
  status: string;
  date_requested: Date;
  created_at: Date;
  created_by: string;
}

export class CombinedMeetingRequestToApprove {
  id: number;
  requester_center: string;
  requester_name: string;
  requester_phone: string;
  coordinator: string;
  meeting: string;
  host_center: string;
  proposed_meeting_date: Date;
  status: string;
  application_note: string;
  //centers_in_combined_meeting: MeetingCenter;
  created_at: Date;
  created_by: string;
}

/*
export class ApprovalRoutes {
  static approvalRequests = "approval_requests";
  static approvalTypes = "approval_types";
  static approveCombinedMeetingRequests = "approve_combined_meeting_requests";
  static approveNewCenters = "approve_new_centers";
  static approveTestimonies = "approve_testimonies";
  static approveWSFUpdate = "approve_wsf_update";
}
*/
