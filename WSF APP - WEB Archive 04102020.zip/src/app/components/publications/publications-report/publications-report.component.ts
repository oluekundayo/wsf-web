import { finalize } from "rxjs/operators";
import { Router, ActivatedRoute } from "@angular/router";
import { Component, OnInit, OnDestroy } from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import {
  PaginatorFilter,
  Lookup,
  ApiUrlParam,
  ResponseModel,
  ApprovalStatus,
  VisibilityStatus,
  ApprovalPost,
  SimpleFilter,
  StatusReport,
  PageDirection,
  ReportAnalysisPeriodType
} from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import {
  Publication,
  PublicationsStatusReport
} from "../../../models/publications.models";
import { ReportFilter } from "../../../models/reporting.models";
import { PublicationService } from "../../../services/components-services/publications.service";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { sumBy, filter } from "lodash";
import { ChartOptions } from "chart.js";
import { ReportingService } from "../../../services/components-services/reporting.service";
import { TabDirective } from "ngx-bootstrap/tabs";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { ApprovePublicationDialogComponent } from "../../dialog/approve-publication-dialog/approve-publication-dialog.component";

@Component({
  selector: "app-publications-report",
  templateUrl: "./publications-report.component.html",
  styleUrls: ["./publications-report.component.scss"]
})
export class PublicationsReportComponent implements OnInit, OnDestroy {
  loading = false;
  publicationsStatusReport: PublicationsStatusReport;
  publications: Publication[] = [];
  currentPaginator: PaginatorFilter;
  PAGINATOR_PAGE_SIZE: number = 10;

  public chartColors: Array<any> = [];
  public chartOptionsForCounts: ChartOptions;
  public trendsChartOptions: ChartOptions;
  public trendsChartLabels: string[] = [];
  public countsChartLabels: string[] = [];
  public trendsChartData: any[] = [];
  public countsChartData: number[] = [];
  public isTrendsChartReady: boolean = false;
  bsModalRef: BsModalRef;

  constructor(
    private publicationService: PublicationService,
    private sweetAlertService: SweetAlertService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private reportingService: ReportingService,
    private modalService: BsModalService
  ) {}

  ngOnInit() {
    this.initCharts();
    this.initPaginators();
    this.getPublicationsReport();
    //this.getUnProofreadTestimonies();
    //this.getApprovedTestimonies();
  }

  public getPublicationsReport() {
    const filter = new SimpleFilter();
    filter.getOnlyDataTrend = false;
    this.reportingService.injectDatesIntoStatusReportsFilter(
      filter,
      ReportAnalysisPeriodType.ThisYear
    );
    this.publicationService
      .getPublicicationsReport(filter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.publicationsStatusReport = response;
        this.prepareCharts(this.publicationsStatusReport);
      });
  }

  private initPaginators() {
    this.currentPaginator = new PaginatorFilter();
    this.currentPaginator.pageSize = this.PAGINATOR_PAGE_SIZE;
    this.currentPaginator.direction = PageDirection.NEXT;
    this.currentPaginator.lastMaxId = 0;
    this.currentPaginator.totalItemsCount = 0;
    this.currentPaginator.currentPageStart = 0;
    this.currentPaginator.currentPageEnd = 0;
  }

  private initCharts() {
    try {
      this.trendsChartData = [
        { data: [], label: "Shared" },
        { data: [], label: "Approved" },
        { data: [], label: "Disapproved" }
      ];

      this.countsChartLabels.push(...["Shared", "Approved", "Disapproved"]);
      this.trendsChartOptions = {
        responsive: true,
        //scaleShowVerticalLines: false,
        //fill: false,
        // We use these empty structures as placeholders for dynamic theming.
        scales: { xAxes: [{}], yAxes: [{}] },
        plugins: {
          datalabels: {
            anchor: "end",
            align: "end"
          }
        }
      };

      this.chartOptionsForCounts = {
        //rotation: 1 * Math.PI,
        //circumference: 1 * Math.PI,
        scales: { scaleLabel: { fontSize: 13 } },
        title: {
          display: true,
          text: "Status Summary"
        },
        plugins: {
          /*labels: {
          render: function(args) {
            const label = args.label,
              value = args.value;
            return label + ": " + value;
          }
          //arc: true
        }*/
          labels: [
            {
              render: "label",
              position: "outside"
            },
            {
              render: "value"
            }
          ],
          arc: true
        }
      };

      this.isTrendsChartReady = false;
    } catch (e) {}
  }

  private resetChartData() {
    this.trendsChartData = [
      { data: [], label: "Shared" },
      { data: [], label: "Approved" },
      { data: [], label: "Disapproved" }
    ];

    this.countsChartData = [];

    this.trendsChartLabels = [];
  }

  private prepareCharts(reports: PublicationsStatusReport) {
    try {
      this.resetChartData();

      const allItems = sumBy(reports.trends, item => item.allItemsCount);
      const allApproved = sumBy(
        reports.trends,
        item => item.approvedItemsCount
      );
      const allDisapproved = sumBy(
        reports.trends,
        item => item.disapprovedItemsCount
      );

      this.countsChartData.push(...[allItems, allApproved, allDisapproved]);

      reports.expectedPeriodKeys.forEach(key => {
        const groupedData = filter(reports.trends, function(
          item: StatusReport
        ) {
          return (
            item[key.key] == key.value && item[key.parentKey] == key.parentValue
          );
        });
        //console.log(groupedData);
        this.trendsChartData[0].data.push(
          sumBy(groupedData, item => item.allItemsCount)
        );

        this.trendsChartData[1].data.push(
          sumBy(groupedData, item => item.approvedItemsCount)
        );

        this.trendsChartData[1].data.push(
          sumBy(groupedData, item => item.disapprovedItemsCount)
        );
      });

      reports.expectedPeriodKeys.forEach(key => {
        this.trendsChartLabels.push(this.reportingService.getChartKey(key));
      });
      this.isTrendsChartReady = true;
    } catch (e) {}
  }

  onSelectPendingPublicationsTab(ev?: any) {
    if (!(ev instanceof TabDirective)) return;

    if (!this.publications) {
      this.publications = [];
    }

    if (!this.publications.length) {
      this.getUnapprovedPublications();
    }
  }

  getUnapprovedPublications() {
    this.publicationService
      .getAllUnapprovedPublications(this.currentPaginator)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        //this.currentPaginator = response.paginator;
        this.publications = response;
      });
  }

  public openApprovalModal(publication: Publication) {
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      initialState: {
        publicationIdKey: publication.idKey
        //publication: publication
      },
      animate: true
    };

    this.bsModalRef = this.modalService.show(
      ApprovePublicationDialogComponent,
      config
    );

    this.bsModalRef.content.action.subscribe(value => {
      //console.log(value); // here you will get the value
      if (value) {
        const index = this.publications.indexOf(publication);
        if (index > -1) {
          this.publications.splice(index, 1);
        }
      }
    });
  }

  ngOnDestroy(): void {}
}
