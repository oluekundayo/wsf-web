import { Component, OnInit, OnDestroy } from "@angular/core";
import { DynamicJsScriptLoaderService } from "../../../../services/utils/dynamic-js-script-loader.service";
import { finalize, map, filter } from "rxjs/operators";
import {
  ReportAnalysisPeriodType,
  ReportAnalysisResultsGroupingType,
  Lookup,
  ReportAnalysisChartType
} from "../../../../models/utilities.models";
import {
  ActivatedRoute,
  Router,
  NavigationStart,
  NavigationEnd
} from "@angular/router";
import { Subscription } from "rxjs";
import { Meeting } from "../../../../models/meetings.models";
import { ChartOptions } from "chart.js";
import { sumBy, filter as _filter, cloneDeep } from "lodash";

import { find } from "lodash";
//import * as moment from "moment";
import { ReportingService } from "../../../../services/components-services/reporting.service";
import {
  ObjectProperty,
  ReportFilter
} from "../../../../models/reporting.models";
import {
  ParticipantsReportsAnalysisSummary,
  ParticipantsReportsAnalysisDetailsByCenter,
  AnalysisDashboardItemsForParticipants,
  ParticipantsAnalysisReportItem
} from "../../../../models/reports.analysis.models";
import { CenterSearchResult } from "../../../../models/centers.models";

@Component({
  selector: "app-reports-analysis-for-multiple-participations",
  templateUrl: "./reports-analysis-for-multiple-participations.component.html",
  styleUrls: ["./reports-analysis-for-multiple-participations.component.scss"]
})
export class ReportsAnalysisForMultipleParticipationsComponent
  implements OnInit, OnDestroy {
  meeting: Meeting;
  loading: boolean = false;
  isJsLoaded: boolean = false;
  routeSubscription: Subscription;
  selectedPeriodType: ReportAnalysisPeriodType;
  expectedPeriodKeys: ObjectProperty[];
  filter: ReportFilter = new ReportFilter();
  dashboard: AnalysisDashboardItemsForParticipants = new AnalysisDashboardItemsForParticipants();
  selectedCenterForFiltering: CenterSearchResult;
  selectedCenterForFilteringSubscription: Subscription;

  public analysisSummaryData: ParticipantsReportsAnalysisSummary;
  public analysisDetailsByCenters: ParticipantsReportsAnalysisDetailsByCenter[] = [];
  public centerTypesDrilldown: Lookup[] = [];

  public chartColors: Array<any> = [];
  public chartOptionsForGender: ChartOptions;
  public chartOptionsForAgeGroup: ChartOptions;
  public trendsChartOptions: ChartOptions;
  public centersChartOptions: ChartOptions;
  public trendsChartLabels: string[] = [];
  public trendsChartData: any[] = [];
  public centersChartLabels: string[] = [];
  public centersChartData: any[] = [];
  public isDataReady: boolean = false;
  public isTrendsChartReady: boolean = false;
  public isCentersDetailsChartReady: boolean = false;
  public centerDataViewMode: string = "Chart";
  pagingCurrentPage: number = 1;
  pagingItemsPerPage: number = 30;

  constructor(
    private activeRoute: ActivatedRoute,
    private router: Router,
    private dynamicScriptLoader: DynamicJsScriptLoaderService,
    private reportingService: ReportingService
  ) {
    try {
      this.router.routeReuseStrategy.shouldReuseRoute = () => false;
      //const routeParams = this.activeRoute.snapshot.params;
      //this.meetingId = routeParams.id;

      //const t = this.router.getCurrentNavigation().extras.state;

      this.routeSubscription = this.router.events
        .pipe(
          filter(e => e instanceof NavigationEnd),
          map(() => this.router.getCurrentNavigation().extras.state)
        )
        .subscribe(response => {
          if (response && response.meeting) this.meeting = response.meeting;
        });

      //console.log(this.meetingId);
    } catch (e) {
      //console.log(e);
    }

    this.selectedCenterForFilteringSubscription = this.reportingService
      .GetCachedSelectedCenterForFiltering()
      .subscribe(center => {
        this.selectedCenterForFiltering = center;
      });

    //this.configureCharts();
    //this.loadJsScripts();
  }

  ngOnInit() {
    // Just call your load scripts function with scripts you want to load
    this.initCharts();

    if (this.meeting) {
      this.filter.meetingId = this.meeting.id;
      this.filter.meetingChurchSystemId = this.meeting.churchSystemId;
      this.filter.periodType = ReportAnalysisPeriodType.ThisMonth;
      // this.initCharts();
    }

    this.loadData();
  }

  private initCharts() {
    try {
      this.trendsChartData = [
        { data: [], label: "Registered" },
        { data: [], label: "Completed" }
      ];

      this.trendsChartOptions = {
        responsive: true,
        //scaleShowVerticalLines: false,
        //fill: false,
        // We use these empty structures as placeholders for dynamic theming.
        scales: { xAxes: [{}], yAxes: [{}] },
        plugins: {
          datalabels: {
            anchor: "end",
            align: "end"
          }
        }
      };

      this.centersChartData = [
        { data: [], label: "Registered" },
        { data: [], label: "Completed" }
      ];

      this.centersChartOptions = {
        responsive: true,
        //scaleShowVerticalLines: false,
        //fill: false,
        // We use these empty structures as placeholders for dynamic theming.
        scales: { xAxes: [{}], yAxes: [{}] },
        plugins: {
          datalabels: {
            anchor: "end",
            align: "end"
          }
        }
      };

      this.chartOptionsForGender = {
        rotation: 1 * Math.PI,
        circumference: 1 * Math.PI,
        scales: { scaleLabel: { fontSize: 13 } },
        title: {
          display: true,
          text: "Gender Stat"
        },
        plugins: {
          /*labels: {
          render: function(args) {
            const label = args.label,
              value = args.value;
            return label + ": " + value;
          }
          //arc: true
        }*/
          labels: [
            {
              render: "label",
              position: "outside"
            },
            {
              render: "value"
            }
          ],
          arc: true
        }
      };

      this.chartOptionsForAgeGroup = cloneDeep(this.chartOptionsForGender);
      this.chartOptionsForAgeGroup.title.text = "Age Group Stat";

      this.isTrendsChartReady = false;
    } catch (e) {}
  }

  private resetChartData(chartType: ReportAnalysisChartType) {
    try {
      if (chartType == ReportAnalysisChartType.Trend) {
        /*  this.trendsChartData = [
          { data: [], label: "Registered" },
          { data: [], label: "Completed" }
        ];*/

        this.trendsChartData.forEach(element => {
          //element.data = [];
          element.data.length = 0;
        });

        this.trendsChartLabels = [];
      }

      if (chartType == ReportAnalysisChartType.CentersDetails) {
        /* this.centersChartData = [
          { data: [], label: "Registered" },
          { data: [], label: "Completed" },
          { data: [], label: "Still Ongoing" }
        ];*/

        this.centersChartData.forEach(element => {
          //element.data = [];
          element.data.length = 0;
        });

        this.centersChartLabels = [];
        this.analysisDetailsByCenters = [];
      }
    } catch (e) {}
  }

  private loadData() {
    //filter.periodType = AnalysisPeriodType.ThisYear;
    //filter.resultsGroupingType = ResultsGroupingType.InAMonth;
    //filter.startDate = null;
    //filter.endDate = null;
    //filter.previousDataStartDate = null;
    this.reportingService.reconfigureFilter(this.filter);
    this.loading = true;
    this.reportingService
      .getReportsAnalysisForParticipantsSummary(this.filter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((response: ParticipantsReportsAnalysisSummary) => {
        // console.log(response);
        this.analysisSummaryData = response;
        this.centerTypesDrilldown = response.centerTypesDrillDown;
        this.expectedPeriodKeys = response.expectedPeriodKeys;
        //this.processAnalysisData(response.centersAttendanceReports);
        this.computeSummaryFigures();
        this.isCentersDetailsChartReady = false;
        this.resetChartData(ReportAnalysisChartType.CentersDetails);
        this.isDataReady = true;
      });
  }

  public onSelectPeriodType(selectedFilter: ReportFilter) {
    // console.log(selectedFilter.periodType);
    /* 
    
    this.filter.periodType = selectedFilter.periodType;
    this.filter.startDate = selectedFilter.startDate;
    this.filter.endDate = selectedFilter.endDate;
    
    */
    this.filter = selectedFilter;
    this.loadData();
  }

  public getPercentageNewCenters(): number {
    try {
      let perc = 0;
      if (
        this.analysisSummaryData &&
        this.analysisSummaryData.totalMeetingCenters &&
        this.analysisSummaryData.totalMeetingCenters.allMeetingCenters &&
        this.analysisSummaryData.totalMeetingCenters.newCenters
      ) {
        perc =
          (this.analysisSummaryData.totalMeetingCenters.newCenters /
            this.analysisSummaryData.totalMeetingCenters.allMeetingCenters) *
          100;
      }

      return perc;
    } catch (e) {
      return 0;
    }
  }

  private computeSummaryFigures() {
    this.dashboard = new AnalysisDashboardItemsForParticipants();

    if (this.analysisSummaryData && this.analysisSummaryData.reports) {
      this.dashboard.totalMales = sumBy(
        this.analysisSummaryData.reports,
        p => p.males
      );
      this.dashboard.totalFemales = sumBy(
        this.analysisSummaryData.reports,
        p => p.females
      );
      this.dashboard.totalChildren = sumBy(
        this.analysisSummaryData.reports,
        p => p.children
      );
      this.dashboard.totalAdults = sumBy(
        this.analysisSummaryData.reports,
        p => p.adults
      );
      this.dashboard.totalCompleted.value = sumBy(
        this.analysisSummaryData.reports,
        p => p.completed
      );
      this.dashboard.totalInProgress.value = sumBy(
        this.analysisSummaryData.reports,
        p => p.inProgress
      );
      this.dashboard.totalHolyGhostBaptism.value = sumBy(
        this.analysisSummaryData.reports,
        p => p.newBaptism
      );
      this.dashboard.totalNewConverts.value = sumBy(
        this.analysisSummaryData.reports,
        p => p.newConverts
      );
      this.dashboard.totalRegistered = sumBy(
        this.analysisSummaryData.reports,
        p => p.registered
      );

      this.dashboard.totalInProgress.percentage =
        (this.dashboard.totalInProgress.value /
          (this.dashboard.totalRegistered || 1)) *
        100;

      this.dashboard.totalHolyGhostBaptism.percentage =
        (this.dashboard.totalHolyGhostBaptism.value /
          (this.dashboard.totalRegistered || 1)) *
        100;

      this.dashboard.totalNewConverts.percentage =
        (this.dashboard.totalNewConverts.value /
          (this.dashboard.totalRegistered || 1)) *
        100;

      this.dashboard.totalCompleted.percentage =
        (this.dashboard.totalCompleted.value /
          (this.dashboard.totalRegistered || 1)) *
        100;

      this.dashboard.genderChartData.push(
        ...[this.dashboard.totalMales, this.dashboard.totalFemales]
      );
      this.dashboard.ageGroupChartData.push(
        ...[this.dashboard.totalChildren, this.dashboard.totalAdults]
      );
    }
    this.prepareTrendsCharts(this.analysisSummaryData.reports);
  }

  private prepareTrendsCharts(reports: ParticipantsAnalysisReportItem[]) {
    try {
      this.resetChartData(ReportAnalysisChartType.Trend);

      this.expectedPeriodKeys.forEach(key => {
        const groupedData = _filter(reports, function(
          item: ParticipantsAnalysisReportItem
        ) {
          return (
            item[key.key] == key.value && item[key.parentKey] == key.parentValue
          );
        });
        //console.log(groupedData);
        this.trendsChartData[0].data.push(
          sumBy(groupedData, item => item.registered)
        );

        this.trendsChartData[1].data.push(
          sumBy(groupedData, item => item.completed)
        );

        this.trendsChartLabels.push(this.reportingService.getChartKey(key));
      });

      /* this.expectedPeriodKeys.forEach(key => {
        this.trendsChartLabels.push(this.reportingService.getChartKey(key));
      });*/
      this.isTrendsChartReady = true;
    } catch (e) {}
  }

  public getPercentageValue(allData: number, extract: number): number {
    try {
      let perc = 0;
      if (allData && extract) {
        perc = (extract / allData) * 100;
      }

      return perc;
    } catch (e) {
      return 0;
    }
  }

  onSelectCenterTypeDrillDown(centerTypeId: number) {
    // console.log(centerTypeId);
    if (centerTypeId) {
      this.filter.descendantsCenterTypeId = centerTypeId;
      this.getCentersAnalysisDetails();
    }
  }

  getCentersAnalysisDetails() {
    //this.filter.loadAllMeetingCenters = true; // default
    this.loading = true;
    this.reportingService
      .getReportsAnalysisForParticipantsDetailsByCenters(this.filter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        // console.log(response);
        this.resetChartData(ReportAnalysisChartType.CentersDetails);
        this.analysisDetailsByCenters = response;
        this.prepareCentersChart();
      });
  }

  private prepareCentersChart() {
    try {
      const reports: ParticipantsReportsAnalysisDetailsByCenter[] = this
        .analysisDetailsByCenters;

      reports.forEach((center: ParticipantsReportsAnalysisDetailsByCenter) => {
        if (center.report) {
          this.centersChartData[0].data.push(center.report.registered);
          this.centersChartData[1].data.push(center.report.completed);
          this.centersChartData[2].data.push(center.report.inProgress);
        } else {
          this.centersChartData[0].data.push(0);
          this.centersChartData[1].data.push(0);
          this.centersChartData[2].data.push(0);
        }

        this.centersChartLabels.push(center.centerName);
      });

      this.isCentersDetailsChartReady = true;
    } catch (e) {}
  }

  /* public onSelectCenterDataViewMode(mode: string) {
    this.centerDataViewMode = mode;
  }*/

  ngOnDestroy(): void {
    try {
      this.routeSubscription.unsubscribe();
      this.selectedCenterForFilteringSubscription.unsubscribe();
    } catch (e) {}
  }
}
