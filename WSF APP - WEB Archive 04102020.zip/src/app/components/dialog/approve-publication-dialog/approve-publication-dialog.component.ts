import { Component, OnInit, EventEmitter, Output } from "@angular/core";
import { BsModalRef } from "ngx-bootstrap/modal";
import {
  Publication,
  PublicationAttachment
} from "../../../models/publications.models";
import { PublicationService } from "../../../services/components-services/publications.service";
import { finalize } from "rxjs/operators";
import {
  ResponseModel,
  ApprovalStatus,
  ApprovalPost
} from "../../../models/utilities.models";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";

@Component({
  selector: "app-approve-publication-dialog",
  templateUrl: "./approve-publication-dialog.component.html",
  styleUrls: ["./approve-publication-dialog.component.scss"]
})
export class ApprovePublicationDialogComponent implements OnInit {
  publication: Publication;
  loading: boolean = false;
  publicationIdKey: string;
  @Output() action = new EventEmitter<boolean>();

  constructor(
    private publicationService: PublicationService,
    private apiService: APIService,
    public bsModalRef: BsModalRef,
    private sweetAlertService: SweetAlertService
  ) {}

  ngOnInit() {
    this.displayPublication();
    //console.log(this.publication);
  }

  private displayPublication() {
    this.loading = true;
    this.publicationService
      .getPublicationDetail(this.publicationIdKey)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.publication = response;
      });
  }

  public downloadAttachment(attachment: PublicationAttachment) {
    this.loading = true;
    this.apiService
      .downloadAttachment(
        ApiRoutes.church_publication.publication_download,
        attachment.fileName,
        attachment.fileMimeType
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(blob => {
        /*console.log(blob);

        //var blob = new Blob([blob], { type: attachment.fileMimeType });
        var filename = "file.pdf";
        saveAs(blob, filename);

        //console.log(blob);
        //saveAs(blob, attachment.fileName); //attachment.fileName

        //var urlCreator = window.URL;
        //return this._sanitizer.bypassSecurityTrustUrl(
        //  urlCreator.createObjectURL(blob)
        // );*/

        //console.log(blob);
        var newBlob = new Blob([blob], { type: attachment.fileMimeType });
        //saveAs(blob, attachment.fileName);

        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(newBlob, attachment.fileName);
        } else {
          // For other browsers:
          // Create a link pointing to the ObjectURL containing the blob.
          const href = window.URL.createObjectURL(newBlob);

          var link = document.createElement("a");
          link.href = href;
          link.download = attachment.fileName;
          try {
            document.getElementById("domReferenceToModal").appendChild(link);
          } catch (e) {}
          // this is necessary as link.click() does not work on the latest firefox
          link.dispatchEvent(
            new MouseEvent("click", {
              bubbles: true,
              cancelable: true,
              view: window
            })
          );

          setTimeout(function() {
            // For Firefox it is necessary to delay revoking the ObjectURL
            try {
              document.getElementById("domReferenceToModal").removeChild(link);
              // document.removeChild(link);
            } catch (e) {
              console.error(e);
            }
            try {
              window.URL.revokeObjectURL(href);
            } catch (e) {}
          }, 100);
        }
      });
  }

  public approveItem() {
    const status = new ApprovalPost();
    status.status = ApprovalStatus.Approved;
    status.itemId = 0;
    status.itemIdKey = this.publicationIdKey;

    const confirmMessage =
      "This Publication will be approved and become accessible to designated Users.";
    const sucessMessage = "Publication successfully approved";

    //console.log(_status);
    this.sweetAlertService.showConfirm(confirmMessage).then(response => {
      if (response.value) {
        this.loading = true;
        this.publicationService
          .approveItem(0, status)
          .pipe(finalize(() => (this.loading = false)))
          .subscribe((response: ResponseModel) => {
            this.sweetAlertService.showSuccess(sucessMessage);
            this.action.emit(true); //<< here you can send object  instead of true
            this.bsModalRef.hide();
          });
      }
    });
  }

  public disapproveItem() {
    const status = new ApprovalPost();
    status.status = ApprovalStatus.Disapproved;
    status.itemId = 0;
    status.itemIdKey = this.publicationIdKey;

    const confirmMessage = "This Publication will be disapproved.";
    const sucessMessage = "Publication successfully disapproved";

    this.sweetAlertService
      .showPrompt(confirmMessage, "Disapproval Reasons and other comments")
      .then(response => {
        //console.log(response);
        if (response.value) {
          status.approvalComment = response.value;
          this.loading = true;
          this.publicationService
            .approveItem(0, status)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              this.sweetAlertService.showSuccess(sucessMessage);
              this.action.emit(true); //<< here you can send object  instead of true
              this.bsModalRef.hide();
            });
        }
      });
  }
}
