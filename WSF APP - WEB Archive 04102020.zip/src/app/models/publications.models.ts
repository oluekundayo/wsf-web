import {
  PaginatorFilter,
  ApprovalStatus,
  VisibilityStatus,
  StatusReport
} from "./utilities.models";
import { PositionLevel } from "./centers.models";
import { ObjectProperty } from "./reporting.models";

export enum PublicationPageType {
  PublicationsList,
  BookmarkList,
  SearchList,
  ApprovalList
}

export enum TestimonyPageType {
  TestimoniesList,
  BookmarkList,
  SearchList,
  ApprovalList
}

export class PaginatedPublications {
  publications: Publication[] = [];
  paginator: PaginatorFilter;
}

export class Publication {
  //id: number;
  idKey: string;
  publicationCategoryId: number;
  publicationCategoryName: string;
  subject: string;
  //publishAt: Date;
  createdAt: Date;
  message: string;
  signedBy: string;
  comment: string;
  approvalComment: string;
  signedAt: Date;
  removeAt: Date;
  approvalStatus: ApprovalStatus;
  visibilityStatus: VisibilityStatus;
  accessibleBy: PositionLevel[];
  hasAttachments: boolean;
  attachments: PublicationAttachment[];
  category: PublicationCategory;
  pagination: PaginatorFilter;
  hasBeenBookmarked: boolean;
}

export class PublicationTimeline {
  year: number;
  month: string;
  itemsKeys: string;
  pKey: string;
  count: number;
  publications: Publication[] = [];
}

export class PublicationCategory {
  id: number;
  name: string;
  description: string;
}

export class PublicationAttachment {
  id: number;
  publicationId: number;
  fileName: string;
  filePath: string;
  fileMimeType: string;
  fileExtension: string;
  fileSize: number;
}

export class PublicationsStatusReport {
  counts: StatusReport;
  trends: StatusReport[];
  expectedPeriodKeys: ObjectProperty[];
}
