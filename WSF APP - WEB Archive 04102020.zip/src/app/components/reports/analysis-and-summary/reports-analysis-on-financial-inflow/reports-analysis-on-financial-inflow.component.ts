import { Component, OnInit, AfterViewInit, ViewChild } from "@angular/core";
import { ReportingService } from "../../../../services/components-services/reporting.service";
import { finalize } from "rxjs/operators";
import {
  ReportFilter,
  ObjectProperty
} from "../../../../models/reporting.models";
import {
  ReportAnalysisPeriodType,
  Lookup,
  FollowUpPageMode,
  ReportAnalysisPageMode
} from "../../../../models/utilities.models";
import {
  MeetingFinancialAnalysis,
  MeetingOfferingType,
  AmountPerCurrency,
  FlattenedMeetingOffering,
  FinancialConstant,
  OfferingTypeGroupAnalysis,
  CurrenciesGroundTotal,
  FilteredCentersOfferingsAnalysis
} from "../../../../models/reports.analysis.models";

import {
  get,
  find,
  sum,
  flatMap,
  reduce,
  map,
  filter,
  sumBy,
  chain,
  cloneDeep,
  groupBy,
  isEqual,
  uniqWith,
  isEmpty
} from "lodash";
import { Chain } from "@angular/compiler";
import { ChartOptions } from "chart.js";
import { DecimalPipe } from "@angular/common";
import { BaseChartDirective } from "ng2-charts";

@Component({
  selector: "app-reports-analysis-on-financial-inflow",
  templateUrl: "./reports-analysis-on-financial-inflow.component.html",
  styleUrls: ["./reports-analysis-on-financial-inflow.component.scss"]
})
export class ReportsAnalysisOnFinancialInflowComponent
  implements OnInit, AfterViewInit {
  @ViewChild(BaseChartDirective, {static:true}) chart: BaseChartDirective;

  public loading: boolean = false;
  public filter: ReportFilter = new ReportFilter();
  public isFanancialSummaryComputationDone: boolean = false;
  public summaryPageMode: ReportAnalysisPageMode = ReportAnalysisPageMode.Chart;
  public summaryPageCurrenciesGroundTotal: CurrenciesGroundTotal = new CurrenciesGroundTotal();
  public centersCurrenciesGroundTotal: CurrenciesGroundTotal = new CurrenciesGroundTotal();
  public filterCentersByMeetingType: number = 0;
  public filterCentersByOfferingType: number = 0;

  public currencies: FinancialConstant[] = [];
  public offeringTypes: FinancialConstant[] = [];
  public meetingTypes: FinancialConstant[] = [];
  public offeringTypesTabData: OfferingTypeGroupAnalysis[] = [];
  private flattenedMeetingsOfferings: FlattenedMeetingOffering[] = [];
  private flattenedCentersOfferings: FlattenedMeetingOffering[] = [];
  public filteredCentersOfferings: FilteredCentersOfferingsAnalysis[] = [];
  private expectedPeriodKeys: ObjectProperty[];

  public chartColors: Array<any> = [];
  public summaryPageOfferingTypesChartData: any[] = [];
  public summaryPageMeetingTypesChartData: any[] = [];
  public summaryPageOfferingTypesChartOptions: ChartOptions;
  public summaryPageMeetingTypesChartOptions: ChartOptions;
  public offeringTypesChartLabels: string[];
  public trendsChartLabels: string[];
  public meetingTypesChartLabels: string[];
  public selectedPeriodDescription: string = "";

  constructor(
    private reportingService: ReportingService,
    private decimalPipe: DecimalPipe
  ) {
    this.filter.periodType = ReportAnalysisPeriodType.ThisMonth;
  }

  ngOnInit() {
    this.reportingService.reconfigureFilter(this.filter);
    this.getSelectedPeriodDescription();
    this.getFinancialConstants();
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
  }

  private initCharts() {
    this.summaryPageOfferingTypesChartOptions = this.getChartOptionsInitializer(
      "Total In-Flow Per Seed Type"
    );

    this.summaryPageMeetingTypesChartOptions = this.getChartOptionsInitializer(
      "Total In-Flow Per Meeting",
      "#1E90FF"
    );

    this.summaryPageOfferingTypesChartData = this.getChartDatasetInitializer();
    this.summaryPageMeetingTypesChartData = this.getChartDatasetInitializer();
  }

  private populateChartLabels() {
    this.offeringTypesChartLabels = map(this.offeringTypes, e => e.name);
    this.trendsChartLabels = map(
      this.expectedPeriodKeys,
      e => e.dataPeriodLabel
    );
    this.meetingTypesChartLabels = map(this.meetingTypes, e => e.name);
  }

  private getSelectedPeriodDescription(): string {
    try {
      const startDate = this.filter.startDate;
      const endDate = this.filter.endDate;
      var options = { year: "numeric", month: "short", day: "numeric" };

      const sub =
        startDate.toLocaleDateString("en-US", options).toUpperCase() +
        "  -  " +
        endDate.toLocaleDateString("en-US", options).toUpperCase();

      this.selectedPeriodDescription = sub;

      return sub;
    } catch (e) {
      return "";
    }
  }

  private getChartOptionsInitializer(
    title: string = "",
    titleColor: string = "#FF0000"
  ): ChartOptions {
    try {
      const trendsChartOptions: ChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        animation: {
          duration: 1000
        },
        legend: { position: "bottom" },
        title: {
          display: true,
          fontSize: 15,
          padding: 17,
          fontColor: titleColor, //"#FF0000", //"#B22222",
          fontStyle: "bold",
          text: title
        },
        scales: { xAxes: [{ stacked: true }], yAxes: [{ stacked: true }] },
        plugins: {
          chartJsPluginSubtitle: {
            display: true,
            fontSize: 13,
            fontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
            fontColor: "#888",
            fontStyle: "bold",
            //paddingTop: 10,
            //paddingBottom: 15,
            text: this.selectedPeriodDescription
          },
          datalabels: {
            formatter: function(value, context) {
              //console.log(context);
              //return context.chart.data.labels[context.dataIndex];
              if (!value) {
                return value;
              } else {
                return (
                  context.dataset.label.split("|")[0] +
                  new DecimalPipe("en-US").transform(value, "1.2-2")
                );
              }
            }
          }
        }
      };
      return trendsChartOptions;
    } catch (e) {}
  }

  private getChartDatasetInitializer(): any[] {
    try {
      const trendsChartData = [];
      /* [{ data: [], label: "NAIRA" },
        { data: [], label: "USD" },
        { data: [], label: "CAD" },
        { data: [], label: "EUR" },
        { data: [], label: "POUND" },
        { data: [], label: "OTHERS" }
      ];*/
      this.currencies.forEach(currency => {
        trendsChartData.push({
          data: [],
          label: `${currency.subDescription}|${currency.name.toUpperCase()}`,
          hidden: currency.hideOnChartByDefault
        });
      });
      /* {
        responsive: true,
        maintainAspectRatio: false,
        //scaleShowVerticalLines: false,
        //fill: false,
        // We use these empty structures as placeholders for dynamic theming.
        // scales: { xAxes: [{}], yAxes: [{}] },
        title: {
          display: true,
          text: "In-Flow Trends By Currencies"
        }
        // plugins: {
          //  datalabels: {
           // anchor: "end",
           // align: "end"
         // }
       // }
      };*/
      /* this.offeringTypes.forEach(type => {
        this.trendsChartDataBucket.push(cloneDeep(trendsChartData));
      }); */
      return trendsChartData;
    } catch (e) {}
  }

  private getFinancialConstants() {
    this.loading = true;
    this.reportingService
      .getFinancialConstants()
      //.pipe(finalize(() => (this.loading = false)))
      .subscribe(
        response => {
          try {
            this.currencies = response.currencies;
            this.offeringTypes = response.offeringTypes;
            this.meetingTypes = response.meetingTypes;
            this.initCharts();
            this.offeringTypes.forEach((type, index) => {
              this.offeringTypesTabData.push({
                id: type.id,
                name: type.name,
                meetingTypes: [],
                periods: [],
                pageMode: ReportAnalysisPageMode.Chart,
                hasDataLoaded: false,
                isChartDataReady: false,
                //meetingTypesChartLabel: [],
                //periodsChartLabel: [],
                periodsChartData: this.getChartDatasetInitializer(),
                meetingTypesChartData: this.getChartDatasetInitializer(),
                meetingTypesChartOptions: this.getChartOptionsInitializer(
                  type.name + " In-Flow Per Meeting",
                  "#5DADE2" //"#D35400"
                ),
                periodsChartOptions: this.getChartOptionsInitializer(
                  type.name + " In-Flow Over a Period",
                  "#D35400" //"#1E90FF", "#85929E"
                ),
                groundTotals: new CurrenciesGroundTotal()
              });
            });
          } catch (e) {
            this.loading = false;
          }
          //console.log(response);
          this.getFinancialReportsForMeetings();
        },
        error => {
          this.loading = false;
        }
      );
  }

  private getFinancialReportsForMeetings() {
    this.loading = true;
    this.reportingService
      .getFinancialReportsForMeetings(this.filter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(
        response => {
          try {
            this.flattenedMeetingsOfferings = response.offerings;
            this.expectedPeriodKeys = response.expectedPeriodKeys;
            this.populateChartLabels();
            this.getSumTotalOfOfferingTypes();
            this.getSumTotalOfMeetingTypes();
            this.refreshChart();
            //this.prepareCharts();
            this.isFanancialSummaryComputationDone = true;
            //console.log(response);
            this.loading = false;
          } catch (e) {
            console.log(e);
            this.loading = false;
          }
        },
        error => {
          this.loading = false;
        }
      );
  }

  refreshChart() {
    setTimeout(() => {
      if (this.chart && this.chart.chart && this.chart.chart.config) {
        //this.chart.chart.config.data.labels = this.labels_pie;
        this.resetChartSubtitle();
        this.chart.chart.update();
      }
    });
  }

  private resetChartSubtitle() {
    try {
      //this.summaryPageMeetingTypesChartOptions.plugins = null;

      // console.log(this.chart);

      this.chart.options.plugins.chartJsPluginSubtitle.text = this.selectedPeriodDescription;
      this.summaryPageMeetingTypesChartOptions.plugins.chartJsPluginSubtitle.text = this.selectedPeriodDescription;
      this.summaryPageOfferingTypesChartOptions.plugins.chartJsPluginSubtitle.text = this.selectedPeriodDescription;

      console.log(this.summaryPageMeetingTypesChartOptions.plugins);

      this.offeringTypesTabData.forEach(offering => {
        offering.meetingTypesChartOptions.plugins.chartJsPluginSubtitle.text = this.selectedPeriodDescription;
        offering.periodsChartOptions.plugins.chartJsPluginSubtitle.text = this.selectedPeriodDescription;
      });

      //this.chart.chart.update();
      //this.chart.update();
      //this.chart.chart.update();
      //  this.chart.refresh();
    } catch (e) {
      console.log(e);
    }
  }

  public onSelectPeriodType(selectedFilter: ReportFilter) {
    this.filter = selectedFilter;
    this.reportingService.reconfigureFilter(this.filter);
    this.getSelectedPeriodDescription();
    this.getFinancialReportsForMeetings();
  }

  private getSumTotalOfOfferingTypes(): any {
    const groupOfferingTypes = chain(this.flattenedMeetingsOfferings)
      .groupBy(x => x.offeringTypeId)
      .map((value, key) => ({
        offeringType: parseInt(key),
        amountTypes: value
      }))
      .value();

    groupOfferingTypes.forEach(type => {
      var offerings = type.amountTypes.reduce(function(sumByCurrency, item) {
        if (item.currencyId > 0) {
          sumByCurrency[item.currencyId] =
            (sumByCurrency[item.currencyId] || 0) + (item.amount || 0);
        }
        return sumByCurrency;
      }, {});

      const sumTotalOfferingTypes = find(
        this.offeringTypes,
        (e: FinancialConstant) => {
          return e.id == type.offeringType;
        }
      );

      this.currencies.forEach(currency => {
        this.summaryPageCurrenciesGroundTotal.forAllOfferingTypes[currency.id] =
          (this.summaryPageCurrenciesGroundTotal.forAllOfferingTypes[
            currency.id
          ] || 0) + offerings[currency.id] || 0;
      });

      if (sumTotalOfferingTypes) {
        sumTotalOfferingTypes.amountTypesSumTotal = offerings;
      }
    });

    // setTimeout(() => {
    this.offeringTypes.forEach(type => {
      if (type.amountTypesSumTotal) {
        this.currencies.forEach((currency, index) => {
          this.summaryPageOfferingTypesChartData[index].data.push(
            type.amountTypesSumTotal[currency.id] || 0
          );
        });
      }
    });
    //});
  }

  private getSumTotalOfMeetingTypes(): any {
    const groupedMeetingTypes = chain(this.flattenedMeetingsOfferings)
      .groupBy(x => x.meetingId)
      .map((value, key) => ({
        meetingType: parseInt(key),
        amountTypes: value
      }))
      .value();

    groupedMeetingTypes.forEach(type => {
      var offerings = type.amountTypes.reduce(function(sumByCurrency, item) {
        if (item.currencyId > 0) {
          sumByCurrency[item.currencyId] =
            (sumByCurrency[item.currencyId] || 0) + (item.amount || 0);
        }
        return sumByCurrency;
      }, {});

      const sumTotalMeetingTypes = find(
        this.meetingTypes,
        (e: FinancialConstant) => {
          return e.id == type.meetingType;
        }
      );

      this.currencies.forEach(currency => {
        this.summaryPageCurrenciesGroundTotal.forAllMeetingTypes[currency.id] =
          (this.summaryPageCurrenciesGroundTotal.forAllMeetingTypes[
            currency.id
          ] || 0) + (offerings[currency.id] || 0);
      });

      sumTotalMeetingTypes.amountTypesSumTotal = offerings;
    });

    this.meetingTypes.forEach(type => {
      this.currencies.forEach((currency, index) => {
        this.summaryPageMeetingTypesChartData[index].data.push(
          type.amountTypesSumTotal[currency.id] || 0
        );
      });
    });
  }

  private populateOfferingTypeOverAPeriod(
    offeringTypeGroup: OfferingTypeGroupAnalysis,
    groupedOfferingsInAType: FlattenedMeetingOffering[]
  ): any {
    const groupedPeriodTypes = chain(groupedOfferingsInAType)
      .groupBy((x: FlattenedMeetingOffering) => x.dataPeriodLabel)
      .map((value, key) => ({
        dataPeriodLabel: key,
        amountTypes: value
      }))
      .value();

    groupedPeriodTypes.forEach(type => {
      var offerings = type.amountTypes.reduce(function(sumByCurrency, item) {
        if (item.currencyId > 0) {
          sumByCurrency[item.currencyId] =
            (sumByCurrency[item.currencyId] || 0) + (item.amount || 0);
        }
        return sumByCurrency;
      }, {});

      const sumTotalMeetingTypes = find(
        offeringTypeGroup.periods,
        (e: FinancialConstant) => {
          return e.name == type.dataPeriodLabel;
        }
      );

      //console.log(sumTotalMeetingTypes);
      // console.log(offerings);

      this.currencies.forEach((currency, index) => {
        offeringTypeGroup.groundTotals.forAllMeetingTypes[currency.id] =
          (offeringTypeGroup.groundTotals.forAllMeetingTypes[currency.id] ||
            0) + (offerings[currency.id] || 0);
      });

      if (sumTotalMeetingTypes) {
        sumTotalMeetingTypes.amountTypesOverAPeriod = offerings;
      }

      offeringTypeGroup.hasDataLoaded = true;
    });

    offeringTypeGroup.periods.forEach(type => {
      this.currencies.forEach((currency, index) => {
        offeringTypeGroup.periodsChartData[index].data.push(
          type.amountTypesOverAPeriod[currency.id] || 0
        );
      });
    });
  }

  private populateOfferingTypeInMeeting(
    offeringTypeGroup: OfferingTypeGroupAnalysis,
    groupedOfferingsInAType: FlattenedMeetingOffering[]
  ): any {
    const groupedMeetingTypes = chain(groupedOfferingsInAType)
      .groupBy(x => x.meetingId)
      .map((value, key) => ({
        meetingTypeId: parseInt(key),
        amountTypes: value
      }))
      .value();

    groupedMeetingTypes.forEach(type => {
      var offerings = type.amountTypes.reduce(function(sumByCurrency, item) {
        if (item.currencyId > 0) {
          sumByCurrency[item.currencyId] =
            (sumByCurrency[item.currencyId] || 0) + (item.amount || 0);
        }
        return sumByCurrency;
      }, {});

      const sumTotalMeetingTypes = find(
        offeringTypeGroup.meetingTypes,
        (e: FinancialConstant) => {
          return e.id == type.meetingTypeId;
        }
      );

      this.currencies.forEach((currency, index) => {
        offeringTypeGroup.groundTotals.forAllOfferingsOverAPeriods[
          currency.id
        ] =
          (offeringTypeGroup.groundTotals.forAllOfferingsOverAPeriods[
            currency.id
          ] || 0) + (offerings[currency.id] || 0);
      });

      sumTotalMeetingTypes.amountTypesSumTotal = offerings;
      offeringTypeGroup.hasDataLoaded = true;
    });

    offeringTypeGroup.meetingTypes.forEach(type => {
      this.currencies.forEach((currency, index) => {
        offeringTypeGroup.meetingTypesChartData[index].data.push(
          type.amountTypesSumTotal[currency.id] || 0
        );
      });
    });

    // console.log(offeringTypeGroup.meetingTypesChartData);
  }

  public onSelectSeedTypeTab(offeringTypeGroup: OfferingTypeGroupAnalysis) {
    //alert(seedType);
    let fin;

    if (!offeringTypeGroup.meetingTypes.length) {
      this.meetingTypes.forEach(meeting => {
        fin = new FinancialConstant();
        fin.id = meeting.id;
        fin.name = meeting.name;
        fin.amountTypesOverAPeriod = {};
        fin.amountTypesSumTotal = {};
        offeringTypeGroup.meetingTypes.push(fin);
      });
    }

    if (!offeringTypeGroup.periods.length) {
      this.expectedPeriodKeys.forEach(period => {
        fin = new FinancialConstant();
        fin.name = period.dataPeriodLabel;
        fin.amountTypesOverAPeriod = {};
        fin.amountTypesSumTotal = {};
        offeringTypeGroup.periods.push(fin);
      });
    }

    // public summaryPageOfferingTypesChartData: any[] = [];
    // public summaryPageMeetingTypesChartData: any[] = [];

    //this.summaryPageOfferingTypesChartData.

    if (!offeringTypeGroup.hasDataLoaded) {
      const groupedOfferingsInAType = filter(
        this.flattenedMeetingsOfferings,
        (b: FlattenedMeetingOffering) => {
          return b.offeringTypeId == offeringTypeGroup.id;
        }
      );

      this.populateOfferingTypeInMeeting(
        offeringTypeGroup,
        groupedOfferingsInAType
      );
      this.populateOfferingTypeOverAPeriod(
        offeringTypeGroup,
        groupedOfferingsInAType
      );

      /*
      https://github.com/valor-software/ng2-charts/issues/547 
      I had a simplier solution :)
      Just use wrapper canvas inside the div and ngIf for it.

      Then set it to false show variable.
      Change data
      Set show variable to true inside setTimeout(()=>{this.show = true}, 0)
      Impossible stupid, but working.
      */

      setTimeout(() => {
        offeringTypeGroup.isChartDataReady = true;
      }, 0);
    }
  }

  public onSelectCentersFinancialReportsTab() {
    if (!this.filteredCentersOfferings.length) {
      this.reportingService
        .getFinancialReportsForCenters(this.filter)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          this.flattenedCentersOfferings = response;

          this.filteredCentersOfferings = chain(response)
            .map(e => ({
              centerId: e.centerId,
              centerAddress: e.centerAddress,
              centerName: e.centerName,
              centerShortNameFromAddress: e.centerShortNameFromAddress,
              amountTypes: {}
            }))
            .uniqWith(isEqual)
            .value();
          //console.log(response);
          this.runFilterOnCentersOfferings();
        });
    }
  }

  public runFilterOnCentersOfferings() {
    let filteredOfferings: FlattenedMeetingOffering[] = [];

    //please don't remove == 0 here,
    //for some reasons, the 0 selected value is seen as string value instead of number.

    if (
      this.filterCentersByOfferingType == 0 &&
      this.filterCentersByMeetingType == 0
    ) {
      filteredOfferings = this.flattenedCentersOfferings;
    } else {
      filteredOfferings = filter(
        this.flattenedCentersOfferings,
        (b: FlattenedMeetingOffering) => {
          return (
            (this.filterCentersByOfferingType == 0
              ? true
              : b.offeringTypeId == this.filterCentersByOfferingType) &&
            (this.filterCentersByMeetingType == 0
              ? true
              : b.meetingId == this.filterCentersByMeetingType)
          );
        }
      );
    }

    const groupedOfferings = chain(filteredOfferings)
      .groupBy(x => x.centerId)
      .map((value, key) => ({
        centerId: parseInt(key),
        amountTypes: value
      }))
      .value();

    //reset centers Currencies Ground Total
    this.centersCurrenciesGroundTotal.forAllCenters = {};

    if (groupedOfferings.length) {
      groupedOfferings.forEach(type => {
        var offerings = type.amountTypes.reduce(function(sumByCurrency, item) {
          if (item.currencyId > 0) {
            sumByCurrency[item.currencyId] =
              (sumByCurrency[item.currencyId] || 0) + (item.amount || 0);
          }
          return sumByCurrency;
        }, {});

        const center = find(
          this.filteredCentersOfferings,
          (e: FilteredCentersOfferingsAnalysis) => {
            return e.centerId == type.centerId;
          }
        );
        center.amountTypes = offerings;

        this.currencies.forEach(currency => {
          this.centersCurrenciesGroundTotal.forAllCenters[currency.id] =
            (this.centersCurrenciesGroundTotal.forAllCenters[currency.id] ||
              0) + offerings[currency.id] || 0;
        });
      });
    } else {
      this.filteredCentersOfferings.forEach(type => {
        type.amountTypes = {};
      });
    }
  }

  public trackCenterByFn(index, center) {
    return center.centerId; //index;
  }

  /*private getFlattenedOfferingsData(
    meetingsOfferings: MeetingOfferingPerPeriod[]
  ): FlattenedMeetingOffering[] {
    const flats: FlattenedMeetingOffering[] = [];
    let flat = new FlattenedMeetingOffering();

    meetingsOfferings.forEach((meetingOffering: MeetingOfferingPerPeriod) => {
      //Meeting Type

      meetingOffering.offeringsPerPeriod.forEach(
        (offeringPerPeriod: OfferingPerPeriod) => {
          //Periods in this Meeting Type

          offeringPerPeriod.offerings.forEach(offering => {
            //Offerings Types in this Period

            offering.amountTypes.forEach((amount: AmountPerCurrency) => {
              // Amount Types

              flat = new FlattenedMeetingOffering();
              flat.meetingId = meetingOffering.meetingId;
              flat.meetingName = meetingOffering.meetingName;
              flat.meetingSectionId = meetingOffering.meetingSectionId;
              flat.meetingReportOfferingTypeId =
                offering.meetingReportOfferingTypeId;
              flat.meetingReportOfferingTypeName =
                offering.meetingReportOfferingTypeName;
              flat.dataPeriodLabel = offeringPerPeriod.dataPeriodLabel;
              flat.amount = amount.amount;
              flat.currencyId = amount.currencyId;
              flat.currencyName = amount.currencyName;

              flats.push(flat);
            });
          });
        }
      );
    });

    //console.log(flats);

    return flats;
  } */
}
