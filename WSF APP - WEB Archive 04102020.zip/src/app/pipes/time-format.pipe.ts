import { Pipe, PipeTransform } from "@angular/core";
import * as moment from "moment";
@Pipe({
  name: "timeFormat"
})
export class TimeFormatPipe implements PipeTransform {
  transform(value: any, args?: any): any {
    var time = moment.utc(value, "HH:mm:ss");
    return time.format("hh:mm A");
  }
}
