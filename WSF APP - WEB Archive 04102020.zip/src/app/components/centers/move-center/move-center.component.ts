import { finalize } from "rxjs/operators";
import { Component, OnInit, OnDestroy, TemplateRef } from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import {
  Lookup,
  ApiUrlParam,
  ResponseModel
} from "../../../models/utilities.models";
import {
  CenterSearchResult,
  CenterSearchParams,
  DrillDownCenters,
  CenterToMove
} from "../../../models/centers.models";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { filter, cloneDeep } from "lodash";

@Component({
  selector: "app-move-center",
  templateUrl: "./move-center.component.html",
  styleUrls: ["./move-center.component.scss"]
})
export class MoveCenterComponent implements OnInit, OnDestroy {
  loading = false;
  drilledDownCenters: DrillDownCenters[] = [];
  drilledDownCentersForNewParent: DrillDownCenters[] = [];
  centerFinderResults: CenterSearchResult[];
  formGroup: FormGroup;
  modalRef: BsModalRef;
  searchFilter: string = "";
  pagingCurrentPage: number = 1;
  pagingItemsPerPage: number = 10;

  selectedParentCenterToMoveFrom: CenterSearchResult;
  selectedParentCenterToMoveTo: CenterSearchResult;
  selectedCentersToMove: CenterSearchResult[] = [];

  constructor(
    private api: APIService,
    private sweetAlertService: SweetAlertService,
    private modalService: BsModalService,
    private fb: FormBuilder
  ) {
    this.formGroup = fb.group({
      reason: ["", Validators.required],
      deletePermanently: [false]
    });
  }

  ngOnInit() {
    this.drillDownCenters({ centerId: 0 }, 0);

    /*this.loading = true;
    this.api
      .getAll<Lookup[]>(ApiRoutes.centers.centers_types_lookup)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.centerTypes = response;
      });*/
  }

  public drillDownCenters(
    parentCenter: CenterSearchResult,
    selectedIndex: number
  ) {
    //console.log(parentCenter);

    if (parentCenter && parentCenter.centerId >= 0) {
      this.selectedParentCenterToMoveFrom = parentCenter;
      this.loading = true;
      this.api
        .get<CenterSearchResult[]>(
          ApiRoutes.centers.drill_down_centers,
          parentCenter.centerId
        )
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          /* this.drilledDownCenters = filter(
            this.drilledDownCenters,
            (a, index) => {
              return index <= selectedIndex;
            }
          );*/
          this.centerFinderResults = response;
          this.drilledDownCenters.push({
            centerTypeId: response[0].centerTypeId,
            parentCenters: response
          } as DrillDownCenters);

          if (parentCenter.centerId == 0) {
            this.drilledDownCentersForNewParent = cloneDeep(
              this.drilledDownCenters
            );
          }
        });
    }

    this.drilledDownCenters = filter(this.drilledDownCenters, (a, index) => {
      return index <= selectedIndex;
    });
  }

  public drillDownCentersForNewParent(
    parentCenter: CenterSearchResult,
    selectedIndex: number
  ) {
    //console.log(parentCenter);
    if (parentCenter && parentCenter.centerId >= 0) {
      this.selectedParentCenterToMoveTo = parentCenter;
      this.loading = true;
      this.api
        .get<CenterSearchResult[]>(
          ApiRoutes.centers.drill_down_centers,
          parentCenter.centerId
        )
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          this.drilledDownCentersForNewParent.push({
            centerTypeId: response[0].centerTypeId,
            parentCenters: response
          } as DrillDownCenters);
        });
    }
    this.drilledDownCentersForNewParent = filter(
      this.drilledDownCentersForNewParent,
      (a, index) => {
        return index <= selectedIndex;
      }
    );
  }

  public onSelectCenterToMove(selected: boolean, index: number) {
    this.selectedCentersToMove.push(this.drilledDownCenters[index]);
  }

  public openConfirmationModal(
    template: TemplateRef<any>,
    center: CenterSearchResult
  ) {
    if (center) {
      this.modalRef = this.modalService.show(template);
    }
  }

  public removeCenter() {
    this.sweetAlertService
      .showConfirm("Want to proceed to delete this Center?")
      .then(response => {
        if (response.value) {
          const deleteCenter = new CenterToMove();
          //deleteCenter.centerId = this.selectedCenterToDelete.centerId;
          deleteCenter.reason = this.formGroup.value.reason;
          //deleteCenter.deletePermanently = this.formGroup.value.deletePermanently;

          this.processDelete(deleteCenter);
        }
      });
  }

  private processDelete(deleteCenter: CenterToMove) {
    this.loading = true;
    this.api
      .post<ResponseModel>(ApiRoutes.centers.remove_center, deleteCenter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(
        response => {
          const index = this.centerFinderResults.indexOf(null, 0);
          if (index > -1) {
            this.centerFinderResults.splice(index, 1);
          }
          this.sweetAlertService.showMessage(response.message);
        },
        error => {
          this.modalRef.hide();
        }
      );
  }

  ngOnDestroy(): void {}
}
