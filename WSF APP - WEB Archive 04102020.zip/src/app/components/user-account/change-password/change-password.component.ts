import { Component, OnInit, ElementRef } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { finalize } from "rxjs/operators";
import { Router } from "@angular/router";
import { LoginService } from "../../../services/components-services/login.service";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { ResponseModel } from "../../../models/utilities.models";
import { ChangePasswordDetails } from "app/models/user_account.models";
import { UserAccountService } from "../../../services/components-services/user-account.service";

@Component({
  selector: "app-change-password",
  templateUrl: "./change-password.component.html",
  styleUrls: ["./change-password.component.scss"]
})
export class ChangePasswordComponent implements OnInit {
  appName: string = "WSF Portal";
  formGroup: FormGroup;
  loading: boolean = false;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private loginService: LoginService,
    private sweetAlertService: SweetAlertService
  ) {}

  ngOnInit() {
    this.createForm();
  }

  private createForm() {
    this.formGroup = this.fb.group({
      currentPassword: ["", Validators.required],
      newPassword: ["", Validators.required],
      confirmPassword: ["", Validators.required]
    });
  }

  private validateInputs(user: ChangePasswordDetails): ResponseModel {
    const response = new ResponseModel();

    response.isOk = true;
    response.error = "";

    if (!user.currentPassword) {
      response.error += "Your Current Password is required. <br/><br/> ";
      response.isOk = false;
    }

    if (!user.newPassword || user.newPassword.length < 4) {
      response.error +=
        "Password is required and must be of 4 Characters minimum. <br/><br/>";
      response.isOk = false;
    }

    if (user.newPassword != user.confirmPassword) {
      response.error += "Password and Confirm Password must be thesame. ";
      response.isOk = false;
    }

    if (user.newPassword == user.currentPassword) {
      response.error +=
        "Your Current Password should not be thesame as the proposed New Password. ";
      response.isOk = false;
    }

    return response;
  }

  public submitForm() {
    const user = new ChangePasswordDetails();

    user.currentPassword = this.formGroup.value.currentPassword;
    user.newPassword = this.formGroup.value.newPassword;
    user.confirmPassword = this.formGroup.value.confirmPassword;

    const res = this.validateInputs(user);

    if (!res.isOk) {
      this.sweetAlertService.showError(res.error, true);
      return;
    }

    this.sweetAlertService
      .showConfirm("Your Password will be changed")
      .then(response => {
        if (response.value) {
          this.loading = true;
          this.loginService
            .changePassword(user)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              this.sweetAlertService.showSuccess(response.message);
              this.router.navigate(["auth/user/login"]);
            });
        }
      });
  }
}
