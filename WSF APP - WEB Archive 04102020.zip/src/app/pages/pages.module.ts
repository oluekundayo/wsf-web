import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { PagesRoutes } from "./pages.routing";

import { RegisterComponent } from "./register/register.component";
import { LockComponent } from "./lock/lock.component";
import { LoginComponent } from "./login/login.component";
import { SharedModule } from "../app.shared.module";
import { NgxLoadingModule, ngxLoadingAnimationTypes } from "ngx-loading";
import { UpdateProfileDialogComponent } from "../components/dialog/update-profile-dialog/update-profile-dialog.component";
import { NgBootstrapFormValidationModule } from "ng-bootstrap-form-validation";
import { NgSelectModule } from "@ng-select/ng-select";
import { FaqComponent } from "./faq/faq.component";
import { ForgotPasswordComponent } from "./forgot-password/forgot-password.component";

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(PagesRoutes),
    FormsModule,
    ReactiveFormsModule,
    NgxLoadingModule,
    NgSelectModule,
    NgBootstrapFormValidationModule
  ],
  declarations: [
    LoginComponent,
    RegisterComponent,
    LockComponent,
    UpdateProfileDialogComponent,
    ForgotPasswordComponent,
    FaqComponent
  ],
  entryComponents: [UpdateProfileDialogComponent]
})
export class PagesModule {}
