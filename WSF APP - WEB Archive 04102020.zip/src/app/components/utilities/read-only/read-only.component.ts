import { Component, OnInit, Input } from "@angular/core";
import { ReadOnlyItemsGroup } from "../../../models/utilities.models";

@Component({
  selector: "app-read-only",
  templateUrl: "./read-only.component.html",
  styleUrls: ["./read-only.component.scss"]
})
export class ReadOnlyComponent implements OnInit {
  @Input() groups: ReadOnlyItemsGroup[] = [];

  constructor() {}

  ngOnInit() {}
}
