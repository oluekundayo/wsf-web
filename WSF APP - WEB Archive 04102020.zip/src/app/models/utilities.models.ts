import { BsModalRef } from "ngx-bootstrap/modal";

export class Lookup {
  id: number;
  name: string;
  description?: string;
  isInEditMode?: boolean;
  itemsCount?: number;
}

export class KeyValueModel {
  key: any;
  value: any;
  description?: any;
}

export class ApiUrlParam {
  name: string;
  value: any;
}

export class ResponseModel {
  message: string;
  data: any;
  error: string;
  isOk: boolean;
}

export class PageFilterDescription {
  startDate: string;
  endDate: any;
  category: string = "None";
  text: string = "";
  //hasFilterRunning: boolean = false;
  //currentYear: number = new Date().getFullYear();
}

export class PaginatorFilter {
  // for api communication
  pageSize: number = 0;
  lastMaxId?: number = 0;
  lastMaxDate?: Date = null;
  lastMinId?: number = 0;
  lastMinDate?: Date = null;
  direction?: PageDirection = PageDirection.NEXT;
  totalItemsCount?: number = 0;
  approvalStatus?: ApprovalStatus = ApprovalStatus.Approved;
  limitToBookmarks?: boolean = false;
  filterStartDate?: Date;
  filterEndDate?: Date;
  filterItemsCategoryId?: number;
  // for front pages design
  /* currentPage?: number = 0;
  totalPages?: number = 0;
  startPage?: number = 0;
  endPage?: number = 0;
  startIndexForItemsOfCurrentPage?: number = 0;
  endIndexForItemsOfCurrentPage?: number = 0;
  pagesList?: number[] = [];
  noItemsToShow?: number = 0;*/

  // for front pages design
  currentPageStart?: number;
  currentPageEnd?: number;
}

export class Contact {
  lastname?: string;
  firstname?: string;
  fullName: string;
  phone?: string;
  email?: string;
  address?: string;
  gender?: string;
}

export class StatusReport {
  month: number;
  year: number;
  allItemsCount: number;
  approvedItemsCount: number;
  unapprovedItemsCount: number;
  disapprovedItemsCount: number;
  notVisibleItemsCount: number;
  unproofreadItemsCount: number;
}

export class SimpleFilterHolderWithDescription {
  filter?: SimpleFilter;
  description?: PageFilterDescription;
  isAdvancedSearch?: boolean;
  bsModalRef: BsModalRef;
}

export class SimpleFilter {
  startDate?: Date;
  endDate?: Date;
  searchText?: string;
  status?: ApprovalStatus;
  getOnlyDataTrend?: boolean;
  categories?: number[];
}

export class MyHttpOptions {
  headers?: any;
  observe?: any;
  params?: any;
  search?: URLSearchParams;
  reportProgress?: any;
  responseType?: any;
  withCredentials?: any;
}

export enum ApprovalStatus {
  Approved = "Approved",
  Unapproved = "Unapproved",
  Disapproved = "Disapproved",
  NotVisible = "NotVisible",
  Visible = "Visible",
  Unproofread = "Unproofread",
  All = "All"
}

export enum VisibilityStatus {
  Visible = "Visible",
  NotVisible = "NotVisible"
}

export enum ActiveStatus {
  Active = "Active",
  Inactive = "Inactive"
}

export enum AppResourceType {
  Menu = "Menu",
  Meeting = "Meeting",
  Approval = "Approval"
}

export enum CRUD {
  Create = "Create",
  Read = "Read",
  Update = "Update",
  Delete = "Delete"
}

export enum AppApprovalType {
  ApproveMeetingReportEdit = "ApproveMeetingReportEdit",
  ApproveCombinedMeeting = "ApproveCombinedMeeting",
  ApprovePublications = "ApprovePublications",
  ApproveTestimonies = "ApproveTestimonies",
  ProofreadTestimonies = "ProofreadTestimonies"
}

export enum CenterMemberShipStatus {
  CenterMember = "CenterMember",
  MeetingParticipant = "MeetingParticipant"
}

export enum CenterMemberConversionStatus {
  NewConvert = "NewConvert",
  FirstTimer = "FirstTimer",
  None = "None"
}

export enum MeetingReportingType {
  Attendance = "Attendance",
  SingleParticipation = "SingleParticipation",
  MultipleParticipations = "MultipleParticipations"
}

export enum ReportAnalysisPeriodType {
  Today = "Today",
  ThisWeek = "ThisWeek",
  ThisMonth = "ThisMonth",
  ThisQuarter = "ThisQuarter",
  ThisYear = "ThisYear",
  Custom = "Custom"
}

export enum FollowUpPageMode {
  SummaryVisuals = "SummaryVisuals",
  CentersVisual = "CentersVisual",
  ContactsList = "ContactsList"
}

export enum DataCacheMode {
  Approved = "Approved",
  Unapproved = "Unapproved",
  Disapproved = "Disapproved",
  Bookmarked = "Bookmarked",
  NotVisible = "NotVisible",
  Search = "Search",
  All = "All"
}

export enum ReportAnalysisResultsGroupingType {
  /*Days,
  Weeks,
  Months,
  Quarters,
  Years*/
  InADay = "InADay",
  InAWeek = "InAWeek",
  InAMonth = "InAMonth",
  InAQuarter = "InAQuarter",
  InAYearByMonths = "InAYearByMonths",
  InYearsByQuarters = "InYearsByQuarters",
  InYears = "InYears"
}

export class ReadOnlyItem {
  value: any;
  label: string;
  type?: string;
  hidden?: boolean;
}

export class ReadOnlyItemsGroup {
  caption: string;
  items: ReadOnlyItem[];
}

export class ApprovalTypeList {
  itemId: number;
  itemIdKey?: string;
  status: string;
  approvalComment?: string;
  data?: any;
}

export class ApprovalPost {
  itemId: number;
  itemIdKey?: string;
  status: string;
  approvalComment?: string;
  data?: any;
}

export class BookmarkPost {
  itemId: number;
  itemIdKey?: string;
  flagAsBookmark: boolean;
}

export enum SmsRecipientOptions {
  All = "All",
  Selected = "Selected",
  NewBirths = "New Births",
  FirstTimers = "First timers",
  HolyGhostBaptism = "Newly Baptised in Holy Ghost"
}

/*export enum SmsRecipientOptionKey {
  All,
  Selected,
  NewConverts,
  FirstTimers,
  HolyGhostBaptism
}*/

/*export class DateRangeFilter {
  itemId?: number;
  startDate: Date;
  endDate: Date;
  status?: string;
}*/

export enum PageDirection {
  CURRENT = "Current",
  NEXT = "Next",
  PREVIOUS = "Previous",
  REPEAT = "Repeat"
}

export enum ReportAnalysisDataStatus {
  Previous = "Previous",
  Current = "Current",
  Started = "Started",
  Completed = "Completed",
  None = "None"
}

export enum ReportAnalysisChartType {
  Summary = "Summary",
  Trend = "Trend",
  CentersDetails = "CentersDetails"
}

export enum ReportAnalysisPageMode {
  Table = "Table",
  Chart = "Chart"
}

export enum ReportAnalysisResultsType {
  Summary = "Summary",
  Details = "Details"
}

export enum ReportPageActionType {
  Submit = "Submit",
  Edit = "Edit",
  Analyze = "Analyze"
}

export enum DashboardItemType {
  TestimoniesInfo = "TestimoniesInfo",
  PublicationsInfo = "PublicationsInfo",
  FollowUpContactsInfo = "FollowUpContactsInfo",
  PendingTestimonies = "PendingTestimonies",
  PendingPublications = "PendingPublications"
}

export enum Privilege {
  CanAccessPage = "CanAccessPage",
  CanSubmit = "CanSubmit",
  CanView = "CanView",
  CanDelete = "CanDelete",
  CanEdit = "CanEdit",
  CanReview = "CanReview"
}
