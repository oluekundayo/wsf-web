import { DashboardItemType } from "./utilities.models";

//Metadata
export interface MenuInfo {
  id: number;
  url: string;
  name: string;
  type: string; //link, sub, external
  icon: string;
  // icon: string;
  children?: ChildrenItems[];
}

export interface ChildrenItems {
  id: number;
  url: string;
  name: string;
  ab?: string; // abbreviations
  type?: string; //link, sub, external,
}

export class DashboardItem {
  itemType: DashboardItemType;
  itemsCount: number;
  latestItemDate: Date;
  canAccessItems: boolean;
}
