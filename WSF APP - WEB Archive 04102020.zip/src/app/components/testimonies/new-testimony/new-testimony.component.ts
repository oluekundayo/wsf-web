import { Component, OnInit, Inject } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from "@angular/forms";
import { TestimonyService } from "../../../services/components-services/testimony.service";
import {
  TestimonyClassification,
  Testimony
} from "../../../models/testimonies.models";
import { AngularEditorConfig } from "@kolkov/angular-editor";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import {
  ResponseModel,
  SimpleFilter,
  ApprovalStatus,
  ReportAnalysisPeriodType
} from "../../../models/utilities.models";
import { finalize } from "rxjs/operators";
import { filter } from "lodash";
import { UtilitiesService } from "../../../services/utils/utilities.service";
import { ReportingService } from "../../../services/components-services/reporting.service";

@Component({
  templateUrl: "./new-testimony.component.html",
  styleUrls: ["./new-testimony.component.css"],
  selector: "app-new-testimony"
})
export class NewTestimonyComponent implements OnInit {
  TestimonyClassification: TestimonyClassification[];
  loading = false;
  angularEditorConfig: AngularEditorConfig = {};
  testimonyForm: FormGroup;
  searchForm: FormGroup;
  testimonies: Testimony[] = [];
  cachedTestimonies: Testimony[] = [];
  filter: SimpleFilter;

  //Pagination
  public pagingCurrentPage: number = 1;
  public pagingItemsPerPage: number = 10;

  constructor(
    private fb: FormBuilder,
    private sweetAlertService: SweetAlertService,
    private testimonyService: TestimonyService,
    private utilitiesService: UtilitiesService,
    private reportingService: ReportingService
  ) {
    this.filter = new SimpleFilter();
    this.setAngularEditorConfig();
  }

  public ngOnInit() {
    this.createFormControls();
  }

  createFormControls() {
    this.testimonyForm = this.fb.group({
      testifier: ["", Validators.required],
      title: ["", Validators.required],
      details: ["", Validators.required],
      sharedAt: ["", Validators.required]
      // testimoniesClassificationsIds: [null]
    });

    this.reportingService.injectDatesIntoStatusReportsFilter(
      this.filter,
      ReportAnalysisPeriodType.ThisYear
    );

    this.searchForm = this.fb.group({
      endDate: [this.filter.endDate, Validators.required],
      startDate: [this.filter.startDate, Validators.required],
      statusFilter: [""]
    });
  }

  private setAngularEditorConfig() {
    this.angularEditorConfig = {
      editable: true,
      spellcheck: true,
      height: "25rem",
      minHeight: "5rem",
      placeholder: "Enter Testimony Details here...",
      translate: "no",
      //uploadUrl: 'v1/images', // if needed
      customClasses: [
        // optional
        {
          name: "quote",
          class: "quote"
        },
        {
          name: "redText",
          class: "redText"
        },
        {
          name: "titleText",
          class: "titleText",
          tag: "h1"
        }
      ]
    };
  }

  submitTestimony() {
    const body: Testimony = {
      sharedAt: this.testimonyForm.value.sharedAt,
      title: this.testimonyForm.value.title,
      details: this.testimonyForm.value.details,
      detailsBeforeProofReading: "",
      testifier: {
        fullName: this.testimonyForm.value.testifier
      },
      testimoniesClassificationsIds: this.testimonyForm.value
        .testimoniesClassificationsIds
    };
    //console.log(this.testimonyForm.value);
    this.loading = true;
    this.testimonyService
      .postTestimony(body)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((data: ResponseModel) => {
        this.sweetAlertService.showSuccess(data.message);
        //console.log(data);
        this.testimonyForm.reset();
      });
  }

  onSelectPreviousTab() {
    if (!this.testimonies.length) {
      this.getPreviousTestimonies();
    }
  }

  public getPreviousTestimonies() {
    this.filter.startDate = this.utilitiesService.createDateAsUTC(
      this.searchForm.value.startDate
    );
    this.filter.endDate = this.utilitiesService.createDateAsUTC(
      this.searchForm.value.endDate
    );

    this.testimonyService.getMyPreviousTestimonies(this.filter).subscribe(e => {
      //console.log(e);
      this.testimonies = e;
      this.cachedTestimonies = e;
    });
  }

  public trackByFn(index, item: Testimony) {
    if (!item) return null;
    return item.id;
  }

  public deleteTestimony(testimony: Testimony) {
    this.testimonyService.deleteTestimony(testimony.id).subscribe(e => {
      const index = this.testimonies.indexOf(testimony);
      if (index > -1) {
        this.testimonies.splice(index, 1);
        this.cachedTestimonies.splice(index, 1);
      }
    });
  }

  onChangeStatusFilter(status: ApprovalStatus) {
    if (status == ApprovalStatus.All) this.testimonies = this.cachedTestimonies;
    else {
      this.testimonies = filter(this.cachedTestimonies, item => {
        return item.approvalStatus == status;
      });
    }
  }
}
