export class Church {
  id: number;
  name: string;
  mission: string;
  vision: string;
  slogan: string;
  country: string;
  state: string;
  city: string;
  address: string;
  logo_path: string;
  logo: Blob; //blob
  contact_name: string;
  contact_address: string;
  contact_phone: string;
  contact_email: string;
  contact_2_name: string;
  contact_2_address: string;
  contact_2_phone: string;
  contact_2_email: string;
  created_at: Date;
  created_by: string;
  created_from: string;
}

export class ChurchCountry {
  name: string;
  description: string;
  created_at: Date;
  created_by: string;
}

export class ChurchState {
  country_id: number;
  country: string;
  name: string;
  description: string;
  created_at: Date;
  created_by: string;
}

export class ChurchCity {
  id: number;
  country_id: number;
  country: string;
  state_id: number;
  state: string;
  name: string;
  description: string;
  created_at: Date;
  created_by: string;
}

export class ChurchRoleBasedSystem {
  name: string;
  description: string;
  operational_division_id: number;
  operational_division: string;
  created_at: Date;
  created_by: string;
}

export class ChurchOperationalDivision {
  id: number;
  parent_division_id: number;
  parent_division: string;
  name: string = "";
  description: string = "";
  created_at: Date;
  created_by: string = "";
}

/*
export class ChurchSetupsRoutes {
  static cities = "church_setups/chuch_cities";
  static states = "church_setups/church_states";
  static countries = "church_setups/church_countries";
  static operational_systems = "church_setups/church_operational_systems";
  static structural_divisions = "church_setups/church_structural_divisions";
  static churches = "church_setups/churches";
}
*/
