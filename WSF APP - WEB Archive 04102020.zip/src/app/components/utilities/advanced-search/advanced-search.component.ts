import { Component, OnInit, EventEmitter, Output, Input } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import {
  PageFilterDescription,
  SimpleFilter,
  SimpleFilterHolderWithDescription,
  Lookup
} from "../../../models/utilities.models";
import { map } from "lodash";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { UtilitiesService } from "../../../services/utils/utilities.service";

@Component({
  selector: "app-advanced-search",
  templateUrl: "./advanced-search.component.html",
  styleUrls: ["./advanced-search.component.scss"]
})
export class AdvancedSearchComponent implements OnInit {
  public simpleSearchText: string = "";
  limitFormGroup: FormGroup;
  public bsModalRef: BsModalRef;
  filterHolder: SimpleFilterHolderWithDescription;

  @Output() onApplyFilter: EventEmitter<
    SimpleFilterHolderWithDescription
  > = new EventEmitter();
  @Input() searchTextPlaceholder: string = "Search Text";
  @Input() itemsCategories: Lookup[] = [];

  constructor(
    private fb: FormBuilder,
    private sweetAlertService: SweetAlertService,
    private modalService: BsModalService,
    private utilitiesService: UtilitiesService
  ) {
    if (!this.limitFormGroup) {
      this.createFilterFormGroup();
    }
  }

  ngOnInit() {
    if (!this.filterHolder) {
      this.filterHolder = new SimpleFilterHolderWithDescription();
    }

    if (!this.filterHolder.filter) {
      this.filterHolder.filter = new SimpleFilter();
    }

    if (!this.filterHolder.description) {
      this.filterHolder.description = new PageFilterDescription();
    }

    this.patchFilterFormGroup();
  }

  createFilterFormGroup() {
    this.limitFormGroup = this.fb.group({
      startDate: [null],
      endDate: [null],
      categories: [null],
      searchText: [""]
    });
  }

  patchFilterFormGroup() {
    this.limitFormGroup = this.fb.group({
      startDate: [this.filterHolder.filter.startDate],
      endDate: [this.filterHolder.filter.endDate],
      categories: [this.filterHolder.filter.categories],
      searchText: [this.filterHolder.filter.searchText]
    });
  }

  public applyFilter(isAdvancedSearch: boolean) {
    if (!isAdvancedSearch) {
      if (!this.simpleSearchText) {
        this.sweetAlertService.showMessage(
          "Invalid Search Text. Please check and try again."
        );
        return;
      }
      this.fillSearchDescription(isAdvancedSearch);
    } else {
      if (
        !this.limitFormGroup.value.searchText &&
        !this.limitFormGroup.value.startDate &&
        !this.limitFormGroup.value.endDate &&
        !this.limitFormGroup.value.categories
      ) {
        this.sweetAlertService.showMessage(
          "Invalid Search Criteria. Please check and try again."
        );
        return;
      }
    }
    this.fillSearchDescription(isAdvancedSearch);
    this.filterHolder.isAdvancedSearch = isAdvancedSearch;

    //const term = new SimpleFilter();
    if (isAdvancedSearch) {
      this.filterHolder.bsModalRef = this.bsModalRef;

      (this.filterHolder.filter.startDate = this.utilitiesService.createDateAsUTC(
        this.limitFormGroup.value.startDate
      )),
        (this.filterHolder.filter.endDate = this.utilitiesService.createDateAsUTC(
          this.limitFormGroup.value.endDate
        )),
        (this.filterHolder.filter.categories = map(
          this.limitFormGroup.value.categories,
          e => e.id
        )),
        (this.filterHolder.filter.searchText = this.limitFormGroup.value.searchText);
    } else {
      this.filterHolder.filter.searchText = this.simpleSearchText;
    }

    this.onApplyFilter.emit(this.filterHolder);
  }

  private fillSearchDescription(isAdvancedSearch: boolean) {
    if (isAdvancedSearch) {
      this.filterHolder.description.startDate = this.limitFormGroup.value.startDate;
      this.filterHolder.description.endDate = this.limitFormGroup.value.endDate;
      if (this.limitFormGroup.value.categories) {
        this.filterHolder.description.category = map(
          this.limitFormGroup.value.categories,
          e => e.name
        ).join(", ");
      }
      this.filterHolder.description.text = this.limitFormGroup.value.searchText;
    } else {
      this.filterHolder.description.startDate = null;
      this.filterHolder.description.endDate = null;
      this.filterHolder.description.category = null;
      this.filterHolder.description.text = this.simpleSearchText;
    }
  }

  private removeRunningFilter() {
    this.filterHolder.description.startDate = null;
    this.filterHolder.description.endDate = null;
    //this.filterHolder.description.hasFilterRunning = false;
    this.filterHolder.description.category = "None";
    this.limitFormGroup.patchValue({
      startDate: null,
      endDate: null,
      categories: null,
      searchText: ""
    });
  }

  public showDataLimitModal(template: any) {
    this.bsModalRef = this.modalService.show(template, {
      ignoreBackdropClick: true
      //class: "modal-lg"
    });
  }
}
