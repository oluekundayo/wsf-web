import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "../../services/guards/auth-guard.service";
import { LoadingBaysComponent } from "./loading-bays/loading-bays.component";
import { CreateLoadingBaysComponent } from "./create-loading-bays/create-loading-bays.component";

const routes: Routes = [
  {
    path: "view-loading-bays",
    component: LoadingBaysComponent,
    data: {
      title: "Church Transportation Loading Bays"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "create-loading-bays",
    component: CreateLoadingBaysComponent,
    data: {
      title: "Create Transportation Loading Bays"
    },
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TransportationSystemRoutingModule {}
