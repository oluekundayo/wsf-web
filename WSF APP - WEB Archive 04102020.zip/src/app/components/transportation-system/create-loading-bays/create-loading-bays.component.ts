import { Component, OnInit } from "@angular/core";
import {
  TransportationLoadingHub,
  HubDataFromExcel,
  LoadingPointDataFromExcel,
  TransportationLoadingPoint,
  TransportationLoadingPointDeparture
} from "../../../models/follow_up.models";
import { FollowUpService } from "../../../services/components-services/followup.service";
import { finalize } from "rxjs/operators";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { ResponseModel, Contact } from "../../../models/utilities.models";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { ApiRoutes } from "../../../services/api.routes";
import { APIService } from "../../../services/api.service";
import { ExcelService } from "../../../services/utils/excel.service";
import { Observable, SubscriptionLike as ISubscription } from "rxjs";
import { Center } from "../../../models/centers.models";
import * as moment from "moment";

@Component({
  selector: "app-create-loading-bays",
  templateUrl: "./create-loading-bays.component.html",
  styleUrls: ["./create-loading-bays.component.scss"]
})
export class CreateLoadingBaysComponent implements OnInit {
  public loadingHubs: TransportationLoadingHub[] = [];
  public loading: boolean = false;
  public bsModalRef: BsModalRef;
  public selectedLoadingHub: TransportationLoadingHub;
  pageTitle: string;
  excelServiceSubscriptions: ISubscription[] = [];
  hubToRegisterFromExcel: HubDataFromExcel;
  loadingPointsToRegisterFromExcel: LoadingPointDataFromExcel[];
  excelFileEvent$: any;
  massUploadedHub: TransportationLoadingHub = new TransportationLoadingHub();

  constructor(
    private followUpService: FollowUpService,
    private modalService: BsModalService,
    private sweetAlertService: SweetAlertService,
    private api: APIService,
    private excelService: ExcelService
  ) {}

  ngOnInit() {
    this.getLoadingHubs();
  }

  private getLoadingHubs() {
    this.followUpService
      .getLoadingHubsWithoutPoints()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.loadingHubs = response;
      });
  }

  private showModal(template: any) {
    this.bsModalRef = this.modalService.show(template, {
      ignoreBackdropClick: true,
      class: "modal-lg"
    });
  }

  public showLoadingPoints(hub: TransportationLoadingHub, template: any) {
    if (!hub.loadingPoints || !hub.loadingPoints.length) {
      this.followUpService
        .getLoadingPointsInAHub(hub.hubId)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          hub.loadingPoints = response;
          this.selectedLoadingHub = hub;
          this.showModal(template);
        });
    } else {
      this.selectedLoadingHub = hub;
      this.showModal(template);
    }
  }

  /* ... (within the component class definition) ... */
  public onFileChange(evt: any) {
    this.clearFileInput();

    /* wire up file reader */
    const target: DataTransfer = <DataTransfer>evt.target;

    if (target.files.length !== 1) {
      //throw new Error("Cannot use multiple files");
      alert("Cannot use multiple files");
      try {
        evt.srcElement.value = null;
        evt = null;
      } catch (e) {}

      return;
    }

    this.excelFileEvent$ = target;

    const sub = this.excelService.GetAllSheetNames(target).subscribe(names => {
      this.loadSelectedExcelSheet(names[0]);
      this.loadSelectedExcelSheet(names[1]);
    });

    this.excelServiceSubscriptions.push(sub);
  }

  private loadSelectedExcelSheet(
    sheetName: string,
    readyToClearMemomy: boolean = false
  ) {
    const sub = this.excelService
      .ReadExcelFile(this.excelFileEvent$, sheetName, true)
      .subscribe(data => {
        console.log(data);

        if (sheetName == "Loading Hub" && data.length) {
          const hub: HubDataFromExcel = data[0];
          this.massUploadedHub.hubAddress = hub.H_Address;
          this.massUploadedHub.hubName = hub.H_Name;
          this.massUploadedHub.loadingPointsCount = 0;
          this.massUploadedHub.hubCoordinator = {
            fullName: hub.C_Name,
            gender: hub.C_Gender,
            phone: hub.C_Phone,
            email: hub.C_Email,
            address: hub.C_Address
          } as Contact;
        } else if (sheetName == "Loading Points" && data.length) {
          const points: LoadingPointDataFromExcel[] = data;
          let pPoint: TransportationLoadingPoint;
          this.massUploadedHub.loadingPoints = [];
          points.forEach(point => {
            pPoint = new TransportationLoadingPoint();
            pPoint.loadingPointAddress = point.LP_Address;
            pPoint.loadingPointName = point.LP_Name;
            pPoint.loadingPointCoordinator = {
              fullName: point.C_Name,
              gender: point.C_Gender,
              phone: point.C_Phone,
              email: point.C_Email,
              address: point.C_Address
            } as Contact;
            pPoint.departures = [];
            let time: string;
            if (point.Takeoff_Time_1 && point.Service_to_Attend_1) {
              pPoint.departures.push({
                takeoff: point.Takeoff_Time_1,
                serviceName: point.Service_to_Attend_1,
                numberOfBusesLoaded: point.No_of_Buses_1
              } as TransportationLoadingPointDeparture);
            }
            if (point.Takeoff_Time_2 && point.Service_to_Attend_2) {
              pPoint.departures.push({
                takeoff: point.Takeoff_Time_2,
                serviceName: point.Service_to_Attend_2,
                numberOfBusesLoaded: point.No_of_Buses_2
              } as TransportationLoadingPointDeparture);
            }
            if (point.Takeoff_Time_3 && point.Service_to_Attend_3) {
              pPoint.departures.push({
                takeoff: point.Takeoff_Time_3,
                serviceName: point.Service_to_Attend_3,
                numberOfBusesLoaded: point.No_of_Buses_3
              } as TransportationLoadingPointDeparture);
            }
            if (point.Takeoff_Time_4 && point.Service_to_Attend_4) {
              pPoint.departures.push({
                takeoff: point.Takeoff_Time_4,
                serviceName: point.Service_to_Attend_4,
                numberOfBusesLoaded: point.No_of_Buses_4
              } as TransportationLoadingPointDeparture);
            }
            if (point.Takeoff_Time_5 && point.Service_to_Attend_5) {
              pPoint.departures.push({
                takeoff: point.Takeoff_Time_5,
                serviceName: point.Service_to_Attend_5,
                numberOfBusesLoaded: point.No_of_Buses_5
              } as TransportationLoadingPointDeparture);
            }
            if (point.Takeoff_Time_6 && point.Service_to_Attend_6) {
              pPoint.departures.push({
                takeoff: point.Takeoff_Time_6,
                serviceName: point.Service_to_Attend_6,
                numberOfBusesLoaded: point.No_of_Buses_6
              } as TransportationLoadingPointDeparture);
            }
            this.massUploadedHub.loadingPoints.push(pPoint);
          });
        }

        console.log(this.massUploadedHub);
      });

    this.excelServiceSubscriptions.push(sub);
  }

  private convertTime(time: number): string {
    //return `${time * 24} : ${(time % 24) * 60} AM`;

    //const quotient = Math.floor(time * 24);
    //const remainder = time % 24;

    //const quotient = (time - (time % 24)) / 24;
    //const remainder = (time % 24) / 24;

    /*const rawQuotient = time * 24;
    const remainder = rawQuotient % 1;
    const quotient = rawQuotient - remainder;

    return `${quotient}:${remainder * 60} AM`;*/

    var n = new Date(0, 0);
    //n.setSeconds(+time * 60 * 60);
    n.setHours(+time * 60);
    // var result = n.toTimeString().slice(0, 5);

    //var result = moment.duration(time).format("HH:mm");

    var result2 = moment
      .utc(moment.duration(time * 60).asHours())
      .format("HH:mm");

    var result3 = moment()
      .startOf("day")
      .add(time * 60, "hours")
      .format("HH:mm");

    //return result2 + " - " + result3;

    var hours = Math.floor(time / (60 * 60));
    time = time - hours * 60 * 60;
    var minutes = Math.floor(time / 60);
    time = time - minutes * 60;
    var seconds = Math.round(time);

    let _hours, _minutes, _seconds;

    if (hours < 10) {
      _hours = "0" + hours;
    }
    if (minutes < 10) {
      _minutes = "0" + minutes;
    }
    if (seconds < 10) {
      _seconds = "0" + seconds;
    }
    return "" + _hours + ":" + _minutes + ":" + _seconds;
  }

  private clearFileInput() {
    try {
      //console.log(this.massUploadedHub);
      this.excelFileEvent$.srcElement.value = null;
      this.excelFileEvent$ = null;
    } catch (e) {}
  }

  /*
  public removeCenterFromList(center: CenterDataFromExcel) {
    const index = this.centersData.indexOf(center, 0);
    if (index > -1) {
      this.centersData.splice(index, 1);
    }
    // this.centersData.splice(center);
  }*/

  /*public registerExistingCenters() {
    const validate = this.validateBeforeSubmission();
    if (!validate.isOk) {
      this.sweetAlertService.showError(validate.error, true);
      return;
    }

    const centers: Center[] = [];
    let newCenter: Center;
    let positionHolder: PositionHolder;

    this.centersData.forEach(_center => {
      newCenter = new Center();
      positionHolder = new PositionHolder();
      positionHolder.address = this.trimString(_center.MinisterAddress);
      positionHolder.firstname = this.trimString(_center.MinisterFirstname);
      positionHolder.lastname = this.trimString(_center.MinisterLastname);
      positionHolder.fullname =
        positionHolder.lastname + " " + positionHolder.firstname;
      positionHolder.email = this.trimString(_center.MinisterEmail);
      positionHolder.phone = this.trimString(_center.MinisterPhone);
      positionHolder.prefix = this.trimString(_center.MinisterPrefix);

      if (
        (_center.MinisterSex &&
          _center.MinisterSex.trim().toUpperCase() == "M") ||
        "MALE"
      ) {
        positionHolder.gender = "Male";
      } else if (
        (_center.MinisterSex &&
          _center.MinisterSex.trim().toUpperCase() == "F") ||
        "FEMALE"
      ) {
        positionHolder.gender = "Female";
      }

      positionHolder.maritalStatus = "";
      positionHolder.othername = this.trimString(_center.MinisterOthername);
      positionHolder.positionLevelId = this.selectedPositionLevelId;

      newCenter.address = this.trimString(_center.CenterAddress);
      newCenter.churchSystemsIds = null; //this.selectedChurchSystemsIds;
      newCenter.parentId = this.parentCenter.centerId;
      newCenter.centerTypeId = this.selectedCenterType.id;
      newCenter.number = _center.CenterNumber;
      newCenter.activeStatus = this.selectedActiveStatus;
      newCenter.addCenterUser = true;


      newCenter.shortNameFromAddress = this.trimString(
        _center.CenterShortNameFromAddress
      );
      newCenter.useSystemCenterNumbering = false;
      newCenter.positionHolder = positionHolder;

      if (_center.Center_type) {
        newCenter.churchSystemsTags = _center.Center_type.split(",");
      } else {
        newCenter.churchSystemsTags = [];
      }

      //console.log(_center.Center_type);

      centers.push(newCenter);
    });

    this.sweetAlertService
      .showConfirm("These Centers will be Registered")
      .then(response => {
        if (response.value) {
          this.loading = true;
          this.api
            .post<ResponseModel>(
              ApiRoutes.centers.register_existing_centers,
              centers
            )
            .pipe(finalize(() => (this.loading = false)))
            .subscribe(response => {
              //this.resetPage();
              this.sweetAlertService.showSuccess(response.message);
            });

          //console.log(response.value);
        }
      });
  }*/

  private trimString(_string: string): string {
    if (_string && typeof _string === "string") {
      return _string.trim();
    } else return "";
  }

  public clearScreen() {
    this.excelFileEvent$ = null;
  }

  private validateBeforeSubmission(): ResponseModel {
    let error = new ResponseModel();
    error.isOk = true;
    error.error = "";

    /*if (!this.selectedCenterType || !this.selectedCenterType.id) {
      error.isOk = false;
      error.error += "Please select Center Type.<br/>";
    }
    if (!this.parentCenter || !this.parentCenter.centerId) {
      error.isOk = false;
      error.error += "Please select Parent Center.<br/>";
    }
    if (!this.selectedPositionLevelId) {
      error.isOk = false;
      error.error += "Please select User Role.<br/>";
    }
    if (!this.selectedActiveStatus) {
      error.isOk = false;
      error.error += "Please select Centers' Active Status.<br/>";
    }


    const _findEmptyAddresses = filter(
      this.centersData,
      (center: CenterDataFromExcel) => {
        return !center.CenterAddress;
      }
    );

    if (_findEmptyAddresses && _findEmptyAddresses.length > 0) {
      error.isOk = false;
      error.error += "Center Address is required for each record.<br/>";
    }*/

    return error;
  }

  ngOnDestroy(): void {
    try {
      this.excelServiceSubscriptions.forEach(sub => {
        sub.unsubscribe();
      });
    } catch (e) {}

    try {
      this.bsModalRef.content.action.unsubscribe();
    } catch (e) {}

    this.clearFileInput();
  }
}
