import { ReportAnalysisBaseModel } from "./reports.analysis.models";
import { ObjectProperty } from "./reporting.models";
import {
  Lookup,
  Contact,
  ApprovalStatus,
  ActiveStatus
} from "./utilities.models";

export class FollowUpSummaryDataItem extends ReportAnalysisBaseModel {
  allSoulsRegistered: number;
  newConverts: number;
  firstTimers: number;
  males: number;
  females: number;
  adults: number;
  children: number;
  holyGhostBaptism: number;
}

export class FollowUpDataSummary {
  summary: FollowUpSummaryDataItem[];
  expectedPeriodKeys: ObjectProperty[];
  assignedMeetings: Lookup[] = [];
}

export class FollowUpDataSummaryPerCenter {
  centerId: number;
  centerAddress: string;
  centerChartLabel: string;
  centerName: string;
  contactFullName: string;
  contactPhone: string;
  reports: FollowUpSummaryDataItem[];
}

export class ApprovedSmsSenderIds {
  senderIds: string[];
}

export class SmsMessaging {
  id: number;
  recieverPositionId?: number;
  recipients?: string[];
  senderId: string;
  text: string;
  subject: string;
  ScheduledDate?: Date;
  ScheduledTime?: string;
  saveDraft?: boolean = false;
  sendThroughSms?: boolean = false;
  sendThroughEmail?: boolean = false;
}

export class SmsMessagingDraft {
  id: number;
  from?: string;
  text: string;
  subject: string;
  createdAt?: Date;
}

export class TransportationCentralLocation {
  id: number;
  locationName: string;
  locationDescription?: string;
  locationNumber?: number;
  locationAddress?: string;
  loadingBaysCount?: number;
  loadingPointsCount?: number;
  loadingHubs: TransportationLoadingHub[] = [];
}

export class TransportationLoadingPointDeparture {
  hostCenterId: number;
  transportationLoadingPointId: number;
  serviceName?: string;
  description?: string;
  dayOfWeek?: number;
  hubDescription?: string;
  takeoff?: string;
  busCapacity?: number;
  busType?: string;
  numberOfBusesLoaded?: number;
  coordinatorName?: string;
  coordinatorPhone?: string;
  coordinatorEmail?: string;
  approvalStatus?: ApprovalStatus;
  activeStatus?: ActiveStatus;
}

export class TransportationLoadingPoint {
  hostCenterId: number;
  hostCenterName: string;
  hostCenterAddress: string;
  hostCenterShortNameFromAddress: string;
  loadingPointId: number;
  loadingPointName: string;
  loadingPointDescription?: string;
  loadingPointAddress?: string;
  loadingPointCoordinator?: Contact;
  departures: TransportationLoadingPointDeparture[];
}

export class TransportationLoadingHub {
  hostCenterId: number;
  hostCenterName: string;
  hostCenterAddress: string;
  hostCenterShortNameFromAddress: string;
  hubId: number;
  hubAddress?: string;
  hubCoordinator?: Contact;
  hubName?: string;
  hubDescription?: string;
  loadingPointsCount?: number;
  loadingPoints?: TransportationLoadingPoint[];
}

export class HubDataFromExcel {
  H_Name: string;
  H_Address: string;
  C_Name: string;
  C_Address?: string;
  C_Email?: string;
  C_Phone?: string;
  C_Gender?: string;
}

export class LoadingPointDataFromExcel {
  LP_Name: string;
  LP_Address: string;
  C_Name: string;
  C_Address?: string;
  C_Email?: string;
  C_Phone?: string;
  C_Gender?: string;

  Takeoff_Time_1: string;
  Service_to_Attend_1: string;
  No_of_Buses_1: number;
  /*Agent_Name_1: string;
  Agent_Email_1?: string;
  Agent_Phone_1?: string;*/

  Takeoff_Time_2: string;
  Service_to_Attend_2: string;
  No_of_Buses_2: number;
  /*Agent_Name_2: string;
  Agent_Email_2?: string;
  Agent_Phone_2?: string;*/

  Takeoff_Time_3: string;
  Service_to_Attend_3: string;
  No_of_Buses_3: number;
  /*Agent_Name_3: string;
  Agent_Email_3?: string;
  Agent_Phone_3?: string;*/

  Takeoff_Time_4: string;
  Service_to_Attend_4: string;
  No_of_Buses_4: number;
  /*Agent_Name_4: string;
  Agent_Email_4?: string;
  Agent_Phone_4?: string;*/

  Takeoff_Time_5: string;
  Service_to_Attend_5: string;
  No_of_Buses_5: number;
  /*Agent_Name_5: string;
  Agent_Email_5?: string;
  Agent_Phone_5?: string;*/

  Takeoff_Time_6: string;
  Service_to_Attend_6: string;
  No_of_Buses_6: number;
  /*Agent_Name_6: string;
  Agent_Email_6?: string;
  Agent_Phone_6?: string;*/
}
