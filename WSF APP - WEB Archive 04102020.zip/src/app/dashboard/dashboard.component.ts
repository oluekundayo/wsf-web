import { Component, OnInit, AfterViewInit } from "@angular/core";
import { Subscription } from "rxjs";
import { Router, NavigationStart } from "@angular/router";
import { LoginService } from "../services/components-services/login.service";
import { DashboardItem } from "../models/menu.models";
import { DashboardItemType } from "../models/utilities.models";

//declare var $: any;

@Component({
  selector: "dashboard-cmp",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.scss"]
})
export class DashboardComponent implements AfterViewInit {
  //public loading: boolean = true;
  public dashboardItems: {
    testimoniesInfo: DashboardItem;
    publicationsInfo: DashboardItem;
    followUpContactsInfo: DashboardItem;
    pendingTestimonies: DashboardItem;
    pendingPublications: DashboardItem;
  } = {
    testimoniesInfo: new DashboardItem(),
    publicationsInfo: new DashboardItem(),
    followUpContactsInfo: new DashboardItem(),
    pendingTestimonies: new DashboardItem(),
    pendingPublications: new DashboardItem()
  };

  public constructor(
    private loginService: LoginService,
    private router: Router
  ) {}

  ngOnInit() {}

  ngAfterViewInit(): void {
    this.loginService.getDashboardItems().subscribe(response => {
      // this.dashboardItems = response;
      // console.log(response);
      if (response) {
        response.forEach(element => {
          switch (element.itemType) {
            case DashboardItemType.TestimoniesInfo:
              this.dashboardItems.testimoniesInfo = element;
              break;
            case DashboardItemType.PublicationsInfo:
              this.dashboardItems.publicationsInfo = element;
              break;
            case DashboardItemType.FollowUpContactsInfo:
              this.dashboardItems.followUpContactsInfo = element;
              break;
            case DashboardItemType.PendingPublications:
              this.dashboardItems.pendingPublications = element;
              break;
            case DashboardItemType.PendingTestimonies:
              this.dashboardItems.pendingTestimonies = element;
              break;
          }
        });
      }
    });
  }

  public navigateToDetails(type: string) {
    switch (type) {
      case DashboardItemType.TestimoniesInfo:
        this.router.navigate(["app/testimonies/testimonies"]);
        break;
      case DashboardItemType.PublicationsInfo:
        this.router.navigate(["app/publications/publications"]);
        break;
      case DashboardItemType.FollowUpContactsInfo:
        this.router.navigate(["app/follow-up/contact-new-converts"]);
        break;
      case DashboardItemType.PendingPublications:
        this.router.navigate(["app/publications/publications-report"]);
        break;
      case DashboardItemType.PendingTestimonies:
        this.router.navigate(["app/testimonies/testimonies-report"]);
        break;
    }
  }
}
