import { Injectable } from "@angular/core";
import * as jwt_decode from "jwt-decode";
import { isEmpty } from "rxjs/operators";
import { BehaviorSubject } from "rxjs";
import { MenuService } from "./components-services/menu.service";

//https://medium.com/@amcdnl/authentication-in-angular-jwt-c1067495c5e0
//https://medium.com/@ryanchenkie_40935/angular-authentication-using-the-http-client-and-http-interceptors-2f9d1540eb8

export const TOKEN_KEY: string = "token";
export const RESOURCE_ID_KEY: string = "RD";

@Injectable()
export class AuthService {
  private tokenSubject = new BehaviorSubject<string>("");

  constructor(private menuService: MenuService) {}

  public cacheUsername(username: string) {
    // store username and jwt token in local storage to keep user logged in between page refreshes
    //sessionStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem("reloader", username);
  }

  /**
   * name
   */
  public getUsername(): string {
    //return sessionStorage.getItem(TOKEN_KEY);
    const user = localStorage.getItem("reloader");
    return user ? user : "";
  }

  /**
   * login
   */
  public setToken(token: string) {
    // store username and jwt token in local storage to keep user logged in between page refreshes
    //sessionStorage.setItem(TOKEN_KEY, token);
    //localStorage.setItem(TOKEN_KEY, token);

    this.tokenSubject.next(token);
  }

  /**
   * name
   */
  public getToken(): string {
    //return sessionStorage.getItem(TOKEN_KEY);
    //return localStorage.getItem(TOKEN_KEY);

    return this.tokenSubject.value;
  }

  /**
   * name
   */
  public isLoggedIn(): boolean {
    //https://medium.com/@luukgruijs/understanding-rxjs-behaviorsubject-replaysubject-and-asyncsubject-8cc061f1cfc0
    //https://medium.com/@saivicky2015/why-jwt-shouldnt-be-stored-in-local-storage-aa9aeacc46a0

    const emptytoken = this.getToken();
    //console.log(emptytoken);

    //const token = sessionStorage.getItem(TOKEN_KEY);
    //return token  ? true : false;

    return emptytoken ? true : false;
  }

  public isTokenExpired(token?: string): boolean {
    // temp value
    //return false;

    //console.log(this.getToken());

    if (!token) token = this.getToken();
    if (!token) return true;

    /*
    // this logic is not working on all systems. due to time format on systems
    const date = this.getTokenExpirationDate(token);
    if (date === undefined) return false;
    return date === null || !(date.valueOf() > new Date().valueOf()); */
  }

  public getTokenExpirationDate(token: string): Date {
    try {
      const decoded = jwt_decode(token);
      if (decoded.exp === undefined) return null;

      const date = new Date(0);
      date.setUTCSeconds(decoded.exp);
      return date;
    } catch (e) {
      return null;
    }
  }

  /**
   * logout
   */
  public logout(): void {
    // clear token remove user from local storage to log user out
    //sessionStorage.removeItem(TOKEN_KEY);
    this.setToken("");
  }

  /**
   * login
   */
  public setResourceId(id: number) {
    // store username and jwt token in local storage to keep user logged in between page refreshes
    //sessionStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(RESOURCE_ID_KEY, id + "");
  }

  /**
   * name
   */
  public getResourceId(): number {
    //return sessionStorage.getItem(TOKEN_KEY);
    try {
      return parseInt(localStorage.getItem(RESOURCE_ID_KEY));
    } catch (e) {
      return 0;
    }
  }
}
