import { Component, OnInit, TemplateRef } from "@angular/core";
import { FollowUpService } from "../../../services/components-services/followup.service";
import { Observable, from, Subject, of, concat } from "rxjs";
import { CenterMemberGetModel } from "../../../models/centers.models";
import { Validators, FormGroup, FormBuilder } from "@angular/forms";
// import { DateRangeFilter } from "../../../models/utilities.models";
//import { DatePipe } from "@angular/common";
import { UtilitiesService } from "../../../services/utils/utilities.service";
import { ComposeSmsDialogComponent } from "../../dialog/compose-sms-dialog/compose-sms-dialog.component";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import {
  ReportFilter,
  MeetingDashboardItem
} from "../../../models/reporting.models";
import {
  ReportAnalysisPeriodType,
  SimpleFilter,
  CenterMemberConversionStatus,
  Lookup,
  SmsRecipientOptions,
  KeyValueModel,
  DataCacheMode,
  FollowUpPageMode
} from "../../../models/utilities.models";
import {
  FollowUpDataSummary,
  FollowUpSummaryDataItem,
  FollowUpDataSummaryPerCenter
} from "../../../models/follow_up.models";
import { ReportingService } from "../../../services/components-services/reporting.service";
import { CreateFollowupCenterMemberDialogComponent } from "../../dialog/create-followup-center-member-dialog/create-followup-center-member-dialog.component";
import {
  finalize,
  //map,
  //filter,
  debounceTime,
  distinctUntilChanged,
  tap,
  switchMap,
  catchError
} from "rxjs/operators";
import { ApiRoutes } from "../../../services/api.routes";
import { sumBy, find, map, chain, filter } from "lodash";
import { ChartOptions } from "chart.js";
import { query } from "@angular/animations";

export enum FollowUpDataPendingState {
  PeriodTypeChange,
  MeetingTypeChange,
  None
}

@Component({
  selector: "app-view-new-converts",
  templateUrl: "./view-new-converts.component.html",
  styleUrls: ["./view-new-converts.component.scss"]
})
export class ViewNewConvertsComponent implements OnInit {
  loading: boolean = false;
  isSelectedAll: boolean = false;
  centerMembers: CenterMemberGetModel[] = [];
  cachedCenterMembers: CenterMemberGetModel[] = [];

  formGroupFilter: FormGroup;
  bsModalRef: BsModalRef;
  dataSummary: FollowUpDataSummary;
  //statusFilter: StatusReportsFilter = new StatusReportsFilter();
  messageRecipientOptions: KeyValueModel[] = [];
  filter: ReportFilter;
  assignedMeetings: Lookup[] = [];
  summaryDataItemsCount: FollowUpSummaryDataItem;
  summaryDataPerCenter: FollowUpDataSummaryPerCenter[] = [];

  public selectedCentersMemberFilter: string = SmsRecipientOptions.All;
  public filteredItemsCount: number = 0;
  private checkedRecipientsCount: number = 0;
  private cachedSelectedCentersMemberFilterBeforeAutoSelect;

  //Pagination
  public pagingCurrentPage: number = 1;
  public pagingItemsPerPage: number = 10;
  //Chart

  public chartColors: Array<any> = [];
  public meetingsChartOptions: ChartOptions;
  public trendsChartOptions: ChartOptions;
  public trendsChartLabels: string[] = [];
  public meetingsChartLabels: string[] = [];
  public trendsChartData: any[] = [];
  public meetingsChartData: any[] = [];

  public centersChartOptions: any;
  public centersChartLabels: string[] = [];
  public centersChartData: any[] = [];

  public selectedSearchItems: CenterMemberGetModel[] = [];
  searchResults$: Observable<CenterMemberGetModel[]>;
  searchQuery$ = new Subject<string>();
  isSearchLoading: boolean = false;
  selectedMeeting: MeetingDashboardItem;

  //isContactListRefreshed: boolean = true;
  //isSummaryDataRefreshed: boolean = true;
  //isCentersDataRefreshed: boolean = true;

  //public isTrendsChartReady: boolean = false;
  //public isCentersChartReady: boolean = false;

  /*isContactListRefreshed: boolean = true;
  isSummaryDataRefreshed: boolean = true;
  isCentersDataRefreshed: boolean = true;*/

  pageMode: FollowUpPageMode;
  dataPendingStateForSummaryData: FollowUpDataPendingState;
  dataPendingStateForContactsList: FollowUpDataPendingState;
  dataPendingStateForCentersData: FollowUpDataPendingState;

  constructor(
    private followUpService: FollowUpService,
    private fb: FormBuilder,
    public reportingService: ReportingService,
    private modalService: BsModalService
  ) {
    this.createForm();
  }

  ngOnInit() {
    this.filter = new ReportFilter();
    this.filter.periodType = ReportAnalysisPeriodType.ThisMonth;
    this.pageMode = FollowUpPageMode.SummaryVisuals;

    this.dataPendingStateForCentersData =
      FollowUpDataPendingState.PeriodTypeChange;
    this.dataPendingStateForContactsList =
      FollowUpDataPendingState.PeriodTypeChange;
    this.dataPendingStateForSummaryData =
      FollowUpDataPendingState.PeriodTypeChange;

    this.summaryDataItemsCount = new FollowUpSummaryDataItem();
    this.selectedMeeting = {
      id: 0,
      name: "All Meetings",
      selected: true
    } as MeetingDashboardItem;

    this.initCharts();
    this.initSearch();
    this.prepareMessageRecipientOptions();
    this.reportingService.reconfigureFilter(this.filter);
    this.onSelectDataSummaryVisualsTab();
    //this.getAssignedMeetings();
  }

  private getSummaryData() {
    this.filter.loadAssignedMeetingsAsReference =
      this.assignedMeetings.length < 1;
    this.loading = true;
    this.followUpService
      .getFollowUpDataSummary(this.filter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        if (this.filter.loadAssignedMeetingsAsReference) {
          this.assignedMeetings = response.assignedMeetings;
          response.assignedMeetings = []; //empty the array for memory
        }
        this.dataSummary = response;
        this.computePageData();
      });
  }

  private prepareMessageRecipientOptions() {
    /*Object.keys(SmsRecipientOptions).forEach(key => {
      console.log(SmsRecipientOptions[key]);
      });*/

    this.messageRecipientOptions = Object.keys(SmsRecipientOptions).map(
      function(type) {
        return { value: SmsRecipientOptions[type], key: type } as KeyValueModel;
      }
    );
    this.selectedCentersMemberFilter = SmsRecipientOptions.All;
  }

  createForm() {
    this.formGroupFilter = this.fb.group({
      startDate: [null, Validators.required],
      endDate: [null, Validators.required]
    });
  }

  public openModalToComposeSms() {
    let recipients: string[];

    if (this.selectedCentersMemberFilter == SmsRecipientOptions.Selected) {
      recipients = chain(this.centerMembers)
        .filter((e: CenterMemberGetModel) => e.isSelected)
        .map(e => e.phone)
        .value();
    } else {
      recipients = map(this.centerMembers, e => e.phone);
    }

    //console.log(recipients);

    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      animated: true,
      initialState: { recipientsInput: recipients }
    };

    this.bsModalRef = this.modalService.show(ComposeSmsDialogComponent, config);
    /*this.bsModalRef.content.action.subscribe(value => {
      // console.log(value); // here you will get the value
      if (value) {

      }
    });*/
  }

  public openModalToCreateNewMember() {
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      animated: true,
      initialState: {}
    };

    this.bsModalRef = this.modalService.show(
      CreateFollowupCenterMemberDialogComponent,
      config
    );
    this.bsModalRef.content.action.subscribe(value => {
      // console.log(value); // here you will get the value
      if (value) {
        this.appendNewContactToPageData(value);
      }
    });
  }

  private initCharts() {
    try {
      this.trendsChartData = [
        { data: [], label: "New Births" },
        { data: [], label: "First Timers" },
        { data: [], label: "Holy Ghost Baptism" }
      ];

      this.meetingsChartData = [
        { data: [], label: "New Births" },
        { data: [], label: "First Timers" },
        { data: [], label: "Holy Ghost Baptism" }
      ];

      this.centersChartData = [
        { data: [], label: "New Births" },
        { data: [], label: "First Timers" },
        { data: [], label: "Holy Ghost Baptism" }
      ];

      this.trendsChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        //scaleShowVerticalLines: false,
        //fill: false,
        // We use these empty structures as placeholders for dynamic theming.
        // scales: { xAxes: [{}], yAxes: [{}] },
        title: {
          display: true,
          text: "Data Trends in Time"
        }
        /* plugins: {
          datalabels: {
            anchor: "end",
            align: "end"
          }
        }*/
      };

      this.meetingsChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        //rotation: 1 * Math.PI,
        //circumference: 1 * Math.PI,
        scales: { scaleLabel: { fontSize: 13 } },
        title: {
          display: true,
          text: "Registered Contacts Per Meetings"
        }
      };

      this.centersChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        title: {
          display: true,
          text: "Centers Follow-Up Data Analysis"
        },
        scales: {
          yAxes: [
            {
              barPercentage: 0.5
            }
          ]
        },
        elements: {
          rectangle: {
            borderSkipped: "left"
          }
        }
      };

      //this.isTrendsChartReady = false;
    } catch (e) {}
  }

  private resetSummaryChartsData() {
    this.trendsChartData.forEach(element => {
      element.data.length = 0;
    });

    this.meetingsChartData.forEach(element => {
      element.data.length = 0;
    });
  }

  private resetCentersChartData() {
    this.centersChartData.forEach(element => {
      element.data.length = 0;
    });
  }

  private computeSummaryDataItemsCount() {
    let data: FollowUpSummaryDataItem[];
    if (this.selectedMeeting.id == 0) {
      data = this.dataSummary.summary;
    } else {
      data = filter(this.dataSummary.summary, (e: FollowUpSummaryDataItem) => {
        return e.meetingId == this.selectedMeeting.id;
      });
    }
    if (!data) {
      data = [];
    }

    this.summaryDataItemsCount.allSoulsRegistered = sumBy(
      data,
      item => item.allSoulsRegistered
    );

    this.summaryDataItemsCount.males = sumBy(data, item => item.males);

    this.summaryDataItemsCount.females = sumBy(data, item => item.females);

    this.summaryDataItemsCount.adults = sumBy(data, item => item.adults);

    this.summaryDataItemsCount.children = sumBy(data, item => item.children);

    this.summaryDataItemsCount.newConverts = sumBy(
      data,
      item => item.newConverts
    );

    this.summaryDataItemsCount.firstTimers = sumBy(
      data,
      item => item.firstTimers
    );

    this.summaryDataItemsCount.holyGhostBaptism = sumBy(
      data,
      item => item.holyGhostBaptism
    );
  }

  private prepareCharts() {
    try {
      this.resetSummaryChartsData();
      let data: FollowUpSummaryDataItem[];

      if (!this.dataSummary.summary) {
        data = [];
      } else {
        if (this.selectedMeeting.id == 0) {
          data = this.dataSummary.summary;
        } else {
          data = filter(
            this.dataSummary.summary,
            (e: FollowUpSummaryDataItem) => {
              return e.meetingId == this.selectedMeeting.id;
            }
          );
        }
      }

      if (!data) {
        data = [];
      }

      this.assignedMeetings.forEach(key => {
        const groupedData = filter(data, function(
          item: FollowUpSummaryDataItem
        ) {
          return item.meetingId == key.id;
        });

        //console.log(this.assignedMeetings);
        //console.log(groupedData);
        //console.log(this.meetingsChartData);

        this.meetingsChartData[0].data.push(
          sumBy(groupedData, item => item.newConverts)
        );

        this.meetingsChartData[1].data.push(
          sumBy(groupedData, item => item.firstTimers)
        );

        this.meetingsChartData[2].data.push(
          sumBy(groupedData, item => item.holyGhostBaptism)
        );

        //this.meetingsChartLabels.push(key.name);

        setTimeout(() => {
          this.meetingsChartLabels = this.assignedMeetings.map(val => val.name);
        });
      });

      this.dataSummary.expectedPeriodKeys.forEach(key => {
        const groupedData = filter(data, function(
          item: FollowUpSummaryDataItem
        ) {
          return (
            item[key.key] == key.value && item[key.parentKey] == key.parentValue
          );
        });

        this.trendsChartData[0].data.push(
          sumBy(groupedData, item => item.newConverts) || 0
        );

        this.trendsChartData[1].data.push(
          sumBy(groupedData, item => item.firstTimers) || 0
        );

        this.trendsChartData[2].data.push(
          sumBy(groupedData, item => item.holyGhostBaptism) || 0
        );

        //this.trendsChartLabels.push();
      });

      setTimeout(() => {
        this.trendsChartLabels = this.dataSummary.expectedPeriodKeys.map(val =>
          this.reportingService.getChartKey(val)
        );
      });

      //this.isTrendsChartReady = true;
    } catch (e) {
      //console.log(e);
    }
  }

  private prepareCentersCharts() {
    try {
      this.resetCentersChartData();

      this.summaryDataPerCenter.forEach(center => {
        let data: FollowUpSummaryDataItem[];
        if (this.selectedMeeting.id == 0) {
          data = center.reports;
        } else {
          data = filter(center.reports, (e: FollowUpSummaryDataItem) => {
            return e.meetingId == this.selectedMeeting.id;
          });
        }

        if (!data) {
          data = [];
        }

        // console.log(data);

        if (data && data.length) {
          this.centersChartData[0].data.push(
            sumBy(data, item => item.newConverts)
          );
          this.centersChartData[1].data.push(
            sumBy(data, item => item.firstTimers)
          );
          this.centersChartData[2].data.push(
            sumBy(data, item => item.holyGhostBaptism)
          );
        }

        // this.centersChartLabels.push(center.centerChartLabel);
      });

      setTimeout(() => {
        this.centersChartLabels = this.summaryDataPerCenter.map(
          val => val.centerChartLabel
        );
      });
    } catch (e) {
      //console.log(e);
    }
  }

  public onSelectSearchContact(member: CenterMemberGetModel) {
    if (member) {
      //console.log(member);
      this.onCheckRecipient(member, true);
      //this.selectedCentersMemberFilter = SmsRecipientOptions.Selected;
      //this.centerMembers = members;
      this.onChangeCentersMemberFilter();
    } else {
    }
  }

  private initSearch() {
    this.searchResults$ = concat(
      of([] as CenterMemberGetModel[]), // default items
      this.searchQuery$.pipe(
        debounceTime(200),
        distinctUntilChanged(),
        tap(() => (this.isSearchLoading = true)),
        switchMap(term =>
          this.followUpService
            .searchCenterMemebers(term, this.cachedCenterMembers)
            .pipe(
              catchError(() => of([] as CenterMemberGetModel[])), // empty list on error
              tap(() => (this.isSearchLoading = false))
            )
        )
      )
    );
  }

  public onSelectContactsListTab() {
    this.pageMode = FollowUpPageMode.ContactsList;
    if (
      this.dataPendingStateForContactsList ==
      FollowUpDataPendingState.PeriodTypeChange
    ) {
      this.loading = true;
      this.followUpService
        .getNewConverts(this.filter)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          //console.log(response);
          this.centerMembers = response;
          this.cachedCenterMembers = response;
          this.filteredItemsCount = response.length;
          this.computePageData();
        });
    } else if (
      this.dataPendingStateForContactsList ==
      FollowUpDataPendingState.MeetingTypeChange
    ) {
      this.computePageData();
    }

    this.dataPendingStateForContactsList = FollowUpDataPendingState.None;
  }

  public onSelectCentersVisualsTab() {
    this.pageMode = FollowUpPageMode.CentersVisual;
    if (
      this.dataPendingStateForCentersData ==
      FollowUpDataPendingState.PeriodTypeChange
    ) {
      this.loading = true;
      this.followUpService
        .getFollowUpDataSummaryPerCenter(this.filter)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          //console.log(response);
          this.summaryDataPerCenter = response;
          this.computePageData();
        });
    } else if (
      this.dataPendingStateForCentersData ==
      FollowUpDataPendingState.MeetingTypeChange
    ) {
      this.computePageData();
    }

    this.dataPendingStateForCentersData = FollowUpDataPendingState.None;
  }

  public onSelectDataSummaryVisualsTab() {
    this.pageMode = FollowUpPageMode.SummaryVisuals;
    if (
      this.dataPendingStateForSummaryData ==
      FollowUpDataPendingState.PeriodTypeChange
    ) {
      this.getSummaryData();
    } else if (
      this.dataPendingStateForSummaryData ==
      FollowUpDataPendingState.MeetingTypeChange
    ) {
      this.computePageData();
    }
    this.dataPendingStateForSummaryData = FollowUpDataPendingState.None;
  }

  private appendNewContactToPageData(newMembers: CenterMemberGetModel[]) {
    if (newMembers && newMembers.length) {
      this.onSelectPeriodType(null);
    }
  }

  onChangeCentersMemberFilter() {
    this.computePageData();
  }

  getCurrentCenterMembers(): CenterMemberGetModel[] {
    let data: CenterMemberGetModel[];
    if (this.selectedMeeting.id == 0) {
      data = this.cachedCenterMembers;
    } else {
      data = filter(this.cachedCenterMembers, (e: CenterMemberGetModel) => {
        return e.meetingId == this.selectedMeeting.id;
      });
    }
    if (!data) {
      data = [];
    }
    return data;
  }

  onCheckRecipient(member: CenterMemberGetModel, checked: boolean) {
    member.isSelected = checked;

    find(
      this.cachedCenterMembers,
      _member => _member.id == member.id
    ).isSelected = checked;

    if (
      checked &&
      this.selectedCentersMemberFilter != SmsRecipientOptions.Selected
    ) {
      this.cachedSelectedCentersMemberFilterBeforeAutoSelect = this.selectedCentersMemberFilter;
      this.selectedCentersMemberFilter = SmsRecipientOptions.Selected;
    }

    this.checkedRecipientsCount = checked
      ? this.checkedRecipientsCount + 1
      : this.checkedRecipientsCount - 1;

    if (this.checkedRecipientsCount == 0) {
      this.selectedCentersMemberFilter = this.cachedSelectedCentersMemberFilterBeforeAutoSelect;
      this.filteredItemsCount = this.centerMembers.length;
      this.onChangeCentersMemberFilter();
    } else {
      this.filteredItemsCount = this.checkedRecipientsCount;
    }
  }

  public trackByFn(index, item: CenterMemberGetModel) {
    if (!item) return null;
    return item.id;
  }

  public onSelectPeriodType(selectedFilter: ReportFilter) {
    if (filter) {
      this.filter = selectedFilter;
      this.reportingService.reconfigureFilter(this.filter);
    }

    this.dataPendingStateForCentersData =
      FollowUpDataPendingState.PeriodTypeChange;
    this.dataPendingStateForContactsList =
      FollowUpDataPendingState.PeriodTypeChange;
    this.dataPendingStateForSummaryData =
      FollowUpDataPendingState.PeriodTypeChange;

    if (this.pageMode == FollowUpPageMode.SummaryVisuals) {
      this.onSelectDataSummaryVisualsTab();
    } else if (this.pageMode == FollowUpPageMode.CentersVisual) {
      this.onSelectCentersVisualsTab();
    } else if (this.pageMode == FollowUpPageMode.ContactsList) {
      this.onSelectContactsListTab();
    }
  }

  public onChangeMeetingType(selectedMeeting: MeetingDashboardItem) {
    this.selectedMeeting = selectedMeeting;

    this.dataPendingStateForCentersData =
      FollowUpDataPendingState.MeetingTypeChange;
    this.dataPendingStateForContactsList =
      FollowUpDataPendingState.MeetingTypeChange;
    this.dataPendingStateForSummaryData =
      FollowUpDataPendingState.MeetingTypeChange;

    //this.computePageData();

    if (this.pageMode == FollowUpPageMode.SummaryVisuals) {
      this.onSelectDataSummaryVisualsTab();
    } else if (this.pageMode == FollowUpPageMode.CentersVisual) {
      this.onSelectCentersVisualsTab();
    } else if (this.pageMode == FollowUpPageMode.ContactsList) {
      this.onSelectContactsListTab();
    }
  }

  private computePageData() {
    if (this.pageMode == FollowUpPageMode.SummaryVisuals) {
      this.computeSummaryDataItemsCount();
      this.prepareCharts();
    } else if (this.pageMode == FollowUpPageMode.CentersVisual) {
      this.prepareCentersCharts();
    } else if (this.pageMode == FollowUpPageMode.ContactsList) {
      this.followUpService
        .filterCenterMembers(
          this.selectedCentersMemberFilter,
          this.getCurrentCenterMembers()
        )
        .subscribe((items: CenterMemberGetModel[]) => {
          this.centerMembers = items;
          this.filteredItemsCount = items.length;
        });
    }
  }
}
