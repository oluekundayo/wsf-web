import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "../../services/guards/auth-guard.service";
import { NewTestimonyComponent } from "./new-testimony/new-testimony.component";
import { TestimoniesComponent } from "./testimonies/testimonies.component";
import { TestimoniesReportComponent } from "./testimonies-report/testimonies-report.component";

const routes: Routes = [
  {
    path: "testimonies",
    component: TestimoniesComponent,
    data: {
      title: "Read Church Testimonies"
    },
    canActivate: [AuthGuard]
  },
  /* {
    path: "testimony-details/:pageType/:id", //pageType here = approval
    component: ReadTestimonyDetailsComponent,
    data: {
      title: "Testimony Details"
    },
    canActivate: [AuthGuard]
  },*/
  {
    path: "send-testimonies",
    component: NewTestimonyComponent,
    data: {
      title: "Send Your Testimonies"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "testimonies-report", //pageType here = report
    component: TestimoniesReportComponent,
    data: {
      title: "Testimonies Report"
    },
    canActivate: [AuthGuard]
  }
  /*{
    path: "testimonies-report/:pageType", //pageType here = approval
    component: TestimoniesReportComponent,
    data: {
      title: "Approve Testimonies Details"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "testimonies-report/:pageType", //pageType here = proofread
    component: TestimoniesReportComponent,
    data: {
      title: "Proofread Testimonies Details"
    },
    canActivate: [AuthGuard]
  }*/
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TestimoniesRoutingModule {}
