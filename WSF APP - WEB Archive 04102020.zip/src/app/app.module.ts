import { NgModule } from "@angular/core";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations"; // this is needed!
import { RouterModule } from "@angular/router";
import { HttpModule } from "@angular/http";
import { APP_BASE_HREF, DatePipe, DecimalPipe } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";

import { AppComponent } from "./app.component";

import { SidebarModule } from "./sidebar/sidebar.module";
//import { FixedPluginModule } from './shared/fixedplugin/fixedplugin.module';
import { FooterModule } from "./shared/footer/footer.module";
import { NavbarModule } from "./shared/navbar/navbar.module";
//import { PagesnavbarModule } from "./shared/pagesnavbar/pagesnavbar.module";
import { AdminLayoutComponent } from "./layouts/admin/admin-layout.component";
import { AuthLayoutComponent } from "./layouts/auth/auth-layout.component";
import { AppRoutes, AppRoutingModule } from "./app.routing";
import { AuthGuard } from "./services/guards/auth-guard.service";
import { AuthService } from "./services/auth.service";
import { ApiRoutes } from "./services/api.routes";
import { APIService } from "./services/api.service";
import { TokenInterceptor } from "./services/token.interceptor.service";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { SharedModule } from "./app.shared.module";
// import { DialogModule } from "./plugins/NgExDialog/dialog.module";
import { ExcelService } from "./services/utils/excel.service";
import { SweetAlertService } from "./services/utils/sweet-alert.service";
import { FindACenterComponent } from "./components/centers/find-a-center/find-a-center.component";
import { PublicationService } from "./services/components-services/publications.service";
import { TestimonyService } from "./services/components-services/testimony.service";
import {
  BsDatepickerModule,
  BsDatepickerConfig
} from "ngx-bootstrap/datepicker";
import { BsModalRef } from "ngx-bootstrap/modal";
import { PositionService } from "./services/components-services/positions.service";
import { ReportsMenuService } from "./services/components-services/reports-menu.service";
//import { DynamicJsScriptLoaderService } from "./services/dynamic-js-script-loader.service";
//import { NgxPaginationModule } from "ngx-pagination";
import {
  NgBootstrapFormValidationModule,
  BootstrapVersion
} from "ng-bootstrap-form-validation";
import { DataCachePublicationsService } from "./services/data-cache/data-cache-publications.service";
import { UserAccountService } from "./services/components-services/user-account.service";
import { FollowUpService } from "./services/components-services/followup.service";
import { DynamicJsScriptLoaderService } from "./services/utils/dynamic-js-script-loader.service";
import { UtilitiesService } from "./services/utils/utilities.service";
//import { InViewportModule } from "@thisissoon/angular-inviewport";
//import { ScrollSpyModule } from "@thisissoon/angular-scrollspy";
import { PagesModule } from "./pages/pages.module";
import { FaqComponent } from "./pages/faq/faq.component";
import { MenuService } from "./services/components-services/menu.service";
import { ReportingService } from "./services/components-services/reporting.service";
import { NgxMaskModule, IConfig } from "ngx-mask";

import "chartjs-subtitle";
import "chartjs-plugin-datalabels";

//https://github.com/valor-software/ng2-charts/issues/922

export function getDatepickerConfig(): BsDatepickerConfig {
  return Object.assign(new BsDatepickerConfig(), {
    containerClass: "theme-red",
    //dateInputFormat: "DD-MMM-YYYY"
    dateInputFormat: "MMM DD, YYYY"
    //dateInputFormat: "YYYY/MMM/DD"
    //dateInputFormat: "MMM-DD-YYYY"
  });
}

@NgModule({
  imports: [
    FormsModule,
    RouterModule.forRoot(AppRoutes, {
      //scrollPositionRestoration: "enabled",
      //scrollOffset: [110, 110]
      //onSameUrlNavigation: "reload"
    }),
    HttpModule,
    SidebarModule,
    NavbarModule,
    FooterModule,
    PagesModule,
    //PagesnavbarModule,
    //NgBootstrapFormValidationModule,
    SharedModule,
    NgBootstrapFormValidationModule.forRoot({
      bootstrapVersion: BootstrapVersion.Three // Defaults to Four
      //,customErrorMessages: []
    }),
    BsDatepickerModule.forRoot(),
    //InViewportModule,
    // ScrollSpyModule.forRoot(),
    AppRoutingModule,
    BrowserAnimationsModule,
    BrowserModule
  ],
  declarations: [
    AppComponent,
    AdminLayoutComponent,
    AuthLayoutComponent
    //FaqComponent
  ],
  providers: [
    APIService,
    AuthService,
    ExcelService,
    SweetAlertService,
    MenuService,
    ReportingService,
    TestimonyService,
    PublicationService,
    PositionService,
    UserAccountService,
    DatePipe,
    DecimalPipe,
    UtilitiesService,
    ReportsMenuService,
    DataCachePublicationsService,
    FollowUpService,
    DynamicJsScriptLoaderService,
    AuthGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    },
    { provide: BsDatepickerConfig, useFactory: getDatepickerConfig }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
