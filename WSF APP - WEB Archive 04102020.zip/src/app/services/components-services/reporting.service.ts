import { Injectable } from "@angular/core";
import { APIService } from "../api.service";
import { ApiRoutes } from "../api.routes";
import {
  SimpleAttendanceReport,
  MeetingParticipantGetModel,
  CombinedMeetingRequest,
  SubmittedReportItem,
  MeetingReportToSubmit,
  MeetingParticipantRecordedAttendance,
  ReportFilter,
  MeetingDashboardItem,
  ObjectProperty
} from "app/models/reporting.models";
import { Observable, BehaviorSubject } from "rxjs";
import {
  ResponseModel,
  ReportAnalysisResultsGroupingType,
  ReportAnalysisPeriodType,
  ReportAnalysisResultsType,
  ReportPageActionType,
  MeetingReportingType,
  SimpleFilter,
  PaginatorFilter,
  PageDirection,
  ReportAnalysisDataStatus
} from "../../models/utilities.models";
import {
  CenterMemberPostModel,
  CenterSearchResult
} from "../../models/centers.models";
import { Meeting } from "../../models/meetings.models";
import * as moment from "moment";
import {
  AttendanceReportsAnalysisSummary,
  ParticipantsReportsAnalysisSummary,
  AttendanceReportsAnalysisDetailsByCenter,
  ParticipantsReportsAnalysisDetailsByCenter,
  MeetingFinancialAnalysis,
  FlattenedMeetingOffering,
  FinancialConstants
} from "../../models/reports.analysis.models";
import { getDatepickerConfig } from "../../app.module";
import { Router } from "@angular/router";
import { UtilitiesService } from "../utils/utilities.service";

@Injectable()
export class ReportingService {
  private subject = new BehaviorSubject<CenterSearchResult>(null);

  constructor(
    private apiService: APIService,
    private router: Router,
    private utilitiesService: UtilitiesService
  ) {}

  public CacheSelectedCenterForFiltering(menu: CenterSearchResult) {
    this.subject.next(menu);
  }

  public GetCachedSelectedCenterForFiltering(): Observable<CenterSearchResult> {
    return this.subject.asObservable();
  }

  getCurrentParticipants(
    meetingId: number
  ): Observable<MeetingParticipantGetModel[]> {
    return this.apiService.getAll<MeetingParticipantGetModel[]>(
      ApiRoutes.reports.meeting_participants_current + "/" + meetingId
    );
  }

  getCurrentMonthParticipants(
    meetingId: number
  ): Observable<MeetingParticipantGetModel[]> {
    return this.apiService.getAll<MeetingParticipantGetModel[]>(
      ApiRoutes.reports.all_participants_in_current_month + "/" + meetingId
    );
  }

  getAllParticipants(): Observable<MeetingParticipantGetModel[]> {
    return this.apiService.getAll<MeetingParticipantGetModel[]>(
      ApiRoutes.reports.meeting_participants_all
    );
  }

  /*getMembersDetailed(): Observable<MeetingParticipantGetModel[]> {
    return this.apiService.getAll<MeetingParticipantGetModel[]>(
      ApiRoutes.reports.center_members_detailed
    );
  }*/

  submitAttendanceReport(
    instanceWSFReport: MeetingReportToSubmit
  ): Observable<ResponseModel> {
    // console.log(instanceWSFReport);

    instanceWSFReport.meetingDate = this.utilitiesService.createDateAsUTC(
      instanceWSFReport.meetingDate
    );

    instanceWSFReport.meetingAttendance.meetingDate = this.utilitiesService.createDateAsUTC(
      instanceWSFReport.meetingAttendance.meetingDate
    );
    //console.log(instanceWSFReport);

    return this.apiService.post<ResponseModel>(
      ApiRoutes.reports.meeting_reports,
      instanceWSFReport
    );
  }

  updateAttendanceReport(
    id: number,
    instanceWSFReport: MeetingReportToSubmit
  ): Observable<ResponseModel> {
    //console.log(instanceWSFReport);

    instanceWSFReport.meetingDate = this.utilitiesService.createDateAsUTC(
      instanceWSFReport.meetingDate
    );

    instanceWSFReport.meetingAttendance.meetingDate = this.utilitiesService.createDateAsUTC(
      instanceWSFReport.meetingAttendance.meetingDate
    );

    return this.apiService.put<ResponseModel>(
      ApiRoutes.reports.update_meeting_report_attendance,
      id,
      instanceWSFReport
    );
  }

  createParticipant(
    centerMemberPostModel: CenterMemberPostModel
  ): Observable<ResponseModel> {
    return this.apiService.post<ResponseModel>(
      ApiRoutes.centers.center_members,
      centerMemberPostModel
    );
  }

  submitParticipantsAttendanceReport(
    instanceReport: MeetingReportToSubmit
  ): Observable<ResponseModel> {
    return this.apiService.post<ResponseModel>(
      ApiRoutes.reports.meeting_reports,
      instanceReport
    );
  }

  deleteParticipantsAttendanceReport(
    id: number,
    instanceReport: MeetingParticipantGetModel
  ): Observable<ResponseModel> {
    return this.apiService.put<ResponseModel>(
      ApiRoutes.reports.delete_meeting_participant_attendance,
      id,
      instanceReport
    );
  }

  getAllAttendanceRecordedForAParticipant(
    meetingId: number,
    participantId: number
  ): Observable<MeetingParticipantRecordedAttendance[]> {
    return this.apiService.getAll<MeetingParticipantRecordedAttendance[]>(
      ApiRoutes.reports.all_attendance_recorded_for_a_participant +
        "/" +
        meetingId +
        "/" +
        participantId
    );
  }

  getAssignedMeetings(privilege: string) {
    return this.apiService.getAll<MeetingDashboardItem[]>(
      ApiRoutes.resources.resources_sharing_get_assigned_meetings +
        "/" +
        privilege
    );
  }

  getAllMeetings() {
    return this.apiService.getAll<Meeting[]>(ApiRoutes.meetings.meetings);
  }

  getCentersDrillDown(parentCenterId: number) {
    return this.apiService.get<CenterSearchResult[]>(
      ApiRoutes.centers.drill_down_centers,
      parentCenterId
    );
  }

  /*getMeetings(): Observable<Meeting[]> {
    return this.apiService.getAll<Meeting[]>(ApiRoutes.reports.meetings);
  }

  combinedMeetingRequest(combinedMeetingRequest: CombinedMeetingRequest) {
    return this.apiService.post<CombinedMeetingRequest>(
      ApiRoutes.reports.combined_meeting_requests,
      combinedMeetingRequest
    );
  }*/

  getSubmittedReports(
    meetingId: number,
    filter: ReportFilter
  ): Observable<SubmittedReportItem[]> {
    return this.apiService.find<SubmittedReportItem[]>(
      ApiRoutes.reports.load_submitted_reports + "/" + meetingId,
      filter
    );
  }

  public navigateToReport(
    pageActionType: ReportPageActionType,
    meeting: MeetingDashboardItem
  ) {
    if (!meeting) {
      alert("Sorry Meeting Report Page could not be loaded");
      return;
    }

    if (pageActionType == ReportPageActionType.Submit) {
      this.router.navigateByUrl(meeting.postUrlOnWeb, {
        state: { meeting: meeting }
      });
    } else if (pageActionType == ReportPageActionType.Analyze) {
      this.navigateToReportAnalysis(meeting);
    }
  }

  public navigateToReportAnalysis(meeting: MeetingDashboardItem) {
    if (
      meeting.meetingReportType == MeetingReportingType.Attendance &&
      meeting.id
    ) {
      this.router.navigateByUrl(
        "app/reports/reports-analysis-for-attendance/" + meeting.id * 9, // just change id from user view
        {
          state: { meeting: meeting }
        }
      );
    } else if (
      meeting.meetingReportType ==
        MeetingReportingType.MultipleParticipations &&
      meeting.id
    ) {
      this.router.navigateByUrl(
        "app/reports/reports-analysis-for-multiple-participations/" +
          meeting.id * 7,
        {
          state: { meeting: meeting }
        }
      );
    } else if (
      meeting.meetingReportType == MeetingReportingType.SingleParticipation &&
      meeting.id
    ) {
      this.router.navigateByUrl(
        //"app/reports/reports-analysis-for-single-participation/" +
        "app/reports/reports-analysis-for-multiple-participations/" +
          meeting.id * 8,
        {
          state: { meeting: meeting }
        }
      );
    } else {
      alert("Invalid Meeting Type");
    }
  }

  getAttendanceReportSubmittedForACenter(
    meetingId: number,
    meetingDate: Date
  ): Observable<SubmittedReportItem> {
    return this.apiService.getAll<SubmittedReportItem>(
      ApiRoutes.reports.attendance_report_submitted_for_a_center +
        "/" +
        meetingId +
        "/" +
        meetingDate
    );
  }

  getReportsAnalysisForAttendanceSummary(
    filter: ReportFilter
  ): Observable<AttendanceReportsAnalysisSummary> {
    filter.resultsType = ReportAnalysisResultsType.Summary;
    return this.apiService.post<AttendanceReportsAnalysisSummary>(
      ApiRoutes.reports.get_attendance_analysis_data,
      filter
    );
  }

  getReportsAnalysisForAttendanceDetailsByCenters(
    filter: ReportFilter
  ): Observable<AttendanceReportsAnalysisDetailsByCenter[]> {
    filter.resultsType = ReportAnalysisResultsType.Details;

    return this.apiService.post<AttendanceReportsAnalysisDetailsByCenter[]>(
      ApiRoutes.reports.get_attendance_analysis_data,
      filter
    );
  }

  getReportsAnalysisForParticipantsSummary(
    filter: ReportFilter
  ): Observable<ParticipantsReportsAnalysisSummary> {
    filter.resultsType = ReportAnalysisResultsType.Summary;

    return this.apiService.post<ParticipantsReportsAnalysisSummary>(
      ApiRoutes.reports.get_participants_analysis_data,
      filter
    );
  }

  getReportingCentersUnderARole(
    filter: ReportFilter
  ): Observable<AttendanceReportsAnalysisDetailsByCenter[]> {
    return this.apiService.post<AttendanceReportsAnalysisDetailsByCenter[]>(
      ApiRoutes.reports.get_reporting_centers_under_a_role,
      filter
    );
  }

  getReportsAnalysisForParticipantsDetailsByCenters(
    filter: ReportFilter
  ): Observable<ParticipantsReportsAnalysisDetailsByCenter[]> {
    filter.resultsType = ReportAnalysisResultsType.Details;

    return this.apiService.post<ParticipantsReportsAnalysisDetailsByCenter[]>(
      ApiRoutes.reports.get_participants_analysis_data,
      filter
    );
  }

  getFinancialConstants(): Observable<FinancialConstants> {
    return this.apiService.getAll<FinancialConstants>(
      ApiRoutes.reports.get_financial_constants
    );
  }

  getFinancialReportsForMeetings(
    filter: ReportFilter
  ): Observable<MeetingFinancialAnalysis> {
    filter.resultsType = ReportAnalysisResultsType.Summary;
    return this.apiService.post<MeetingFinancialAnalysis>(
      ApiRoutes.reports.get_financial_reports,
      filter
    );
  }

  getFinancialReportsForCenters(
    filter: ReportFilter
  ): Observable<FlattenedMeetingOffering[]> {
    filter.resultsType = ReportAnalysisResultsType.Details;
    return this.apiService.post<FlattenedMeetingOffering[]>(
      ApiRoutes.reports.get_financial_reports,
      filter
    );
  }

  public getChartKey(key: ObjectProperty) {
    const monthsMapper: string[] = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec"
    ];

    if (
      key.key == "month"
      // || key.parentKey == "month" ||  key.gParentKey == "month"
    ) {
      return monthsMapper[key.value - 1];
    } else if (
      key.key == "quarter"
      // || key.parentKey == "quarter" ||  key.gParentKey == "quarter"
    ) {
      return "Q" + key.value;
    } else {
      return key.valuePrefix + " " + key.value;
    }
  }

  public reconfigureFilter(filter: ReportFilter, dateFormat: string = null) {
    /*startdate = moment()
      .subtract(1, "days")
      .startOf("day");
    begin.startOf("week");
    const today = moment();
    const from_date = today.startOf("week");
    const to_date = today.endOf("week");
    moment("2014-12-01")
      .utc()
      .quarter(); //outputs 4
    moment().quarter(); //returns the current quarter number: 1, 2, 3, 4.
    let quarters = [ 0, 1, 2, 3 ].map(i => 
      moment().subtract(i, 'Q').format('[q]Q-Y')
    )
    // quarters = [ 'q3-2016', 'q2-2016', 'q1-2016', 'q4-2015' ]

    dateB.diff(dateC, 'days'), 'days');
    moment('2018-09-10').isAfter('2018-09-09');
    isBefore(), isAfter(), and isSame()
*/

    if (!dateFormat) {
      dateFormat = "YYYY-MMMM-DD";
    }

    const _todayString = moment().format(dateFormat);
    const _today = moment();

    switch (filter.periodType) {
      case ReportAnalysisPeriodType.Today: {
        filter.resultsGroupingType = ReportAnalysisResultsGroupingType.InADay;
        filter.endDate = this.utilitiesService.createDateStringAsUTCDate(
          _today.format(dateFormat)
        );
        filter.startDate = this.utilitiesService.createDateStringAsUTCDate(
          _today.format(dateFormat)
        );
        filter.previousDataStartDate = this.utilitiesService.createDateStringAsUTCDate(
          _today.subtract(1, "days").format(dateFormat)
        );
        break;
      }
      case ReportAnalysisPeriodType.ThisWeek: {
        filter.resultsGroupingType = ReportAnalysisResultsGroupingType.InAWeek;
        filter.endDate = this.utilitiesService.createDateStringAsUTCDate(
          _today.format(dateFormat)
        );
        filter.startDate = this.utilitiesService.createDateStringAsUTCDate(
          _today.startOf("week").format(dateFormat)
        );
        filter.previousDataStartDate = this.utilitiesService.createDateStringAsUTCDate(
          _today
            .subtract(7, "days")
            .startOf("week")
            .format(dateFormat)
        );
        break;
      }
      case ReportAnalysisPeriodType.ThisMonth: {
        filter.resultsGroupingType = ReportAnalysisResultsGroupingType.InAMonth;
        filter.endDate = this.utilitiesService.createDateStringAsUTCDate(
          _today.format(dateFormat)
        );
        filter.startDate = this.utilitiesService.createDateStringAsUTCDate(
          _today.startOf("month").format(dateFormat)
        );
        filter.previousDataStartDate = this.utilitiesService.createDateStringAsUTCDate(
          _today
            .subtract(1, "months")
            .startOf("month")
            .format(dateFormat)
        );
        break;
      }
      case ReportAnalysisPeriodType.ThisQuarter: {
        filter.resultsGroupingType =
          ReportAnalysisResultsGroupingType.InAQuarter;
        filter.endDate = this.utilitiesService.createDateStringAsUTCDate(
          _today.format(dateFormat)
        );
        filter.startDate = this.utilitiesService.createDateStringAsUTCDate(
          _today.startOf("quarter").format(dateFormat)
        );
        filter.previousDataStartDate = this.utilitiesService.createDateStringAsUTCDate(
          _today
            .subtract(1, "quarters")
            .startOf("quarter")
            .format(dateFormat)
        );
        break;
      }
      case ReportAnalysisPeriodType.ThisYear: {
        filter.resultsGroupingType =
          ReportAnalysisResultsGroupingType.InAYearByMonths;
        filter.endDate = this.utilitiesService.createDateStringAsUTCDate(
          _today.format(dateFormat)
        );
        filter.startDate = this.utilitiesService.createDateStringAsUTCDate(
          _today.startOf("year").format(dateFormat)
        );
        filter.previousDataStartDate = this.utilitiesService.createDateStringAsUTCDate(
          _today
            .subtract(1, "years")
            .startOf("year")
            .format(dateFormat)
        );
        break;
      }
      case ReportAnalysisPeriodType.Custom: {
        // https://github.com/moment/moment/issues/3488
        const startDateMoment = moment(new Date(filter.startDate));
        const endDateMoment = moment(new Date(filter.endDate));

        //var dateDif = filter.endDate.Subtract(filter.startDate).Days;
        const startMonth = startDateMoment.month();
        const endMonth = endDateMoment.month();
        const startYear = startDateMoment.year();
        const endYear = endDateMoment.year();

        const daysDiff = startDateMoment.diff(endDateMoment, "days");
        const monthsDiff = startDateMoment.diff(endDateMoment, "months");

        if (daysDiff == 1) {
          filter.resultsGroupingType = ReportAnalysisResultsGroupingType.InADay;
          filter.previousDataStartDate = this.utilitiesService.createDateStringAsUTCDate(
            startDateMoment.subtract(1, "day").format(dateFormat)
          );
        }
        if (daysDiff > 1 && daysDiff < 8) {
          filter.resultsGroupingType =
            ReportAnalysisResultsGroupingType.InAWeek;
          filter.previousDataStartDate = this.utilitiesService.createDateStringAsUTCDate(
            startDateMoment.subtract(7, "day").format(dateFormat)
          );
        } else if (startMonth == endMonth && startYear == endYear) {
          filter.resultsGroupingType =
            ReportAnalysisResultsGroupingType.InAMonth;
          filter.previousDataStartDate = this.utilitiesService.createDateStringAsUTCDate(
            startDateMoment.subtract(1, "month").format(dateFormat)
          );
        } else if (
          startDateMoment.quarter() == endDateMoment.quarter() &&
          startYear == endYear
        ) {
          filter.resultsGroupingType =
            ReportAnalysisResultsGroupingType.InAQuarter;
          filter.previousDataStartDate = this.utilitiesService.createDateStringAsUTCDate(
            startDateMoment.subtract(1, "quarter").format(dateFormat)
          );
        } else if (monthsDiff <= 12) {
          filter.resultsGroupingType =
            ReportAnalysisResultsGroupingType.InAYearByMonths;
          filter.previousDataStartDate = this.utilitiesService.createDateStringAsUTCDate(
            startDateMoment.subtract(12, "month").format(dateFormat)
          );
        } else if (monthsDiff > 12 && endYear - startYear <= 3) {
          filter.resultsGroupingType =
            ReportAnalysisResultsGroupingType.InYearsByQuarters;
          filter.previousDataStartDate = this.utilitiesService.createDateStringAsUTCDate(
            startDateMoment
              .subtract(endYear - startYear, "year")
              .format(dateFormat)
          );
        } else if (endYear - startYear > 3) {
          filter.resultsGroupingType =
            ReportAnalysisResultsGroupingType.InYears;
          filter.previousDataStartDate = this.utilitiesService.createDateStringAsUTCDate(
            startDateMoment
              .subtract(endYear - startYear, "year")
              .format(dateFormat)
          );
        }
        break;
      }
      default:
        break;
    }
  }

  public injectDatesIntoStatusReportsFilter(
    filter: SimpleFilter,
    periodType: ReportAnalysisPeriodType,
    dateFormat: string = null
  ) {
    const _today = moment();

    if (!dateFormat) {
      dateFormat = "YYYY-MMMM-DD";
    }

    filter.endDate = this.utilitiesService.createDateStringAsUTCDate(
      _today.format(dateFormat)
    );

    if (periodType == ReportAnalysisPeriodType.ThisMonth) {
      filter.startDate = this.utilitiesService.createDateStringAsUTCDate(
        _today.startOf("month").format(dateFormat)
      );
    } else if (periodType == ReportAnalysisPeriodType.ThisYear) {
      filter.startDate = this.utilitiesService.createDateStringAsUTCDate(
        _today.startOf("year").format(dateFormat)
      );
    } else if (periodType == ReportAnalysisPeriodType.ThisQuarter) {
      filter.startDate = this.utilitiesService.createDateStringAsUTCDate(
        _today.startOf("quarter").format(dateFormat)
      );
    } else if (periodType == ReportAnalysisPeriodType.ThisWeek) {
      filter.startDate = this.utilitiesService.createDateStringAsUTCDate(
        _today.startOf("week").format(dateFormat)
      );
    }
  }
}
