import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-centers-data-update',
  templateUrl: './centers-data-update.component.html',
  styleUrls: ['./centers-data-update.component.css']
})
export class CentersDataUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
