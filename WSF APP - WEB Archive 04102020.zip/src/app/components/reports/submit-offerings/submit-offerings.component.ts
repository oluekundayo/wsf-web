import { Component, OnInit, Input, Output } from "@angular/core";
import { FinancialConstant } from "../../../models/reports.analysis.models";
import { FormBuilder, FormArray, FormControl, FormGroup } from "@angular/forms";
import { finalize } from "rxjs/operators";
import { ReportingService } from "../../../services/components-services/reporting.service";
//import { EventEmitter } from "protractor";

@Component({
  selector: "app-submit-offerings",
  templateUrl: "./submit-offerings.component.html",
  styleUrls: ["./submit-offerings.component.scss"]
})
export class SubmitOfferingsComponent implements OnInit {
  public currencies: FinancialConstant[] = [];
  public offeringTypes: FinancialConstant[] = [];
  public loading: boolean = false;
  public offeringsFormGroup: FormGroup;
  // @Output() public offerings: EventEmitter;

  constructor(
    private fb: FormBuilder,
    private reportingService: ReportingService
  ) {
    this.getFinancialConstants();
  }

  ngOnInit() {}

  private prepareForm() {
    if (this.offeringTypes) {
      let group = {};
      this.offeringTypes.forEach(element => {
        /*this.fb.group({
         addDynamicElement: this.fb.array([])
       })*/
        //group[element.id] = this.fb.array([]);
        group[element.id] = this.getAnOfferingFormGroup();
      });

      //console.log(group);
      this.offeringsFormGroup = this.fb.group(group);
      // console.log(this.formGroup);
    }
  }

  private getAnOfferingFormGroup(): FormGroup {
    let group = {};
    this.currencies.forEach(currency => {
      group[currency.id] = new FormControl(null);
    });
    //console.log(group);
    return this.fb.group(group);
  }

  private getFinancialConstants() {
    this.reportingService
      .getFinancialConstants()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.currencies = response.currencies;
        this.offeringTypes = response.offeringTypes;
        this.prepareForm();
      });
  }
}
