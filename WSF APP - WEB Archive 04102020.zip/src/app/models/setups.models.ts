export class Country {
  id: number;
  name: string;
  description: string;
}

export class State {
  id: number;
  name: string;
  description: string;
  registeredCountryId: number;
}

export class City {
  id: number;
  name: string;
  description: string;
  registeredStateId: number;
  registeredCountryId: number;
}

export class Church {
  id: number;
  name: string;
  mission: string;
  vision: string;
  address: string;
  registeredCityId: number;
  // logo: File;
  contactName: string;
  contactAddress: string;
  contactPhone: string;
  contactEmail: string;
  contact2Name: string;
  contact2Address: string;
  contact2Phone: string;
  contact2Email: string;
}

export class ChurchStructuralDivision {
  id: number;
  name: string;
  description: string;
}

export class ChurchSystem {
  id: number;
  name: string;
  description: string;
  churchStructuralDivisionId: number;
  churchId?: number;
  status?: string;
  orderBy?: number;
  churchSystemCodeForCenterRegistration?: string;
  createdAt?: Date;
  createdBy?: string;
  updatedAt?: Date;
  updatedBy?: string;
  deletedAt?: Date;
  deletedBy?: string;
  associatedCenterTypeId?: number;
  associatedCenterTypesIds?: number[];
}

export class CenterType {
  id: number;
  name: string;
  description: string;
  churchStructuralDivisionId: number;
  parentCenterTypeId: number;
  orderBy: number;
  centersNamePrefix: string;
  centersAliasPrefix: string;
  includeInFamilyTreeName: boolean;
  defaultChurchSystemsIdsForAllCenters: number[];
  churchSystemsIds: number[];
  maxAllowablePositionLevels: number;
  showToFindCenterOnSignUp: boolean;
  showCentersAsTransportationCentralLocation: boolean;
  belongsToChurchRoot: boolean;
  belongsToStructuralDivisionRoot: boolean;
}

/*
export class Meeting {
  id: number;
  name: string;
  description: string;
  churchStructuralDivisionId: number;
  churchSystemId: number;
  centerTypeHoldingMeetingId: number;
  holdsInSections: boolean;
  requiredParticipationCount: number;
  hasOfferings: boolean;
  // accessibleBy: boolean;
}*/

export class ResourcesCategoriesDivider {
  id: number;
  name: string;
  description: string;
}

export class ResourcesCategory {
  id: number;
  name: string;
  description: string;
  resourceCategoryDividerId: number;
}

export class Resource {
  id: number;
  name: string;
  description: string;
  resourceCategoryId: number;
  urlOnWeb: string;
  itemOrder: number;
  icon: string;
  cssClass: string;
  isVisible: boolean;
  isFreeForAll: boolean;
  showOnQuickLinkPage: boolean;
}

// ////////////////

export class Church_old {
  name: string;
  mission: string;
  vision: string;
  slogan: string;
  country: string;
  state: string;
  city: string;
  address: string;
  logo_path: string;
  logo: Blob; //blob
  contact_name: string;
  contact_address: string;
  contact_phone: string;
  contact_email: string;
  contact_2_name: string;
  contact_2_address: string;
  contact_2_phone: string;
  contact_2_email: string;
  created_at: Date;
  created_by: string;
  created_from: string;
}

export class ChurchCountry {
  name: string;
  description: string;
  created_at: Date;
  created_by: string;
}

export class ChurchState {
  country_id: number;
  country: string;
  name: string;
  description: string;
  created_at: Date;
  created_by: string;
}

export class ChurchCity {
  id: number;
  country_id: number;
  country: string;
  state_id: number;
  state: string;
  name: string;
  description: string;
  created_at: Date;
  created_by: string;
}

export class ChurchRoleBasedSystem {
  name: string;
  description: string;
  operational_division_id: number;
  operational_division: string;
  created_at: Date;
  created_by: string;
}

export class ChurchOperationalDivision {
  id: number;
  parent_division_id: number;
  parent_division: string;
  name: string = "";
  description: string = "";
  created_at: Date;
  created_by: string = "";
}

/*
export class ChurchSetupsRoutes {
  static cities = "church_setups/chuch_cities";
  static states = "church_setups/church_states";
  static countries = "church_setups/church_countries";
  static operational_systems = "church_setups/church_operational_systems";
  static structural_divisions = "church_setups/church_structural_divisions";
  static churches = "church_setups/churches";
}
*/
