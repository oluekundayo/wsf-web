import { Component, OnInit, EventEmitter, Output } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { FollowUpService } from "../../../services/components-services/followup.service";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { BsModalRef } from "ngx-bootstrap/modal";
import { Lookup, ResponseModel } from "../../../models/utilities.models";
import { finalize } from "rxjs/operators";
import {
  ApprovedSmsSenderIds,
  SmsMessaging,
  SmsMessagingDraft
} from "../../../models/follow_up.models";
@Component({
  selector: "app-compose-sms-dialog",
  templateUrl: "./compose-sms-dialog.component.html",
  styleUrls: ["./compose-sms-dialog.component.scss"]
})
export class ComposeSmsDialogComponent implements OnInit {
  loading: boolean = false;
  smsFormGroup: FormGroup;
  approvedSenderIds: string[] = [];
  drafts: SmsMessagingDraft[] = [];
  recipientsInput: string[] = [];
  //@Output() action = new EventEmitter<boolean>();

  constructor(
    private fb: FormBuilder,
    private sweetAlertService: SweetAlertService,
    private followupService: FollowUpService,
    public bsModalRef: BsModalRef
  ) {
    this.createFormControls();
  }

  public ngOnInit() {
    this.getMessagesDraft();
    this.getApprovedSmsSenderIds();
    this.smsFormGroup.patchValue({ recipients: this.recipientsInput });
  }

  createFormControls() {
    this.smsFormGroup = this.fb.group({
      subject: ["", Validators.required],
      message: ["", Validators.required],
      sendThroughSms: [false],
      sendThroughEmail: [false],
      recipients: [null],
      senderId: [null],
      id: [0]
    });
  }

  private getMessagesDraft() {
    this.loading = true;
    this.followupService
      .getSmsDrafts()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.drafts = response;
      });
  }

  private getApprovedSmsSenderIds() {
    this.loading = true;
    this.followupService
      .getApprovedSenderIds()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.approvedSenderIds = response.senderIds;
      });
  }

  public sendOutMessage() {
    if (
      !this.smsFormGroup.valid ||
      !this.smsFormGroup.value.senderId ||
      !this.recipientsInput.length ||
      (!this.smsFormGroup.value.sendThroughSms &&
        !this.smsFormGroup.value.sendThroughEmail)
    ) {
      this.sweetAlertService.showError(
        "Invalid Data. <br/>1. Sender Id is Required.<br/>2. Subject is Required.<br/>3. Message is Required.<br/>4. Recipients List is Required.<br/>5. Media is Required.",
        true
      );
      return;
    }

    const body: SmsMessaging = {
      id: this.smsFormGroup.value.id,
      subject: this.smsFormGroup.value.subject,
      text: this.smsFormGroup.value.message,
      senderId: this.smsFormGroup.value.senderId,
      recipients: this.recipientsInput,
      sendThroughSms: this.smsFormGroup.value.sendThroughSms,
      sendThroughEmail: this.smsFormGroup.value.sendThroughEmail
    };
    //console.log(_status);
    this.sweetAlertService
      .showConfirm("Send out this Message")
      .then(response => {
        if (response.value) {
          this.loading = true;
          this.followupService
            .sendMessage(body)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              this.sweetAlertService.showSuccess(response.message);
              //this.action.emit(true);
              this.navigateToList();
            });
        }
      });
  }

  public saveMessageDraft() {
    /* if (!this.testimonyForm.value.newClassficationTemp) {
      return;
    }*/

    //console.log(_status);
    this.sweetAlertService
      .showConfirm("Save this Message as Draft")
      .then(response => {
        if (response.value) {
          const newItem = {
            id: 0,
            text: this.smsFormGroup.value.message,
            subject: this.smsFormGroup.value.subject,
            from: this.smsFormGroup.value.senderId
          } as SmsMessagingDraft;

          this.loading = true;
          this.followupService
            .saveSmsDrafts(newItem)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              //console.log(response);
              this.sweetAlertService.showSuccess("Draft Saved Successfully");
              newItem.id = response.data;
              newItem.createdAt = new Date();
              this.drafts.push(newItem);
            });
        }
      });
  }

  public populateMessageFromDraft(message: SmsMessagingDraft) {
    this.smsFormGroup.patchValue({
      message: message.text,
      subject: message.subject
    });
  }

  public deleteMessageDraft(index: number, id: number) {
    this.sweetAlertService.showConfirm("Delete Draft").then(response => {
      if (response.value) {
        this.loading = true;
        this.followupService
          .deleteSmsDraft(id)
          .pipe(finalize(() => (this.loading = false)))
          .subscribe((response: ResponseModel) => {
            // const index = this.drafts.indexOf(center, 0);
            if (index > -1) {
              this.drafts.splice(index, 1);
            }
          });
      }
    });
  }

  private navigateToList() {
    //this.router.navigate(["app/testimonies/approve-testimonies"]);
    this.bsModalRef.hide();
  }
}
