import { finalize } from "rxjs/operators";
import { Component, OnInit, OnDestroy, TemplateRef } from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import {
  Lookup,
  ApiUrlParam,
  ResponseModel
} from "../../../models/utilities.models";
import {
  CenterSearchResult,
  CenterSearchParams,
  DrillDownCenters,
  CenterToDelete
} from "../../../models/centers.models";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { filter } from "lodash";

@Component({
  selector: "app-remove-center",
  templateUrl: "./remove-center.component.html",
  styleUrls: ["./remove-center.component.scss"]
})
export class RemoveCenterComponent implements OnInit, OnDestroy {
  loading = false;
  drilledDownCenters: DrillDownCenters[] = [];
  centerFinderResults: CenterSearchResult[];
  formGroup: FormGroup;
  modalRef: BsModalRef;
  selectedCenterToDelete: CenterSearchResult;
  searchFilter: string = "";
  pagingCurrentPage: number = 1;
  pagingItemsPerPage: number = 10;

  constructor(
    private api: APIService,
    private sweetAlertService: SweetAlertService,
    private modalService: BsModalService,
    private fb: FormBuilder
  ) {
    this.formGroup = fb.group({
      reason: ["", Validators.required],
      deletePermanently: [false],
      suspendCenter: [false]
    });
  }

  ngOnInit() {
    this.drillDownCenters({ centerId: 0 }, 0);

    /*this.loading = true;
    this.api
      .getAll<Lookup[]>(ApiRoutes.centers.centers_types_lookup)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.centerTypes = response;
      });*/
  }

  public drillDownCenters(
    parentCenter: CenterSearchResult,
    selectedIndex: number
  ) {
    //console.log(parentCenter);

    if (parentCenter && parentCenter.centerId >= 0) {
      this.loading = true;
      this.api
        .get<CenterSearchResult[]>(
          ApiRoutes.centers.drill_down_centers,
          parentCenter.centerId
        )
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          /* this.drilledDownCenters = filter(
            this.drilledDownCenters,
            (a, index) => {
              return index <= selectedIndex;
            }
          );*/
          this.centerFinderResults = response;
          this.drilledDownCenters.push({
            centerTypeId: response[0].centerTypeId,
            parentCenters: response
          } as DrillDownCenters);
        });
    }
    this.drilledDownCenters = filter(this.drilledDownCenters, (a, index) => {
      return index <= selectedIndex;
    });
  }

  public openConfirmationModal(
    template: TemplateRef<any>,
    center: CenterSearchResult
  ) {
    if (center) {
      this.selectedCenterToDelete = center;
      this.modalRef = this.modalService.show(template);
    }
  }

  public removeCenter() {
    this.sweetAlertService
      .showConfirm("Hope you know what you are doing?")
      .then(response => {
        if (response.value) {
          const deleteCenter = new CenterToDelete();
          deleteCenter.centerId = this.selectedCenterToDelete.centerId;
          deleteCenter.reason = this.formGroup.value.reason;
          deleteCenter.deletePermanently = this.formGroup.value.deletePermanently;
          deleteCenter.suspendCenter = this.formGroup.value.suspendCenter;

          this.processDelete(deleteCenter);
        }
      });
  }

  private processDelete(deleteCenter: CenterToDelete) {
    this.loading = true;
    this.api
      .post<ResponseModel>(ApiRoutes.centers.remove_center, deleteCenter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(
        response => {
          const index = this.centerFinderResults.indexOf(
            this.selectedCenterToDelete,
            0
          );
          if (index > -1) {
            this.centerFinderResults.splice(index, 1);
          }
          this.sweetAlertService.showMessage(response.message);
        },
        error => {
          this.modalRef.hide();
        }
      );
  }

  ngOnDestroy(): void {}
}
