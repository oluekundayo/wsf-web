import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "../../services/guards/auth-guard.service";
import { SendOutPublicationsComponent } from "./send-out-publications/send-out-publications.component";
import { ViewPublications } from "./view-publications/view-publications.component";
import { PublicationsReportComponent } from "./publications-report/publications-report.component";

const routes: Routes = [
  {
    path: "send-out-publications",
    component: SendOutPublicationsComponent,
    data: {
      title: "Send out Publications"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "publications",
    component: ViewPublications,
    data: {
      title: "Read Publications"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "view-publication",
    component: ViewPublications,
    data: {},
    canActivate: [AuthGuard]
  },
  /*{
    path: "publications-report/:pageType", //pageType here = report
    component: ApproveNewPublicationsComponent,
    data: {},
    canActivate: [AuthGuard]
  },*/
  {
    path: "publications-report",
    component: PublicationsReportComponent,
    data: {},
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PublicationsRoutingModule {}
