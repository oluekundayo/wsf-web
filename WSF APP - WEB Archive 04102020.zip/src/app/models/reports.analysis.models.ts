import { CenterMemberPostModel } from "./centers.models";
import {
  ReportAnalysisPeriodType,
  ReportAnalysisResultsGroupingType,
  Lookup,
  ReportAnalysisDataStatus,
  ReportAnalysisPageMode
} from "./utilities.models";
import { MeetingSection } from "./meetings.models";
import { PrivilegesDialogComponent } from "../components/dialog/privileges-dialog/privileges-dialog.component";
import { ObjectProperty } from "./reporting.models";
import { extend } from "webdriver-js-extender";
import { ChartOptions } from "chart.js";

export class TotalMeetingCenters {
  allMeetingCenters: number;
  newCenters: number;
  deactivatedCenters: number;
  replicationsDue: number;
  likelyInactiveCenters: number;
  centersThatReported: number;
  
  
}

export class TotalParticipantsStatusTillDate {
  allCompleted: number;
  allInProgress: number;
  allStarted: number;
  allRegistered: number;
}

export class ReportAnalysisBaseModel {
  dataPeriodType?: ReportAnalysisDataStatus;
  dataPeriodLabel?: string;
  meetingDate?: Date;
  week?: number;
  month?: number;
  monthYear?: string;
  quarter?: number;
  year?: number;
  displayOrder?: number;
  meetingId?: number;
  sectionId?: number;
  reportedAt?: Date;
  remarks?: string;
  coordinatedBy?: string;
  createdAt?: Date;
  createdBy?: string;
}

export class AttendanceAnalysisReportItem extends ReportAnalysisBaseModel {
  males: number = 0;
  females: number = 0;
  children: number = 0;
  totalAdults: number = 0;
  totalAttendance: number = 0;
  newConverts: number = 0;
  firstTimers: number = 0;
  testimonies: number = 0;
  holyGhostBaptism?: number = 0;
  isReportingACombinedMeeting?: boolean = false;
  totalSmsReports?: number = 0;
  offerings?: any[];
  reportedCenters?: number = 0;
  //reportedAt?: Date;
  //remarks?: string;
  //coordinatedBy?: string;
  //reportAnalysisDataPeriodType?: ReportAnalysisDataPeriodType;
}

export class ParticipantsAnalysisReportItem extends ReportAnalysisBaseModel {
  completed: number;
  registered: number;
  //justStarted: number;
  inProgress: number;
  males: number;
  females: number;
  adults: number;
  children: number;
  newConverts: number;
  firstTimers: number;
  newBaptism: number;
  //reportAnalysisDataPeriodType: ReportAnalysisDataPeriodType;
}

export class AttendanceReportsAnalysisSummary {
  reports: AttendanceAnalysisReportItem[] = [];
  centerTypesDrillDown: Lookup[] = [];
  totalMeetingCenters: TotalMeetingCenters;
  expectedPeriodKeys: ObjectProperty[];
}

export class ParticipantsReportsAnalysisSummary {
  reports: ParticipantsAnalysisReportItem[] = [];
  centerTypesDrillDown: Lookup[] = [];
  totalMeetingCenters: TotalMeetingCenters;
  totalParticipantsStatusTillDate: TotalParticipantsStatusTillDate;
  expectedPeriodKeys: ObjectProperty[];
}

export class AttendanceReportsAnalysisDetailsByCenter {
  parentCenterId: number;
  parentCenterName: string;
  centerId: number;
  centerAddress: string;
  centerChartLabel: string;
  centerName: string;
  centerAlias: string;
  contactFullName: string;
  contactPhone: string;
  totalMeetingCenters: TotalMeetingCenters;
  report: AttendanceAnalysisReportItem;
}

export class ParticipantsReportsAnalysisDetailsByCenter {
  parentCenterId: number;
  parentCenterName: string;
  centerId: number;
  centerAddress: string;
  centerChartLabel: string;
  centerName: string;
  contactFullName: string;
  contactPhone: string;
  totalMeetingCenters: TotalMeetingCenters;
  report: ParticipantsAnalysisReportItem;
}

export class AnalysisDashboardParams {
  label: string;
  value: number = 0;
  percentage: number = 0;
  description?: string;
  isEmphasized?: boolean = false;
}

export class AnalysisDashboardItems {
  totalMeetingCenters: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalNewCenters: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalDeactivatedCenters: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalReplicationsDue: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalLikelyInactiveCenters: AnalysisDashboardParams = new AnalysisDashboardParams();
  centersThatReported: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalCentersWithNoReports?: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalAdults: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalAttendance: AnalysisDashboardParams = new AnalysisDashboardParams();
  newConverts: AnalysisDashboardParams = new AnalysisDashboardParams();
  firstTimers: AnalysisDashboardParams = new AnalysisDashboardParams();
  testimonies: AnalysisDashboardParams = new AnalysisDashboardParams();
  males: number = 0;
  females: number = 0;
  children: number = 0;
}

export class AnalysisDashboardItemsForParticipants {
  totalNewConverts: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalHolyGhostBaptism: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalMales: number = 0;
  totalFemales: number = 0;
  totalAdults: number = 0;
  totalChildren: number = 0;
  totalInProgress: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalCompleted: AnalysisDashboardParams = new AnalysisDashboardParams();
  totalRegistered: number = 0;

  ageGroupChartLabels: string[] = ["Children", "Adults"];
  genderChartLabels: string[] = ["Males", "Females"];
  ageGroupChartData: number[] = [];
  genderChartData: number[] = [];
  ageGroupChartColors: any[] = [
    { backgroundColor: ["#878BB6", "rgba(225,10,24,0.2)"] },
    { borderColor: ["#AEEBF2", "#FEFFC9"] }
  ];
  genderChartColors: any[] = [
    { backgroundColor: ["#86c7f3", "#ffe199"] },
    { borderColor: ["#AEEBF2", "#FEFFC9"] }
  ];

  /* backgroundColor: [
        'rgba(110, 114, 20, 1)',
        'rgba(118, 183, 172, 1)',
        'rgba(0, 148, 97, 1)',
        'rgba(129, 78, 40, 1)',
        'rgba(129, 199, 111, 1)'
    ]*/
  // var bgColor = ["#878BB6", "#FFEA88", "#FF8153", "#4ACAB4", "#c0504d", "#8064a2", "#772c2a", "#f2ab71", "#2ab881", "#4f81bd", "#2c4d75"];
}

export class MeetingReportOffering {
  centerId: string;
  meetingId: string;
  meetingSectionId: string;
  meetingReportId: string;
  meetingDate: Date;
  sumOfferingInLocalCurrency: number;
  sumTitheInLocalCurrency: number;
  sumOtherOfferingsInLocalCurrency: number;
  offerings: MeetingOfferingType[];
}

export class AmountPerCurrency {
  currencyId: number;
  currencyName: string;
  amount: number;
}

export class MeetingOfferingType {
  meetingReportOfferingTypeId: number;
  meetingReportOfferingTypeName: string;
  amountTypes: AmountPerCurrency[];
}

// to the front end app
export class FlattenedMeetingOffering {
  meetingId: number;
  meetingName: string;
  meetingSectionId?: number;
  meetingSections: string[];
  offeringTypeId: number;
  offeringTypeName: string;
  currencyId: number;
  currencyName: string;
  amount: number;
  dataPeriodLabel: string;
  centerId: number;
  centerName: string;
  centerAddress: string;
  centerShortNameFromAddress: string;
  meetingDate: Date;
  Week: number;
  Month: number;
  MonthName: string;
  Quarter: number;
  QuarterName: string;
  Year: number;
}

export class MeetingFinancialAnalysis {
  expectedPeriodKeys: ObjectProperty[];
  offerings: FlattenedMeetingOffering[];
}

export class FinancialConstant {
  id: number;
  name: string;
  description: string;
  subDescription: string;
  hideOnChartByDefault: boolean;
  orderBy: number;
  sections: string[] = [];
  // added for front computations
  amountTypesSumTotal: any = {}; // currencyid:amount
  amountTypesOverAPeriod: any = {}; // currencyid:amount
  //amountTypesPerMeeting: any = {};
  currenciesSumTotal: any = {};
  //currenciesSumTotal: any = {};
  currenciesSumTotalOverAPeriod: any = {};
}

export class FinancialConstants {
  currencies: FinancialConstant[];
  offeringTypes: FinancialConstant[];
  meetingTypes: FinancialConstant[];
}

export class CurrenciesGroundTotal {
  forAllOfferingTypes?: any = {};
  forAllCenters?: any = {};
  forAllMeetingTypes?: any = {};
  forAllOfferingsOverAPeriods: any = {};
}

export class OfferingTypeGroupAnalysis {
  id: number;
  name: string;
  hasDataLoaded: boolean;
  meetingTypes?: FinancialConstant[];
  periods?: FinancialConstant[];
  groundTotals?: CurrenciesGroundTotal;
  meetingTypesChartData?: any[];
  //meetingTypesChartLabel: string[];
  periodsChartData?: any[];
  //periodsChartLabel: string[];
  meetingTypesChartOptions?: ChartOptions;
  periodsChartOptions?: ChartOptions;
  pageMode?: ReportAnalysisPageMode = ReportAnalysisPageMode.Chart;
  isChartDataReady: boolean;
}

export class FilteredCentersOfferingsAnalysis {
  centerId: number;
  centerName?: string;
  centerAddress?: string;
  centerShortNameFromAddress?: string;
  amountTypes?: any = {}; // currencyid:amount
}
