import { Injectable } from "@angular/core";
import {
  Testimony,
  PaginatedTestimonies
} from "../../models/testimonies.models";
import { find } from "lodash";

@Injectable({
  providedIn: "root"
})
export class DataCacheTestimoniesServiceOLD {
  private loadedTestimonies: PaginatedTestimonies = {
    paginator: {
      pageSize: 50,
      lastMinId: 0,
      // currentPage: 0,
      totalItemsCount: 0
    },
    testimonies: []
  };

  constructor() {}

  public getLoadedTestimonies(): PaginatedTestimonies {
    return this.loadedTestimonies;
  }

  public setLoadedTestimonies(testimonies: PaginatedTestimonies) {
    this.loadedTestimonies.testimonies.push(...testimonies.testimonies);
    this.loadedTestimonies.paginator = testimonies.paginator;
  }

  public initPaginatedTestimonies() {
    this.loadedTestimonies = {
      paginator: {
        pageSize: 30,
        lastMinId: 0,
        // currentPage: 0,
        totalItemsCount: 0
      },
      testimonies: []
    };

    return this.loadedTestimonies;
  }

  public findTestimony(itemId: number) {
    const test = find(this.loadedTestimonies.testimonies, (item: Testimony) => {
      return item.id === itemId;
    });

    return test;
  }
}
