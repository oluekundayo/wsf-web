import { Pipe, PipeTransform } from "@angular/core";
import { CenterMemberConversionStatus } from "../models/utilities.models";

@Pipe({
  name: "convertStatus"
})
export class ConvertStatusPipe implements PipeTransform {
  transform(value: CenterMemberConversionStatus, args?: any): string {
    if (value == CenterMemberConversionStatus.FirstTimer) return "First Timer";

    if (value == CenterMemberConversionStatus.NewConvert) return "New Birth";
  }
}
