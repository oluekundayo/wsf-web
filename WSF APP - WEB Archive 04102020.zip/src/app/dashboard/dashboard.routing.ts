import { Routes } from "@angular/router";

import { DashboardComponent } from "./dashboard.component";
import { AuthGuard } from "../services/guards/auth-guard.service";
import { FaqComponent } from "../pages/faq/faq.component";

export const DashboardRoutes: Routes = [
  {
    path: "",
    component: DashboardComponent,
    canActivate: [AuthGuard]
  }
  /*{
    path: "faq",
    component: FaqComponent,
    canActivate: [AuthGuard]
  }*/
];
