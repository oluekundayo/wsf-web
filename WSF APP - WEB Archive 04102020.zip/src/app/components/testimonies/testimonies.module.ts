import { NgModule } from "@angular/core";
import { SharedModule } from "../../app.shared.module";
import { TestimoniesRoutingModule } from "./testimonies-routing.module";
import { NewTestimonyComponent } from "./new-testimony/new-testimony.component";
import { TestimoniesComponent } from "./testimonies/testimonies.component";
import { AngularEditorModule } from "@kolkov/angular-editor";
import { TestimoniesReportComponent } from "./testimonies-report/testimonies-report.component";
import { ChartsModule } from "ng2-charts";
import { ApproveTestimonyDialogComponent } from "../dialog/approve-testimony-dialog/approve-testimony-dialog.component";

@NgModule({
  imports: [
    SharedModule,
    TestimoniesRoutingModule,
    AngularEditorModule,
    ChartsModule
  ],
  declarations: [
    TestimoniesComponent,
    NewTestimonyComponent,
    TestimoniesReportComponent,
    ApproveTestimonyDialogComponent
  ],
  entryComponents: [ApproveTestimonyDialogComponent]
})
export class TestimoniesModule {}
