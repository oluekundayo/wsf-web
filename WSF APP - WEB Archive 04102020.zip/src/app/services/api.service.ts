import { throwError as observableError, Observable } from "rxjs";

import { catchError } from "rxjs/operators";
import { Injectable } from "@angular/core";
import { environment } from "environments/environment";
import {
  HttpClient,
  HttpParams,
  HttpHeaders,
  HttpErrorResponse
} from "@angular/common/http";
import { AuthService } from "./auth.service";
import {
  ApiUrlParam,
  MyHttpOptions,
  ResponseModel
} from "../models/utilities.models";
import { SweetAlertService } from "./utils/sweet-alert.service";
import { DatePipe } from "@angular/common";
import { isDate } from "lodash";
import { UtilitiesService } from "./utils/utilities.service";

@Injectable()
export class APIService {
  //public uploadUrl: string;

  //public params: {};

  constructor(
    private httpClient: HttpClient,
    private authService: AuthService,
    private sweetAlertService: SweetAlertService,
    private datepipe: DatePipe
  ) {
    // inject jwt header into all requests
    //this.uploadUrl = environment.API_BASE_URL + "/upload";
  }

  /**
   * get
   id  */
  public get<T>(
    apiRoute: string,
    id?: number,
    _params?: ApiUrlParam[]
  ): Observable<T> {
    //return observable by default

    /*if (params) {
      this.params = { params: new HttpParams(params) };
    }*/

    let params = new HttpParams();
    if (_params) {
      _params.forEach(parameter => {
        params = params.set(parameter.name, parameter.value);
      });
    }

    return this.httpClient
      .get<T>(`${environment.API_BASE_URL}/${apiRoute}/${id}`, { params })
      .pipe(catchError(error => this.handleErrorWithObservable(error)));
  }

  /**
   * get
   id  */
  /*
  public getWithOptions<T>(
    apiRoute: string,
    id?: number,
    options?: MyHttpOptions
  ): Observable<T> {
    return this.httpClient
      .get<T>(`${environment.API_BASE_URL}/${apiRoute}/${id}`, options)
      .pipe(catchError(error => this.handleErrorWithObservable(error)));
  }
*/
  /**
   * getAll
   */

  public getAll<T>(apiRoute: string, _params?: ApiUrlParam[]): Observable<T> {
    /*if (params) {
      this.params = { params: new HttpParams(params) };
    }*/
    let params = new HttpParams();
    if (_params) {
      _params.forEach(parameter => {
        params = params.set(parameter.name, parameter.value);
      });
    }

    return this.httpClient
      .get<T>(`${environment.API_BASE_URL}/${apiRoute}`, { params })
      .pipe(catchError(error => this.handleErrorWithObservable(error)));
  }

  /**
   * getAll
   */

  public find<T>(apiRoute: string, _params?: any): Observable<T> {
    let params = new HttpParams();
    if (_params) {
      Object.keys(_params).forEach(key => {
        //console.log(key + ":" + _params[key]);
        let value: any = _params[key];
        //console.log(isDate(value));

        try {
          if (isDate(value)) {
            //console.log(isDate(value));
            // console.log(value);
            value = UtilitiesService.convertDateAsString(value);
            // console.log(value);
          }
        } catch (e) {}

        if (value) {
          params = params.set(key, value);
        }
      });
    }

    if (_params) {
      //console.log(`${environment.API_BASE_URL}/${apiRoute}`, { params });
      return this.httpClient
        .get<T>(`${environment.API_BASE_URL}/${apiRoute}`, { params })
        .pipe(catchError(error => this.handleErrorWithObservable(error)));
    } else {
      return this.httpClient
        .get<T>(`${environment.API_BASE_URL}/${apiRoute}`)
        .pipe(catchError(error => this.handleErrorWithObservable(error)));
    }
  }

  public findWithId<T>(apiRoute: string, id?: number): Observable<T> {
    return this.httpClient
      .get<T>(`${environment.API_BASE_URL}/${apiRoute}/${id}`)
      .pipe(catchError(error => this.handleErrorWithObservable(error)));
  }

  /**
   * post
   */
  public post<T>(apiRoute: string, body: any): Observable<T> {
    //return observable by default

    return this.httpClient
      .post<T>(`${environment.API_BASE_URL}/${apiRoute}`, body)
      .pipe(
        //.catch(this.handleErrorWithObservable);
        catchError(error => this.handleErrorWithObservable(error))
      );
  }

  /**
   * delete
   */
  public delete<T>(
    apiRoute: string,
    id: number,
    _params?: ApiUrlParam[]
  ): Observable<T> {
    let params = new HttpParams();
    if (_params) {
      _params.forEach(parameter => {
        params = params.set(parameter.name, parameter.value);
      });
    }

    //return observable by default
    return this.httpClient
      .delete<T>(`${environment.API_BASE_URL}/${apiRoute}/${id}`, { params })
      .pipe(catchError(error => this.handleErrorWithObservable(error)));
  }

  /**
   * patch
   */
  public patch<T>(apiRoute: string, id: number, body: any): Observable<T> {
    //return observable by default
    return this.httpClient
      .patch<T>(`${environment.API_BASE_URL}/${apiRoute}/${id}`, body)
      .pipe(catchError(error => this.handleErrorWithObservable(error)));
  }

  /**
   * put
   */
  public put<T>(
    apiRoute: string,
    id: number,
    body: any
    //,otherRouteParams: any[] = null
  ): Observable<T> {
    //return observable by default

    let route: string = `${environment.API_BASE_URL}/${apiRoute}/${id}`;

    /*if (otherRouteParams && otherRouteParams.length) {
      otherRouteParams.forEach(element => {
        route = route + "/" + element;
      });
    }*/

    return this.httpClient
      .put<T>(route, body)
      .pipe(catchError(error => this.handleErrorWithObservable(error)));
  }

  public postWithDifferentReturn<T>(
    apiRoute: string,
    body: any
  ): Observable<any> {
    //return observable by default

    return;
    this.httpClient
      .post<T>(`${environment.API_BASE_URL}/${apiRoute}`, body)
      //.catch(this.handleErrorWithObservable);
      .pipe(catchError(error => this.handleErrorWithObservable(error)));
  }

  /**
   * getPromise
   id  */
  public getWithPromise<T>(
    apiRoute: string,
    id: number,
    _params?: ApiUrlParam[]
  ): Promise<T> {
    //return observable by default
    /*if (params) {
      this.params = { params: new HttpParams(params) };
    }*/

    let params = new HttpParams();
    if (_params) {
      _params.forEach(parameter => {
        params = params.set(parameter.name, parameter.value);
      });
    }

    return this.httpClient
      .get<T>(`${environment.API_BASE_URL}/${apiRoute}/${id}`, { params })
      .toPromise()
      .catch(error => this.handleErrorWithPromise(error));
  }

  /**
   * getAllWithPromise
   */
  public getAllWithPromise<T>(
    apiRoute: string,
    _params?: ApiUrlParam[]
  ): Promise<T> {
    //return observable by default

    let params = new HttpParams();
    if (_params) {
      _params.forEach(parameter => {
        params = params.set(parameter.name, parameter.value);
      });
    }

    return this.httpClient
      .get<T>(`${environment.API_BASE_URL}/${apiRoute}`, { params })
      .toPromise()
      .catch(error => this.handleErrorWithPromise(error));
  }

  /**
   * postWithPromise
   */
  public postWithPromise<T>(apiRoute: string, body: any): Promise<T> {
    //return observable by default
    return this.httpClient
      .post<T>(`${environment.API_BASE_URL}/${apiRoute}`, body)
      .toPromise()
      .catch(error => this.handleErrorWithPromise(error));
  }

  /**
   * deleteWithPromise
   */
  public deleteWithPromise<T>(apiRoute: string, id: number): Promise<T> {
    //return observable by default
    return this.httpClient
      .delete<T>(`${environment.API_BASE_URL}/${apiRoute}/${id}`)
      .toPromise()
      .catch(error => this.handleErrorWithPromise(error));
  }

  /**
   * patchWithPromise
   */
  public patchWithPromise<T>(
    apiRoute: string,
    id: number,
    body: any
  ): Promise<T> {
    //return observable by default
    return this.httpClient
      .patch<T>(`${environment.API_BASE_URL}/${apiRoute}/${id}`, body)
      .toPromise()
      .catch(error => this.handleErrorWithPromise(error));
  }

  /**
   * putWithPromise
   */
  public putWithPromise<T>(
    apiRoute: string,
    id: number,
    body: any
  ): Promise<T> {
    //return observable by default
    return this.httpClient
      .put<T>(`${environment.API_BASE_URL}/${apiRoute}/${id}`, body)
      .toPromise()
      .catch(error => this.handleErrorWithPromise(error));
  }

  uploadAttachments(
    apiRoute: string,
    data: FormData
  ): Observable<ResponseModel> {
    const headers = new HttpHeaders({
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
    });

    const options: MyHttpOptions = {
      headers: headers
    };

    return this.httpClient
      .post<ResponseModel>(
        //`${environment.API_BASE_URL}/${this.url.church_publication.publication}`,
        `${environment.API_BASE_URL}/${apiRoute}`,
        data
      )
      .pipe(catchError(error => this.handleErrorWithObservable(error)));
  }

  downloadAttachment(apiRoute: string, fileName: string, mimeType: string) {
    //http://javabypatel.blogspot.com/2017/11/download-file-in-angular2.html

    const headers = new HttpHeaders({
      "Content-Type": mimeType,
      Accept: mimeType
    });

    const options: MyHttpOptions = {
      headers: headers,
      responseType: "blob" as "json" // arrayBuffer
    };

    return this.httpClient
      .get<Blob>(
        /* `${environment.API_BASE_URL}/${this.url.church_publication
        .publication_download +
        "/" +
        fileName}`,*/
        `${environment.API_BASE_URL}/${apiRoute}/${fileName}`,
        options
      )
      .pipe(catchError(error => this.handleErrorWithObservable(error)));
  }

  /*getZip(path: string, params: URLSearchParams = new URLSearchParams()): Observable<any> {
    let headers = this.setHeaders({
         'Content-Type': 'application/zip',
         'Accept': 'application/zip'
       });
   
    return this.http.get(`${environment.apiUrl}${path}`, { 
      headers: headers, 
      search: params, 
      responseType: ResponseContentType.ArrayBuffer //magic
    })
             .catch(this.formatErrors)
             .map((res:Response) => res['_body']);
   }*/

  private alertError(response) {
    if (response instanceof HttpErrorResponse) {
      // console.log(response);

      if (response.status === 401 || response.status === 403) {
        return;
      }

      if (response.status === 0) {
        //"status":0,"statusText":"Unknown Error","url":null,"ok":false,"name":"HttpErrorResponse","message":"Http failure response for (unknown url): 0 Unknown Error";
        this.sweetAlertService.showError(
          "Sorry, WSF Portal application could not connect to the server at this moment. Please try again later."
        );
      } else {
        let errorMessage = "";
        if (response.error) {
          if (Array.isArray(response.error))
            for (let i = 0; i < response.error.length; i++) {
              errorMessage += response.error[i] + "<br/>";
            }
          else if (response.error.error) errorMessage = response.error.error;
          else errorMessage = response.error;
        } else {
          errorMessage = "Your data could not be processed by the server.";
        }

        //if (error.status != 0) alert(errorMessage);
        this.sweetAlertService.showError(errorMessage, true);
      }
    } else {
      this.sweetAlertService.showError(
        "Your internet connection is down. Please check and try again."
      );
    }
  }

  private handleErrorWithObservable(error: any) {
    //console.log(error);
    this.alertError(error);
    return observableError(error);
  }

  private handleErrorWithPromise(error: any) {
    this.alertError(error);
    return Promise.reject(error);
  }
}
