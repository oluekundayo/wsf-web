import { finalize } from "rxjs/operators";
import {
  Component,
  OnInit,
  Output,
  // EventEmitter,
  OnDestroy,
  EventEmitter
} from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import {
  Lookup,
  ApiUrlParam,
  ResponseModel,
  CenterMemberShipStatus,
  CenterMemberConversionStatus
} from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import {
  CenterMemberPostModel,
  CenterMemberGetModel
} from "../../../models/centers.models";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";

//import * as moment from "moment";
import { FollowUpService } from "../../../services/components-services/followup.service";
import { Router } from "@angular/router";
import { UtilitiesService } from "../../../services/utils/utilities.service";
import { BsModalRef } from "ngx-bootstrap/modal";
import { MeetingParticipantGetModel } from "../../../models/reporting.models";

@Component({
  selector: "app-create-followup-center-member-dialog",
  templateUrl: "./create-followup-center-member-dialog.component.html",
  styleUrls: ["./create-followup-center-member-dialog.component.scss"]
})
export class CreateFollowupCenterMemberDialogComponent
  implements OnInit, OnDestroy {
  loading = false;
  formGroup: FormGroup;
  genderList: string[] = [];
  ageGroupList: string[] = [];
  prefixList: string[] = [];
  centerMember: CenterMemberPostModel;
  meetingList: Lookup[] = [];

  newMembersCurrentlySubmitted: CenterMemberGetModel[] = [];
  @Output() action = new EventEmitter<CenterMemberGetModel[]>();

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    private router: Router,
    private followUpService: FollowUpService,
    private sweetAlertService: SweetAlertService,
    private utilitiesService: UtilitiesService,
    public bsModalRef: BsModalRef
  ) {}
  ngOnInit() {
    this.prefixList = ["Pastor", "Elder", "Dcn.", "Dcns.", "Bro.", "Sis."];
    this.genderList = ["Male", "Female"];
    this.ageGroupList = ["Adult", "Child"];

    this.createForm();
    this.loadMeetings();
  }

  private createForm() {
    this.formGroup = this.fb.group({
      memberConversionType: ["", Validators.required],
      personalDetails: this.fb.group({
        prefix: [""],
        lastname: ["", Validators.required],
        firstname: ["", Validators.required],
        otherName: [""],
        gender: ["", Validators.required],
        address: [""],
        phone: [""],
        email: [""],
        ageGroup: ["", Validators.required]
        //joinedCenterAt: [null],
        //convertedAt: [null]
      }),
      churchDetails: this.fb.group({
        wofbiStatus: [""],
        wofbiStatusDate: [null]
      }),
      invitedBy: this.fb.group({
        fullName: [""],
        phone: [""],
        email: [""],
        address: [""]
      }),
      meetingAttended: this.fb.group({
        meetingDate: [null, Validators.required],
        meetingId: [null, Validators.required],
        meetingCoordinatedBy: [""]
      })
    });
  }

  private loadMeetings() {
    this.followUpService.getAssignedMeetingsToSubmit().subscribe(response => {
      this.meetingList = response;
    });
  }

  public submitRecord() {
    if (this.formGroup.valid) {
      const memberConversionType = this.formGroup.get("memberConversionType")
        .value;

      const member = Object.assign(
        {},
        this.formGroup.value
      ) as CenterMemberPostModel;

      member.meetingAttended.meetingDate = this.utilitiesService.createDateAsUTC(
        member.meetingAttended.meetingDate
      );

      if (memberConversionType == "IsFirstTimer") {
        member.memberConversionStatus = CenterMemberConversionStatus.FirstTimer;
      } else if (memberConversionType == "IsNewConvert") {
        member.memberConversionStatus = CenterMemberConversionStatus.NewConvert;
      }

      member.membershipStatus = CenterMemberShipStatus.CenterMember;
      //console.log(member);

      this.sweetAlertService
        .showConfirm("New Record will be saved.")
        .then(a => {
          if (a.value) {
            this.loading = true;
            this.followUpService
              .saveNewConvert(member)
              .pipe(finalize(() => (this.loading = false)))
              .subscribe((response: ResponseModel) => {
                if (response.isOk) {
                  // this.formGroup.reset();
                  this.newMembersCurrentlySubmitted.push(response.data);
                  this.resetForm();
                  this.sweetAlertService.showSuccess(
                    "Record saved successfully."
                  );
                  // this.bsModalRef.hide();
                }
              });
          }
        });
    }
  }

  public resetForm() {
    this.formGroup.patchValue({
      memberConversionType: "",
      personalDetails: {
        prefix: "",
        lastname: "",
        firstname: "",
        otherName: "",
        gender: "",
        address: "",
        phone: "",
        email: "",
        ageGroup: ""
      },
      churchDetails: {
        //joinedCenterAt: null,
        //convertedAt: null,
        wofbiStatus: "",
        wofbiStatusDate: null
      },
      invitedBy: {
        fullName: "",
        phone: "",
        email: "",
        address: ""
      },
      meetingAttended: {
        meetingDate: null,
        meetingId: null,
        meetingCoordinatedBy: ""
      }
    });
  }

  public navigateToList() {
    this.router.navigate(["app/follow-up/contact-new-converts"]);
  }

  public closeModal() {
    this.bsModalRef.hide();
    this.action.emit(this.newMembersCurrentlySubmitted);
  }

  ngOnDestroy(): void {}
}
