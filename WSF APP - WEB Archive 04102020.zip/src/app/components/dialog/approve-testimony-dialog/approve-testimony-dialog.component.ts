import { Component, OnInit, Inject, EventEmitter, Output } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from "@angular/forms";
import { TestimonyService } from "../../../services/components-services/testimony.service";
import {
  TestimonyClassification,
  Testimony,
  TestimonyApproval
} from "../../../models/testimonies.models";
import { AngularEditorConfig } from "@kolkov/angular-editor";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import {
  ResponseModel,
  Contact,
  Lookup,
  ApprovalStatus,
  ApprovalPost
} from "../../../models/utilities.models";
import { finalize } from "rxjs/operators";
import { ActivatedRoute, Router } from "@angular/router";
import { Observable } from "rxjs";
import { BsModalRef } from "ngx-bootstrap/modal";
@Component({
  selector: "app-approve-testimony-dialog",
  templateUrl: "./approve-testimony-dialog.component.html",
  styleUrls: ["./approve-testimony-dialog.component.scss"]
})
export class ApproveTestimonyDialogComponent implements OnInit {
  TestimonyClassification: TestimonyClassification[];
  loading: boolean = false;
  angularEditorConfig: AngularEditorConfig = {};
  testimonyForm: FormGroup;
  testimony: Testimony;
  selectedTestimonyIdInput: number;
  currentStatusInput: ApprovalStatus;
  classifications: Lookup[] = [];
  showNewClassificationInput: boolean = false;
  @Output() action = new EventEmitter<boolean>();

  constructor(
    private fb: FormBuilder,
    // private route: ActivatedRoute,
    // private router: Router,
    private sweetAlertService: SweetAlertService,
    private testimonyService: TestimonyService,
    public bsModalRef: BsModalRef
  ) {
    this.testimony = new Testimony();
    this.testimony.testifier = new Contact();

    this.setAngularEditorConfig();
  }

  public ngOnInit() {
    this.createFormControls();
    this.getTestimony();
    this.getTestimoniesClassifications();
  }

  createFormControls() {
    this.testimonyForm = this.fb.group({
      testifier: [""],
      title: ["", Validators.required],
      details: ["", Validators.required],
      sharedAt: [""],
      testimoniesClassificationsIds: [null, Validators.required],
      newClassficationTemp: ""
    });
  }

  private patchFormControls() {
    this.testimonyForm.patchValue({
      testifier: this.testimony.testifier.fullName,
      title: this.testimony.title,
      details: this.testimony.details,
      sharedAt: this.testimony.sharedAt,
      testimoniesClassificationsIds: this.testimony
        .testimoniesClassificationsIds
    });
  }

  private setAngularEditorConfig() {
    this.angularEditorConfig = {
      editable: true,
      spellcheck: true,
      height: "40rem",
      minHeight: "20rem",
      placeholder: "Proofread Testimony Details here...",
      translate: "no",
      //uploadUrl: 'v1/images', // if needed
      customClasses: [
        // optional
        {
          name: "quote",
          class: "quote"
        },
        {
          name: "redText",
          class: "redText"
        },
        {
          name: "titleText",
          class: "titleText",
          tag: "h1"
        }
      ]
    };
  }

  private getTestimony() {
    this.loading = true;
    this.testimonyService
      .getTestimonyDetail(this.selectedTestimonyIdInput)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.testimony = response;
        this.patchFormControls();
      });
  }

  private getTestimoniesClassifications() {
    this.testimonyService
      .getTestimoniesClassifications()
      .subscribe(response => {
        //console.log(response);
        this.classifications = response;
      });
  }

  /*submitTestimony() {
    const body: Testimony = {
      id: this.itemId,
      title: this.testimonyForm.value.title,
      details: this.testimonyForm.value.details,
      detailsBeforeProofReading: this.testimony.details,
      testimoniesClassificationsIds: this.testimonyForm.value
        .testimoniesClassificationsIds
    };
    console.log(body);
    this.loading = true;
    this.testimonyService
      .approveItem(this.itemId, body)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((data: ResponseModel) => {
        this.sweetAlertService.showSuccess(data.message);
        //console.log(data);
        this.testimonyForm.reset();
      });
  }*/

  public proofReadItem() {
    if (!this.testimonyForm.valid) {
      return;
    }

    const confirmMessage = "This Testimony will be marked as proofread";
    const sucessMessage = "Testimony marked as ProofRead";

    const body: TestimonyApproval = {
      id: this.selectedTestimonyIdInput,
      title: this.testimonyForm.value.title,
      details: this.testimonyForm.value.details,
      testimoniesClassificationsIds: this.testimonyForm.value
        .testimoniesClassificationsIds,
      approvalStatus: ApprovalStatus.Unapproved
    };

    //console.log(_status);
    this.sweetAlertService.showConfirm(confirmMessage).then(response => {
      if (response.value) {
        this.loading = true;
        this.testimonyService
          .proofReadItem(this.selectedTestimonyIdInput, body)
          .pipe(finalize(() => (this.loading = false)))
          .subscribe((response: ResponseModel) => {
            this.sweetAlertService.showSuccess(sucessMessage);
            this.action.emit(true); //<< here you can send object  instead of true
            this.navigateToList();
          });
      }
    });
  }

  public approveItem() {
    if (!this.testimonyForm.valid) {
      return;
    }

    const confirmMessage = "This Testimony will be approved";
    const sucessMessage = "Testimony marked as Approved";

    const body: TestimonyApproval = {
      id: this.selectedTestimonyIdInput,
      title: this.testimonyForm.value.title,
      details: this.testimonyForm.value.details,
      testimoniesClassificationsIds: this.testimonyForm.value
        .testimoniesClassificationsIds,
      approvalStatus: ApprovalStatus.Approved
    };

    //console.log(_status);
    this.sweetAlertService.showConfirm(confirmMessage).then(response => {
      if (response.value) {
        this.loading = true;
        this.testimonyService
          .approveItem(this.selectedTestimonyIdInput, body)
          .pipe(finalize(() => (this.loading = false)))
          .subscribe((response: ResponseModel) => {
            this.sweetAlertService.showSuccess(sucessMessage);
            this.action.emit(true);
            this.navigateToList();
          });
      }
    });
  }

  public disapproveItem() {
    const body: TestimonyApproval = {
      id: this.selectedTestimonyIdInput,
      approvalStatus: ApprovalStatus.Disapproved
    };

    const confirmMessage = "This Testimony will be disapproved.";
    const sucessMessage = "Testimony successfully disapproved";

    this.sweetAlertService
      .showPrompt(confirmMessage, "Disapproval Reasons and other comments")
      .then(response => {
        if (response.value) {
          body.approvalComment = response.value;
          this.loading = true;
          this.testimonyService
            .approveItem(this.selectedTestimonyIdInput, body)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              this.sweetAlertService.showSuccess(sucessMessage);
              this.action.emit(true); //<< here you can send object  instead of true
              this.navigateToList();
            });
        }
      });
  }

  public saveNewClassification() {
    if (!this.testimonyForm.value.newClassficationTemp) {
      return;
    }

    //console.log(_status);
    this.sweetAlertService
      .showConfirm("Save this New Testimony Classification")
      .then(response => {
        if (response.value) {
          const newItem = {
            id: 0,
            name: this.testimonyForm.value.newClassficationTemp,
            itemsCount: 0,
            description: ""
          } as Lookup;

          this.loading = true;
          this.testimonyService
            .saveNewClassification(newItem)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              //console.log(response);
              this.sweetAlertService.showSuccess("Saved Successfully");
              newItem.id = response.data;
              this.classifications.push(newItem);
              this.testimonyForm.patchValue({ newClassficationTemp: "" });
            });
        }
      });
  }

  private navigateToList() {
    //this.router.navigate(["app/testimonies/approve-testimonies"]);
    this.bsModalRef.hide();
  }
}
