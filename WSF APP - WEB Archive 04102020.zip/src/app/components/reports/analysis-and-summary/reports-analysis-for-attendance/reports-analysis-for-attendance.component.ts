import { Component, OnInit, OnDestroy } from "@angular/core";
import { DynamicJsScriptLoaderService } from "../../../../services/utils/dynamic-js-script-loader.service";
import { finalize, map, filter } from "rxjs/operators";
import {
  ReportFilter,
  ObjectProperty
} from "../../../../models/reporting.models";
import {
  ReportAnalysisPeriodType,
  ReportAnalysisResultsGroupingType,
  ReportAnalysisDataStatus,
  ReportAnalysisChartType,
  Lookup
} from "../../../../models/utilities.models";
import {
  ActivatedRoute,
  Router,
  NavigationStart,
  NavigationEnd
} from "@angular/router";
import { Subscription } from "rxjs";
import { Meeting } from "../../../../models/meetings.models";
import { ChartOptions } from "chart.js";
import {
  sumBy,
  map as _map,
  maxBy,
  filter as _filter,
  find as _find,
  meanBy,
  groupBy
} from "lodash";
import { ReportingService } from "../../../../services/components-services/reporting.service";
import {
  ReportAnalysisBaseModel,
  AttendanceReportsAnalysisSummary,
  AnalysisDashboardItems,
  AttendanceAnalysisReportItem,
  AttendanceReportsAnalysisDetailsByCenter
} from "../../../../models/reports.analysis.models";
//import * as moment from "moment";
import { CenterSearchResult } from "../../../../models/centers.models";

@Component({
  selector: "app-reports-analysis-for-attendance",
  templateUrl: "./reports-analysis-for-attendance.component.html",
  styleUrls: ["./reports-analysis-for-attendance.component.scss"]
})
export class ReportsAnalysisForAttendanceComponent
  implements OnInit, OnDestroy {
  isDataReady: boolean = false;
  loading: boolean = false;
  isJsLoaded: boolean = false;
  meeting: Meeting;
  routeSubscription: Subscription;
  selectedPeriodType: ReportAnalysisPeriodType;
  expectedPeriodKeys: ObjectProperty[];
  analysisSummary: AttendanceReportsAnalysisSummary;
  analysisDetailsByCenters: AttendanceReportsAnalysisDetailsByCenter[] = [];

  selectedCenterForFiltering: CenterSearchResult;
  selectedCenterForFilteringSubscription: Subscription;

  /*monthsMapper: any[] = [
    { 1: "Jan" },
    { 2: "Feb" },
    { 3: "Mar" },
    { 4: "Apr" },
    { 5: "May" },
    { 6: "Jun" },
    { 7: "Jul" },
    { 8: "Aug" },
    { 9: "Sep" },
    { 10: "Oct" },
    { 11: "Nov" },
    { 12: "Dec" }
  ];*/

  dashboard: AnalysisDashboardItems = new AnalysisDashboardItems();

  public chartOptions: ChartOptions;
  public centersChartOptions: any;
  public chartColors: Array<any> = [];
  public chartColors2: any[] = [];
  public trendChartLabels: string[] = [];
  public centersChartLabels: string[] = [];
  public attendanceTrendChartData: any[] = [];
  public impactsTrendChartData: any[] = [];
  public centersImpactsChartData: any[] = [];
  public centersAttendanceChartData: any[] = [];
  public filter: ReportFilter = new ReportFilter();
  public centerTypesDrilldown: Lookup[] = [];

  public isTrendsChartReady: boolean = false;
  public isCentersDetailsChartReady: boolean = false;
  public centerDataViewMode: string = "Attendance";
  pagingCurrentPage: number = 1;
  pagingItemsPerPage: number = 30;

  constructor(
    private activeRoute: ActivatedRoute,
    private router: Router,
    private dynamicScriptLoader: DynamicJsScriptLoaderService,
    private reportingService: ReportingService
  ) {
    try {
      this.router.routeReuseStrategy.shouldReuseRoute = () => false;

      //const routeParams = this.activeRoute.snapshot.params;
      //this.meetingId = routeParams.id;

      //const t = this.router.getCurrentNavigation().extras.state;

      this.routeSubscription = this.router.events
        .pipe(
          filter(e => e instanceof NavigationEnd),
          map(() => this.router.getCurrentNavigation().extras.state)
        )
        .subscribe(response => {
          if (response && response.meeting) this.meeting = response.meeting;
        });

      //console.log(this.meetingId);
    } catch (e) {
      //console.log(e);
    }

    this.selectedCenterForFilteringSubscription = this.reportingService
      .GetCachedSelectedCenterForFiltering()
      .subscribe(center => {
        this.selectedCenterForFiltering = center;
      });

    this.configureCharts();
    //this.loadJsScripts();
  }

  private configureCharts() {
    /*this.chartOptions = {
      scaleShowVerticalLines: false,
      responsive: true,
      fill: false
    };
*/

    this.centersChartOptions = {
      scales: {
        yAxes: [
          {
            barPercentage: 0.5
          }
        ]
      },
      elements: {
        rectangle: {
          borderSkipped: "left"
        }
      }
    };

    this.chartOptions = {
      responsive: true,
      //scaleShowVerticalLines: false,
      //fill: false,
      // We use these empty structures as placeholders for dynamic theming.
      scales: { xAxes: [{}], yAxes: [{}] },
      plugins: {
        datalabels: {
          anchor: "end",
          align: "end"
        }
      }
    };

    this.chartColors = [
      {
        // dark grey
        backgroundColor: "rgba(77,83,96,0.2)",
        borderColor: "rgba(77,83,96,1)",
        pointBackgroundColor: "rgba(77,83,96,1)",
        pointBorderColor: "#fff",
        pointHoverBackgroundColor: "#fff",
        pointHoverBorderColor: "rgba(77,83,96,1)"
      },
      {
        // second color - red
        backgroundColor: "rgba(225,10,24,0.2)",
        borderColor: "rgba(225,10,24,0.2)",
        pointBackgroundColor: "rgba(225,10,24,0.2)",
        pointBorderColor: "#fff",
        pointHoverBackgroundColor: "#fff",
        pointHoverBorderColor: "rgba(225,10,24,0.2)"
      }
    ];

    this.chartColors2 =
      /*[
  {
    backgroundColor: ["#FF7360", "#6FC8CE", "#FAFFF2", "#FFFCC4", "#B9E8E0"]
  }
];*/
      [
        { backgroundColor: "#d13537" },
        { backgroundColor: "#b0o0b5" },
        { backgroundColor: "#coffee" },
        { backgroundColor: "#FFFCC4" },
        { backgroundColor: "#B9E8E0" }
      ];
  }

  private resetChartData(chartType: ReportAnalysisChartType) {
    if (chartType == ReportAnalysisChartType.Trend) {
      this.attendanceTrendChartData = [
        { data: [], label: "Adults Attendance" },
        { data: [], label: "Total Attendance" }
      ];

      this.impactsTrendChartData = [
        { data: [], label: "Total New Converts" },
        { data: [], label: "Total First Timers" },
        { data: [], label: "Total Testimonies", hidden: true }
      ];

      /*this.attendanceTrendChartData.forEach(element => {
        //element.data = [];
        element.data.length = 0;
      });

      this.impactsTrendChartData.forEach(element => {
        //element.data = [];
        element.data.length = 0;
      });*/

      this.trendChartLabels = [];
    } else if (chartType == ReportAnalysisChartType.CentersDetails) {
      this.centersAttendanceChartData = [
        { data: [], label: "Average Adults" },
        { data: [], label: "Average Attendance" }
      ];

      this.centersImpactsChartData = [
        { data: [], label: "Total New Converts" },
        { data: [], label: "Total First Timers" },
        { data: [], label: "Total Testimonies", hidden: true }
      ];

      /* this.centersAttendanceChartData.forEach(element => {
        element.data = [];
      });

      this.centersImpactsChartData.forEach(element => {
        element.data = [];
      });
      */

      this.centersChartLabels = [];
      this.analysisDetailsByCenters = [];
    }
  }

  ngOnInit() {
    // Just call your load scripts function with scripts you want to load
    if (this.meeting) {
      this.filter.meetingId = this.meeting.id;
      this.filter.meetingChurchSystemId = this.meeting.churchSystemId;
      this.filter.periodType = ReportAnalysisPeriodType.ThisMonth;
      this.resetChartData(ReportAnalysisChartType.Trend);
      this.loadData();
    }
  }

  private loadJsScripts() {
    // You can load multiple scripts by just providing the key as argument into load method of the service
    this.dynamicScriptLoader
      //.load("webdatarocks-toolbar", "webdatarocks", "webdatarocks-highcharts")
      .load("chartistjs")
      .then(data => {
        // Script Loaded Successfully
        this.isJsLoaded = true;
        //console.log("JS LOADED");
      })
      .catch(error => console.log(error));
  }

  private loadData() {
    //filter.periodType = AnalysisPeriodType.ThisYear;
    //filter.resultsGroupingType = ResultsGroupingType.InAMonth;
    //filter.startDate = null;
    //filter.endDate = null;
    //filter.previousDataStartDate = null;
    this.reportingService.reconfigureFilter(this.filter);
    this.loading = true;
    this.reportingService
      .getReportsAnalysisForAttendanceSummary(this.filter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((response: AttendanceReportsAnalysisSummary) => {
        // console.log(response);
        this.analysisSummary = response;
        this.expectedPeriodKeys = response.expectedPeriodKeys;
        this.centerTypesDrilldown = response.centerTypesDrillDown;
        //this.processAnalysisData(response.centersAttendanceReports);
        this.computeSummaryFigures();
        this.isCentersDetailsChartReady = false;
        this.resetChartData(ReportAnalysisChartType.CentersDetails);
        this.isDataReady = true;
      });
  }

  private computeSummaryFigures() {
    // sum of average of each centers

    let currentReports = _filter(this.analysisSummary.reports, function(
      o: AttendanceAnalysisReportItem
    ) {
      return o.dataPeriodType == ReportAnalysisDataStatus.Current;
    });

    let previousReports = _find(this.analysisSummary.reports, function(
      o: AttendanceAnalysisReportItem
    ) {
      return o.dataPeriodType == ReportAnalysisDataStatus.Previous;
    });

    //console.log(currentReports);

    const temp: AttendanceAnalysisReportItem = {
      males: 0,
      females: 0,
      children: 0,
      totalAdults: 0,
      totalAttendance: 0,
      newConverts: 0,
      firstTimers: 0,
      testimonies: 0,
      reportedCenters: 0,
      dataPeriodType: ReportAnalysisDataStatus.None
    };

    if (!currentReports || !currentReports.length) {
      const b = Object.assign({}, temp);
      b.dataPeriodType = ReportAnalysisDataStatus.Current;
      currentReports.push(b);
    }

    if (!previousReports) {
      const b = Object.assign({}, temp);
      b.dataPeriodType = ReportAnalysisDataStatus.Previous;
      previousReports = b;
    }

    const allMeetingCenters = this.analysisSummary.totalMeetingCenters;
    //get current data use that for the sums
    this.dashboard.males = sumBy(currentReports, p => p.males);

    this.dashboard.females = sumBy(currentReports, p => p.females);

    this.dashboard.children = sumBy(currentReports, p => p.children);

    this.dashboard.totalAdults.value = sumBy(
      currentReports,
      p => p.totalAdults
    );

    this.dashboard.totalAttendance.value = sumBy(
      currentReports,
      p => p.totalAttendance
    );

    this.dashboard.newConverts.value = sumBy(
      currentReports,
      p => p.newConverts
    );

    this.dashboard.firstTimers.value = sumBy(
      currentReports,
      p => p.firstTimers
    );

    this.dashboard.testimonies.value = sumBy(
      currentReports,
      p => p.testimonies
    );

    this.dashboard.totalAdults.percentage =
      ((this.dashboard.totalAdults.value - previousReports.totalAdults) /
        previousReports.totalAdults) *
      100;
    this.dashboard.totalAttendance.percentage =
      ((this.dashboard.totalAttendance.value -
        previousReports.totalAttendance) /
        (previousReports.totalAttendance || 1)) *
      100;
    this.dashboard.newConverts.percentage =
      ((this.dashboard.newConverts.value - previousReports.newConverts) /
        (previousReports.newConverts || 1)) *
      100;
    this.dashboard.firstTimers.percentage =
      ((this.dashboard.firstTimers.value - previousReports.firstTimers) /
        (previousReports.firstTimers || 1)) *
      100;
    this.dashboard.testimonies.percentage =
      ((this.dashboard.testimonies.value - previousReports.testimonies) /
        (previousReports.testimonies || 1)) *
      100;

    this.dashboard.totalMeetingCenters.value =
      allMeetingCenters.allMeetingCenters;
    this.dashboard.totalNewCenters.value = allMeetingCenters.newCenters;
    this.dashboard.totalLikelyInactiveCenters.value =
      allMeetingCenters.likelyInactiveCenters;

    this.dashboard.centersThatReported.value =
      allMeetingCenters.centersThatReported;

    this.dashboard.totalNewCenters.percentage =
      (this.dashboard.totalNewCenters.value /
        (this.dashboard.totalMeetingCenters.value || 1)) *
      100;

    this.dashboard.totalLikelyInactiveCenters.percentage =
      (this.dashboard.totalLikelyInactiveCenters.value /
        (this.dashboard.totalMeetingCenters.value || 1)) *
      100;

    this.dashboard.centersThatReported.percentage =
      (this.dashboard.centersThatReported.value /
        (this.dashboard.totalMeetingCenters.value || 1)) *
      100;

    //console.log(this.analysisData);
    this.prepareTrendCharts(currentReports);
  }

  private prepareTrendCharts(
    allCurrentReports: AttendanceAnalysisReportItem[]
  ) {
    this.resetChartData(ReportAnalysisChartType.Trend);

    this.expectedPeriodKeys.forEach(key => {
      const groupedData = _filter(allCurrentReports, function(
        item: AttendanceAnalysisReportItem
      ) {
        return (
          item[key.key] == key.value && item[key.parentKey] == key.parentValue
        );
      });

      //console.log(groupedData);
      //console.log(this.attendanceTrendChartData);

      if (groupedData && groupedData.length) {
        this.attendanceTrendChartData[0].data.push(
          sumBy(groupedData, item => item.totalAdults) || 0
        );

        this.attendanceTrendChartData[1].data.push(
          sumBy(groupedData, item => item.totalAttendance) || 0
        );

        this.impactsTrendChartData[0].data.push(
          sumBy(groupedData, item => item.newConverts) || 0
        );
        this.impactsTrendChartData[1].data.push(
          sumBy(groupedData, item => item.firstTimers) || 0
        );
        this.impactsTrendChartData[2].data.push(
          sumBy(groupedData, item => item.testimonies) || 0
        );
      } else {
        this.attendanceTrendChartData[0].data.push(0);
        this.attendanceTrendChartData[1].data.push(0);
        this.impactsTrendChartData[0].data.push(0);
        this.impactsTrendChartData[1].data.push(0);
        this.impactsTrendChartData[2].data.push(0);
      }

      this.trendChartLabels.push(this.reportingService.getChartKey(key));
    });

    //console.log(this.impactsSummaryChartData);

    /*this.expectedPeriodKeys.forEach(key => {
      this.trendChartLabels.push(this.reportingService.getChartKey(key));
    });*/

    // console.log(this.expectedPeriodKeys)
    // console.log(this.trendChartLabels)

    // console.log(this.attendanceTrendChartData);
    // console.log(this.impactsTrendChartData);

    this.isTrendsChartReady = true;
  }

  private prepareCentersDetailsCharts() {
    const reports: AttendanceReportsAnalysisDetailsByCenter[] = this
      .analysisDetailsByCenters;

    // console.log(reports);

    reports.forEach(center => {
      if (center.report) {
        this.centersAttendanceChartData[0].data.push(
          center.report.totalAdults || 0
        );

        this.centersAttendanceChartData[1].data.push(
          center.report.totalAttendance || 0
        );

        this.centersImpactsChartData[0].data.push(
          center.report.newConverts || 0
        );

        this.centersImpactsChartData[1].data.push(
          center.report.firstTimers || 0
        );

        this.centersImpactsChartData[2].data.push(
          center.report.testimonies || 0
        );
      } else {
        this.centersAttendanceChartData[0].data.push(0);
        this.centersAttendanceChartData[1].data.push(0);
        this.centersImpactsChartData[0].data.push(0);
        this.centersImpactsChartData[1].data.push(0);
        this.centersImpactsChartData[2].data.push(0);
      }

      this.centersChartLabels.push(center.centerName);
    });

    this.isCentersDetailsChartReady = true;
  }

  public onSelectPeriodType(selectedFilter: ReportFilter) {
    /*this.filter.periodType = selectedFilter.periodType;
    this.filter.startDate = selectedFilter.startDate;
    this.filter.endDate = selectedFilter.endDate;*/
    this.filter = selectedFilter;
    this.loadData();
  }

  onSelectCenterTypeDrillDown(centerTypeId: number) {
    // console.log(centerTypeId);

    if (centerTypeId) {
      this.filter.descendantsCenterTypeId = centerTypeId;
      this.getCentersAnalysisDetails();
    }
  }

  getCentersAnalysisDetails() {
    //this.filter.loadAllMeetingCenters = true; // default
    this.loading = true;
    this.reportingService
      .getReportsAnalysisForAttendanceDetailsByCenters(this.filter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.resetChartData(ReportAnalysisChartType.CentersDetails);
        this.analysisDetailsByCenters = response;
        this.prepareCentersDetailsCharts();
      });
  }

  public chartClicked(e: any): void {
    // https://github.com/valor-software/ng2-charts/issues/489

    if (e.active.length > 0) {
      const chart = e.active[0]._chart;
      const activePoints = chart.getElementAtEvent(e.event);
      if (activePoints.length > 0) {
        // get the internal index of slice in pie chart
        const clickedElementIndex = activePoints[0]._index;
        const label = chart.data.labels[clickedElementIndex];
        // get value by index
        const value = chart.data.datasets[0].data[clickedElementIndex];
        var theDrillThroughKey =
          chart.config.data.datakeys[activePoints[0]._index];

        //console.log(clickedElementIndex, label, value);
        //console.log("theDrillThroughKey", theDrillThroughKey);

        //PART 2
        var activePoint = chart.getElementAtEvent(e)[0]; // chart.getElementAtEvent(e.event)[0];
        var data = activePoint._chart.data;
        var datasetIndex = activePoint._datasetIndex;
        const label2 = data.datasets[datasetIndex].label;
        const value2 = data.datasets[datasetIndex].data[activePoint._index];

        //console.log(label2);
        //console.log(value2);
      }
    }
  }

  /* function clickHandler(evt) {
    var firstPoint = myChart.getElementAtEvent(evt)[0];

    if (firstPoint) {
        var label = myChart.data.labels[firstPoint._index];
        var value = myChart.data.datasets[firstPoint._datasetIndex].data[firstPoint._index];
    }
  }*/

  ngOnDestroy(): void {
    try {
      this.routeSubscription.unsubscribe();
      this.selectedCenterForFilteringSubscription.unsubscribe();
    } catch (e) {}
  }
}
