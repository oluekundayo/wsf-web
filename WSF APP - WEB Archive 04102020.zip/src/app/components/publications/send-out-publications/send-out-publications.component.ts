import { Component, OnInit, TemplateRef } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from "@angular/forms";
import { PositionLevel } from "../../../models/centers.models";
import { PublicationService } from "../../../services/components-services/publications.service";

import { PositionService } from "../../../services/components-services/positions.service";
import {
  PublicationCategory,
  PublicationAttachment,
  Publication
} from "../../../models/publications.models";
import { Observable } from "rxjs";
import { APIService } from "../../../services/api.service";
import {
  Lookup,
  ResponseModel,
  SimpleFilter,
  ReportAnalysisPeriodType,
  AppApprovalType,
  CRUD
} from "../../../models/utilities.models";
import { AngularEditorConfig } from "@kolkov/angular-editor";
import { CenterType } from "../../../models/setups.models";
import { finalize } from "rxjs/operators";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { ReportingService } from "../../../services/components-services/reporting.service";
import { UtilitiesService } from "../../../services/utils/utilities.service";
import { FileUploader } from "ng2-file-upload";

//const URL = 'https://evening-anchorage-3159.herokuapp.com/api/';
// https://www.devglan.com/angular/angular-multiple-file-upload

@Component({
  selector: "app-upload-new-materials",
  templateUrl: "./send-out-publications.component.html",
  styleUrls: ["./send-out-publications.component.css"]
})
export class SendOutPublicationsComponent implements OnInit {
  publicationCategories: Lookup[];
  positionLevels: PositionLevel[];
  loading: boolean = false;
  uploadForm: FormGroup;
  angularEditorConfig: AngularEditorConfig = {};
  showNewCategoryInput: boolean = false;
  bsModalRef: BsModalRef;
  searchFormGroup: FormGroup;
  filter: SimpleFilter;
  previousPublications: Publication[] = [];
  selectedPreviousPublication: Publication;
  crudAction: CRUD = CRUD.Create;

  //Pagination
  public pagingCurrentPage: number = 1;
  public pagingItemsPerPage: number = 5;

  public uploader: FileUploader = new FileUploader({
    isHTML5: true
  });

  constructor(
    private modalService: BsModalService,
    private api: APIService,
    private fb: FormBuilder,
    private publicationService: PublicationService,
    private positionService: PositionService,
    private sweetAlertService: SweetAlertService,
    private reportingService: ReportingService,
    private utilitiesService: UtilitiesService
  ) {
    this.filter = new SimpleFilter();
    this.uploader = new FileUploader(null);
  }

  public ngOnInit() {
    this.createFormControls();
    this.setAngularEditorConfig();

    /*this.uploader.onAfterAddingFile = file => {
      file.withCredentials = false;
    };

    this.uploader.onCompleteItem = (
      item: any,
      response: any,
      status: any,
      headers: any
    ) => {
      //  console.log('ImageUpload:uploaded:', item, status, response);
      this.item = item;
    };*/

    this.displayCategories();
    this.getPositionLevels();
  }

  createFormControls() {
    this.uploadForm = this.fb.group({
      id: [0],
      idKey: [null],
      categoryId: [null, Validators.required],
      subject: ["", Validators.required],
      message: [""],
      accessibleBy: [null, Validators.required],
      signedBy: ["", Validators.required],
      signedAt: [null, Validators.required],
      //publishAt: [null, Validators.required],
      removeAt: [null],
      documentsAttachedWithInputControl: [null, null],
      hasAttachments: [false],
      attachments: [null],
      newCategoryTemp: ""
    });

    this.reportingService.injectDatesIntoStatusReportsFilter(
      this.filter,
      ReportAnalysisPeriodType.ThisMonth
    );

    this.searchFormGroup = this.fb.group({
      endDate: [this.filter.endDate, Validators.required],
      startDate: [this.filter.startDate, Validators.required],
      statusFilter: [""]
    });
  }

  private setAngularEditorConfig() {
    this.angularEditorConfig = {
      editable: true,
      spellcheck: true,
      height: "20rem",
      minHeight: "10rem",
      placeholder: "Enter Message here...",
      translate: "no",
      //uploadUrl: 'v1/images', // if needed
      customClasses: [
        // optional
        {
          name: "quote",
          class: "quote"
        },
        {
          name: "redText",
          class: "redText"
        },
        {
          name: "titleText",
          class: "titleText",
          tag: "h1"
        }
      ]
    };
  }

  // function to get all publication categories
  displayCategories() {
    this.loading = true;
    this.publicationService
      .getPublicationCategories()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(
        categories => {
          //console.log(categories);
          this.publicationCategories = categories;
        },
        error => this.handleError(error)
      );
  }

  // function to get postion level
  getPositionLevels(): void {
    this.loading = true;
    this.positionService
      .getPositionLevels()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(
        levels => {
          //console.log(levels);
          this.positionLevels = levels;
        },
        error => this.handleError(error)
      );
  }

  uploadSubmit() {
    if (this.uploadForm.valid) {
      const formData = this.getFormData();

      if (formData) {
        this.sweetAlertService
          .showConfirm(
            this.crudAction == CRUD.Create
              ? "You are Sending out a new Publication"
              : "You are about to update a Publication"
          )
          .then(a => {
            if (a.value) {
              this.loading = true;
              this.publicationService
                .publish(formData)
                .pipe(finalize(() => (this.loading = false)))
                .subscribe((data: ResponseModel) => {
                  //console.log(data);
                  if (data.isOk) {
                    // console.log(data);
                    this.uploader.clearQueue();
                    this.uploadForm.reset();
                    this.sweetAlertService.showSuccess(data.message);
                  } else {
                    this.sweetAlertService.showMessage(data.message);
                  }
                });
            }
          });
      }
    }
  }

  private getFormData(): FormData {
    try {
      const hasAttachments = this.uploadForm.get("hasAttachments").value;

      if (
        hasAttachments &&
        (!this.uploader.queue || this.uploader.queue.length < 1)
      ) {
        this.sweetAlertService.showError(
          "No Attachments included. Please add files and try again."
        );
        return null;
      }

      let data = new FormData();
      for (let i = 0; i < this.uploader.queue.length; i++) {
        let fileItem = this.uploader.queue[i]._file;
        if (fileItem.size > 10000000) {
          this.sweetAlertService.showError(
            "Each File should be less than 10 MB of size."
          );
          return null;
        }
      }

      for (let j = 0; j < this.uploader.queue.length; j++) {
        let fileItem = this.uploader.queue[j]._file;
        /*
      https://stackoverflow.com/questions/12989442/uploading-multiple-files-using-formdata
      ...If you call data.append('file', file) multiple times your request will 
      contain an array of your files... Saved me hours of despair, especially 
      because I felt the name should be file[], but using just file and calling 
      multiple times worked, thanks!
      */
        data.append("files", fileItem);
        // console.log(fileItem);
      }

      data.append("crudAction", this.crudAction);

      const publication = new Publication();
      publication.idKey = this.uploadForm.get("idKey").value;
      publication.publicationCategoryId = this.uploadForm.get(
        "categoryId"
      ).value;
      publication.subject = this.uploadForm.get("subject").value;
      publication.message = this.uploadForm.get("message").value;
      //publication.publishAt = this.uploadForm.get("publishAt").value;
      publication.accessibleBy = this.uploadForm.get("accessibleBy").value;
      publication.removeAt = this.utilitiesService.createDateAsUTC(
        this.uploadForm.get("removeAt").value
      );
      publication.signedBy = this.uploadForm.get("signedBy").value;
      publication.signedAt = this.utilitiesService.createDateAsUTC(
        this.uploadForm.get("signedAt").value
      );
      publication.hasAttachments = hasAttachments;

      data.append("content", JSON.stringify(publication));

      //console.log(publication);
      //console.log(JSON.stringify(publication));

      /* data.append("subject", this.uploadForm.get("subject").value);
      data.append("message", this.uploadForm.get("message").value);
      data.append("publishAt", this.uploadForm.get("publishedAt").value);
      data.append("visibleTo", this.uploadForm.get("visibleTo").value);
      data.append("removeAt", this.uploadForm.get("removeAt").value);
      data.append("signedBy", this.uploadForm.get("signedBy").value);
      data.append("signedAt", this.uploadForm.get("signedAt").value);
*/
      return data;
    } catch (e) {
      console.error(e);
      return null;
    }
  }

  public saveNewCategory() {
    if (!this.uploadForm.value.newCategoryTemp) {
      return;
    }

    //console.log(_status);
    this.sweetAlertService
      .showConfirm("Save this New Publication Category")
      .then(response => {
        if (response.value) {
          this.loading = true;
          this.publicationService
            .saveNewCategory({
              id: 0,
              name: this.uploadForm.value.newCategoryTemp
            } as Lookup)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              this.sweetAlertService.showSuccess("Saved Successfully.");
              this.publicationCategories.push({
                id: response.data,
                name: this.uploadForm.value.newCategoryTemp
              } as Lookup);
              this.uploadForm.patchValue({ newCategoryTemp: "" });
            });
        }
      });
  }
  // handle error function
  handleError(error) {
    // console.log(error);
  }

  openModalToEdit(template: TemplateRef<any>) {
    this.bsModalRef = this.modalService.show(template, {
      ignoreBackdropClick: true,
      class: "modal-lg"
    });
  }

  public getPreviousPublications() {
    this.filter.startDate = this.searchFormGroup.value.startDate;
    this.filter.endDate = this.searchFormGroup.value.endDate;
    this.loading = true;
    this.publicationService
      .getPreviousPublications(this.filter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.previousPublications = response;
      });
  }

  closeModal() {
    this.bsModalRef.hide();
  }

  public patchForm(pub: Publication) {
    if (pub) {
      this.uploadForm.patchValue({
        idKey: pub.idKey,
        categoryId: pub.publicationCategoryId,
        subject: pub.subject,
        message: pub.message,
        accessibleBy: pub.accessibleBy,
        attachments: pub.attachments,
        signedBy: pub.signedBy,
        signedAt: new Date(pub.signedAt),
        //publishAt: pub.publishAt,
        removeAt: new Date(pub.removeAt),
        hasAttachments: pub.hasAttachments
      });
      this.selectedPreviousPublication = pub;
      this.crudAction = CRUD.Update;
      this.closeModal();
    }
  }

  public removePreviousAttachment(
    index: number,
    attachment: PublicationAttachment
  ) {
    this.sweetAlertService
      .showConfirm("Delete this Previous Attachment")
      .then(response => {
        if (response.value) {
          this.loading = true;
          this.publicationService
            .deletePreviousAttachment(attachment.id, attachment.fileName)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              this.sweetAlertService.showSuccess("Deleted Successfully.");
              this.selectedPreviousPublication.attachments.splice(index, 1);
            });
        }
      });
  }
}
