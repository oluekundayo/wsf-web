import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "../../services/guards/auth-guard.service";
import { RegisterNewConvertsComponent } from "./register-new-converts/register-new-converts.component";
import { ViewNewConvertsComponent } from "./view-new-converts/view-new-converts.component";

const routes: Routes = [
  {
    path: "register-new-converts",
    component: RegisterNewConvertsComponent,
    data: {
      title: "Register New Converts"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "contact-new-converts",
    component: ViewNewConvertsComponent,
    data: {
      title: "View New Converts List"
    },
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FollowUpRoutingModule {}
