import { Injectable } from "@angular/core";
// import * as FileSaver from "file-saver";
// import * as XLSXStyle from "xlsx-style";

import * as XLSX from "xlsx";
import { Observable, Subject } from "rxjs";

const EXCEL_TYPE =
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
const EXCEL_EXTENSION = ".xlsx";

import * as FileSaver from "file-saver";

import { HttpClient } from "@angular/common/http";

//https://stackoverflow.com/questions/52990621/angular-6-formatting-export-excel-sheet

@Injectable()
export class ExcelService {
  constructor(private $http: HttpClient) {}

  /*public exportAsExcelFile(json: any[], excelFileName: string): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    this.wrapAndCenterCell(worksheet.B2);
    const workbook: XLSX.WorkBook = {
      Sheets: { data: worksheet },
      SheetNames: ["data"]
    };
    // Use XLSXStyle instead of XLSX write function which property writes cell styles.
    const excelBuffer: any = XLSXStyle.write(workbook, {
      bookType: "xlsx",
      type: "buffer"
    });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }

  private wrapAndCenterCell(cell: XLSX.CellObject) {
    const wrapAndCenterCellStyle = {
      alignment: { wrapText: true, vertical: "center", horizontal: "center" }
    };
    this.setCellStyle(cell, wrapAndCenterCellStyle);
  }

  private setCellStyle(cell: XLSX.CellObject, style: {}) {
    cell.s = style;
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE
    });
    FileSaver.saveAs(
      data,
      fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
    );
  }*/
  /* ... (within the component class definition) ... */

  public GetAllSheetNames(target: DataTransfer): Observable<any> {
    const subject = new Subject<any>();

    let data: any;

    /* wire up file reader */
    const reader: FileReader = new FileReader();

    reader.onload = (e: any) => {
      /* read workbook */
      //const bstr: string = e.target.result;

      const array = new Uint8Array(reader.result as ArrayBuffer);

      //const wb: XLSX.WorkBook = XLSX.read(bstr, { type: "binary" });
      const wb: XLSX.WorkBook = XLSX.read(array, { type: "array" });

      //console.log(wb.SheetNames);

      subject.next(wb.SheetNames);
      subject.complete();
      //console.log(data);
    };

    reader.readAsArrayBuffer(target.files[0]);
    //console.log(data);

    return subject.asObservable();
  }

  public exportAsExcelFile(json: any[], excelFileName: string): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    const workbook: XLSX.WorkBook = {
      Sheets: { data: worksheet },
      SheetNames: ["data"]
    };
    const excelBuffer: any = XLSX.write(workbook, {
      bookType: "xlsx",
      type: "array"
    });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
    FileSaver.saveAs(
      data,
      fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
    );
  }

  public ReadExcelFile(
    target: DataTransfer,
    sheetName: string,
    skipFirstRow: boolean = false
  ): Observable<any> {
    const subject = new Subject<any>();
    let data: any;

    /* wire up file reader */
    const reader: FileReader = new FileReader();

    reader.onload = (e: any) => {
      /* read workbook */
      //const bstr: string = e.target.result;

      const array = new Uint8Array(reader.result as ArrayBuffer);

      //const wb: XLSX.WorkBook = XLSX.read(bstr, { type: "binary" });
      const wb: XLSX.WorkBook = XLSX.read(array, { type: "array" });

      //console.log(wb.SheetNames);

      /* grab first sheet */
      //const wsname: string = wb.SheetNames[0];
      const wsname = sheetName;

      //console.log(wsname);
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      if (skipFirstRow) {
        //github.com/SheetJs/js-xlsx/issues/482
        data = XLSX.utils.sheet_to_json(ws, { range: 1 });
      } else {
        data = XLSX.utils.sheet_to_json(ws); //, { header: 1 }
      }

      subject.next(data);
      subject.complete();
      //console.log(data);
    };

    reader.readAsArrayBuffer(target.files[0]);
    //console.log(data);

    return subject.asObservable();
  }

  // get the XLS file from the server based on the url you pass
  // this.$http.get(excelPath, { responseType: "arraybuffer" })
  //  https://stackoverflow.com/questions/35869668/how-to-parse-read-an-excel-file-xls-or-xlsx-in-angularjs-which-is-already-pre?rq=1

  public convertArrayBufferToJson(
    arrayBufferResponse,
    sheetIndex: number = 0,
    skipFirstRow: boolean = false
  ) {
    // response.data will have your xls file as an arraybuffer

    // then do as the other answers have suggested
    /* convert data to binary string */
    var data = new Uint8Array(arrayBufferResponse);
    var arr = new Array();
    for (var i = 0; i != data.length; ++i)
      arr[i] = String.fromCharCode(data[i]);

    var bstr = arr.join("");
    /* Call XLSX */
    var workbook = XLSX.read(bstr, { type: "binary" });
    /* DO SOMETHING WITH workbook HERE */
    var first_sheet_name = workbook.SheetNames[sheetIndex];
    /* Get worksheet */
    var worksheet = workbook.Sheets[first_sheet_name];

    let excelData: any;
    /* save data */
    if (skipFirstRow) {
      //github.com/SheetJs/js-xlsx/issues/482
      excelData = XLSX.utils.sheet_to_json(worksheet, { range: 1, raw: true });
    } else {
      excelData = XLSX.utils.sheet_to_json(worksheet, { raw: true }); //, { header: 1 }
    }

    return excelData;
  }

  public saveJsonObjectToFile(
    jsonObject: any,
    fileName: string = "JsonToFile"
  ) {
    const blob = new Blob([JSON.stringify(jsonObject)], {
      type: "application/json"
    });
    saveAs(blob, fileName + ".json");
  }

  public convertExcelToJson(excelPath: string) {
    // get the XLS file from the server based on the url you pass
    return this.$http.get(excelPath, { responseType: "arraybuffer" });
  }

  /* public exportAsExcelFile2(
    json: any[],
    excelFileName: string,
    headersArray: any[]
  ): void {
    //Excel Title, Header, Data
    const header = headersArray;
    const data = json;
    //Create workbook and worksheet
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet(excelFileName);
    //Add Header Row
    let headerRow = worksheet.addRow(header);
    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FFFFFF00" },
        bgColor: { argb: "FF0000FF" }
      };
      cell.border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" }
      };
    });
    // Add Data and Conditional Formatting
    data.forEach(element => {
      let eachRow = [];
      headersArray.forEach(headers => {
        eachRow.push(element[headers]);
      });
      if (element.isDeleted === "Y") {
        let deletedRow = worksheet.addRow(eachRow);
        deletedRow.eachCell((cell, number) => {
          cell.font = {
            name: "Calibri",
            family: 4,
            size: 11,
            bold: false,
            strike: true
          };
        });
      } else {
        worksheet.addRow(eachRow);
      }
    });
    worksheet.getColumn(3).width = 15;
    worksheet.getColumn(4).width = 20;
    worksheet.getColumn(5).width = 30;
    worksheet.getColumn(6).width = 30;
    worksheet.getColumn(7).width = 10;
    worksheet.addRow([]);
    //Generate Excel File with given name
    workbook.xlsx.writeBuffer().then(data => {
      let blob = new Blob([data], { type: EXCEL_TYPE });
      FileSaver.saveAs(
        blob,
        excelFileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
      );
    });
  }*/
}
