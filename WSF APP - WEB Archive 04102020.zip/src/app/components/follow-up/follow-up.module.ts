import { NgModule } from "@angular/core";
import { SharedModule } from "../../app.shared.module";
import { ViewNewConvertsComponent } from "./view-new-converts/view-new-converts.component";
import { FollowUpRoutingModule } from "./follow-up-routing.module";
import { RegisterNewConvertsComponent } from "./register-new-converts/register-new-converts.component";
import { ComposeSmsDialogComponent } from "../dialog/compose-sms-dialog/compose-sms-dialog.component";
import { CreateFollowupCenterMemberDialogComponent } from "../dialog/create-followup-center-member-dialog/create-followup-center-member-dialog.component";
import { ConvertStatusPipe } from "../../pipes/convert-status.pipe";
import { ChartsModule } from "ng2-charts";
import { NgxPrintModule } from "ngx-print";

@NgModule({
  imports: [SharedModule, FollowUpRoutingModule, ChartsModule, NgxPrintModule],
  declarations: [
    RegisterNewConvertsComponent,
    ViewNewConvertsComponent,
    ComposeSmsDialogComponent,
    CreateFollowupCenterMemberDialogComponent,
    ConvertStatusPipe
  ],
  entryComponents: [
    ComposeSmsDialogComponent,
    CreateFollowupCenterMemberDialogComponent
  ]
})
export class FollowUpModule {}
