import { Observable, of } from "rxjs";
import { Injectable } from "@angular/core";

import swal, {
  SweetAlertOptions,
  SweetAlertResult,
  SweetAlertCustomClass
} from "sweetalert2";

export const enum ConfirmAlertResult {
  OK = 1,
  CANCELLED = 2,
  PROCESSING = 3
}

//PLEASE DESTROY THE OBSERVABLES WHEN CALLING CONFIRM.. FROM HERE

@Injectable()
export class SweetAlertService {
  constructor() {}

  public showMessage(message: string, isHtml: boolean = false) {
    const _customClass: SweetAlertCustomClass = {
      confirmButton: "btn btn-fill btn-info"
    };

    const swalObject = {
      title: "Information!",
      animation: false,
      buttonsStyling: false,
      customClass: _customClass
    };

    if (isHtml) {
      swalObject["html"] = message;
    } else {
      swalObject["text"] = message;
    }

    swal.fire(swalObject); //.catch(swal.noop);
  }

  public showSuccess(message: string, isHtml: boolean = false) {
    const _customClass: SweetAlertCustomClass = {
      confirmButton: "btn btn-fill btn-info"
    };

    const swalObject: SweetAlertOptions = {
      title: "Success!",
      animation: false,
      buttonsStyling: false,
      customClass: _customClass,
      icon: "success"
    };

    if (isHtml) {
      swalObject["html"] = message;
    } else {
      swalObject["text"] = message;
    }

    swal.fire(swalObject); //.catch(swal.noop);
  }

  public showError(message: string, isHtml: boolean = false) {
    const _customClass: SweetAlertCustomClass = {
      confirmButton: "btn btn-fill btn-danger"
    };

    const swalObject: SweetAlertOptions = {
      title: "Oops!",
      animation: false,
      buttonsStyling: false,
      confirmButtonColor: "btn btn-fill btn-danger",
      customClass: _customClass,
      icon: "error"
    };

    if (isHtml) {
      swalObject["html"] = message;
    } else {
      swalObject["text"] = message;
    }

    swal.fire(swalObject); //.catch(swal.noop);
  }

  public showConfirm(
    message: string,
    isHtml: boolean = false
  ): Promise<SweetAlertResult> {
    const _customClass: SweetAlertCustomClass = {
      confirmButton: "btn btn-fill btn-warning btn-mr-5",
      cancelButton: "btn btn-fill btn-default"
    };

    const swalObject: SweetAlertOptions = {
      title: "Are you sure?",
      animation: false,
      text: message,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Continue",
      cancelButtonText: "No, Thanks",
      customClass: _customClass,
      buttonsStyling: false
    };

    if (isHtml) {
      swalObject["html"] = message;
    } else {
      swalObject["text"] = message;
    }

    return swal.fire(swalObject);
  }

  public showCustomConfirmOnSelectCenter(
    message: string
  ): Promise<SweetAlertResult> {
    const _customClass: SweetAlertCustomClass = {
      confirmButton: "btn btn-fill btn-warning btn-mr-5",
      cancelButton: "btn btn-fill btn-default"
    };

    const swalObject: SweetAlertOptions = {
      title: "Found the Center?",
      animation: false,
      text: message,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Found",
      cancelButtonText: "No, Drilldown Again",
      customClass: _customClass,
      buttonsStyling: false
    };

    swalObject["html"] = message;
    return swal.fire(swalObject);
  }

  public showConfirmUpdate(
    message: string,
    isHtml: boolean = false
  ): Promise<SweetAlertResult> {
    const _customClass: SweetAlertCustomClass = {
      confirmButton: "btn btn-fill btn-warning btn-mr-5",
      cancelButton: "btn btn-fill btn-default"
    };

    const swalObject: SweetAlertOptions = {
      title: "Are you sure?",
      animation: false,
      text: `Are you sure you want to update this ${message}?`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Update",
      cancelButtonText: "No, Thanks",
      customClass: _customClass,
      buttonsStyling: false
    };

    if (isHtml) {
      swalObject["html"] = message;
    } else {
      swalObject["text"] = message;
    }

    /* swal(swalObject).then(result => {
      if (result.value) {
        return of(ConfirmAlertResult.OK);
      } else {
        return of(ConfirmAlertResult.CANCELLED);
      }
    });*/

    return swal.fire(swalObject);
  }

  public showConfirmDelete(
    message: string,
    isHtml: boolean = false
  ): Promise<SweetAlertResult> {
    const _customClass: SweetAlertCustomClass = {
      confirmButton: "btn btn-fill btn-warning btn-mr-5",
      cancelButton: "btn btn-fill btn-default"
    };

    const swalObject: SweetAlertOptions = {
      title: "Are you sure?",
      animation: false,
      text: `Are you sure you want to delete this ${message}?`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Delete",
      cancelButtonText: "No, Thanks",
      customClass: _customClass,
      buttonsStyling: false
    };

    if (isHtml) {
      swalObject["html"] = message;
    } else {
      swalObject["text"] = message;
    }

    /*swal(swalObject).then(result => {
      if (result.value) {
        return of(ConfirmAlertResult.OK);
      } else {
        return of(ConfirmAlertResult.CANCELLED);
      }
    });*/

    //return of(ConfirmAlertResult.PROCESSING);

    return swal.fire(swalObject);
  }

  public showConfirmRedirect(
    message: string,
    isHtml: boolean = false
  ): Promise<SweetAlertResult> {
    const _customClass: SweetAlertCustomClass = {
      confirmButton: "btn btn-fill btn-warning btn-mr-5",
      cancelButton: "btn btn-fill btn-default"
    };

    const swalObject: SweetAlertOptions = {
      title: "Redirecting...",
      animation: false,
      text: message,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Redirect",
      cancelButtonText: "No, Stay on this Page",
      customClass: _customClass,
      buttonsStyling: false
    };

    if (isHtml) {
      swalObject["html"] = message;
    } else {
      swalObject["text"] = message;
    }

    return swal.fire(swalObject);

    //return of(ConfirmAlertResult.PROCESSING);
  }

  public showPrompt(
    message: string,
    inputPlaceholder: string = "",
    isHtml: boolean = false
  ): Promise<SweetAlertResult> {
    const _customClass: SweetAlertCustomClass = {
      confirmButton: "btn btn-fill btn-warning btn-mr-5",
      cancelButton: "btn btn-fill btn-default"
    };

    const swalObject: SweetAlertOptions = {
      title: "Are you sure?",
      animation: false,
      text: message,
      input: "textarea",
      inputPlaceholder: inputPlaceholder + "...",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, Continue",
      cancelButtonText: "No, Thanks",
      customClass: _customClass,
      buttonsStyling: false
    };
    if (isHtml) {
      swalObject["html"] = message;
    } else {
      swalObject["text"] = message;
    }

    /* swal(swalObject).then(result => {
      if (result.value) {
        return of(ConfirmAlertResult.OK);
      } else {
        return of(ConfirmAlertResult.CANCELLED);
      }
    });*/

    return swal.fire(swalObject);
  }
}
