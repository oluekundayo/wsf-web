import { Component, OnInit, ViewEncapsulation, OnDestroy } from "@angular/core";
import { FormBuilder, FormGroup, Validators, FormArray } from "@angular/forms";
import {
  SimpleAttendanceReport,
  MeetingReportToSubmit,
  SubmittedReportItem,
  ReportFilter,
  MeetingDashboardItem
} from "app/models/reporting.models";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { ActivatedRoute, Router, NavigationEnd } from "@angular/router";
import {
  ResponseModel,
  ReportAnalysisPeriodType,
  Lookup,
  ReportPageActionType
} from "../../../models/utilities.models";
import { finalize, filter, map } from "rxjs/operators";
import * as moment from "moment";
import { UtilitiesService } from "../../../services/utils/utilities.service";
import { ReportAttendanceDialogComponent } from "../../dialog/report-attendance-dialog/report-attendance-dialog.component";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { Meeting, MeetingSection } from "../../../models/meetings.models";
import { Subscription } from "rxjs";
import { ReportingService } from "../../../services/components-services/reporting.service";
import { includes, find } from "lodash";

@Component({
  selector: "app-attendance-report-edit",
  templateUrl: "./attendance-report-edit.component.html",
  styleUrls: ["./attendance-report-edit.component.scss"]
})
export class AttendanceReportEditComponent implements OnInit, OnDestroy {
  //meetingId: number = 0;
  simpleAttendanceReport: SimpleAttendanceReport;
  //isInEditMode: boolean = false;
  simpleReportForm: FormGroup;
  filterFormGroup: FormGroup;
  loading: boolean = false;
  submittedReports: SubmittedReportItem[] = [];
  reportsKeys: any;
  bsModalRef: BsModalRef;
  isInSubmitMode: boolean = true;
  reportsListTitle: string = "";
  meeting: MeetingDashboardItem;
  routeSubscription: Subscription;
  selectedMeetingSectionHasOfferings: boolean = false;
  offeringsFormGroup: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private reportingServce: ReportingService,
    private sweetAlertService: SweetAlertService,
    private activeRoute: ActivatedRoute,
    private utilitiesService: UtilitiesService,
    private modalService: BsModalService
  ) {
    this.offeringsFormGroup = formBuilder.group({});

    try {
      this.routeSubscription = this.router.events
        .pipe(
          filter(e => e instanceof NavigationEnd),
          map(() => this.router.getCurrentNavigation().extras.state)
        )
        .subscribe(response => {
          this.meeting = response.meeting;
        });
    } catch (e) {
      //console.log(e);
    }
  }

  ngOnInit() {
    /* try {
      const routeParams = this.activeRoute.snapshot.params;
      this.meetingId = routeParams.id;
    } catch (e) {}*/

    this.createForm();
    this.patchForm();
    this.onSelectMeetingSection();
  }

  public createForm() {
    //const defaultSectionId: number =  this.meeting.meetingSections.find();
    this.simpleReportForm = this.formBuilder.group({
      meetingId: [this.meeting.id],
      meetingDate: ["", Validators.required],
      males: [],
      females: [],
      children: [],
      totalAttendance: [0, Validators.required],
      totalAdults: [0],
      newConverts: [],
      firstTimers: [],
      testimonies: [],
      coordinatedBy: [""],
      meetingSectionId: [0, Validators.required]
    });

    this.filterFormGroup = this.formBuilder.group({
      meetingId: [this.meeting.id],
      startDate: [null, Validators.required],
      endDate: [null, Validators.required]
    });
  }

  private patchForm() {
    if (this.meeting && this.meeting.meetingSections) {
      {
        const defaultMeetingSectionId = find(
          this.meeting.meetingSections,
          (e: MeetingSection) => e.isDefault
        ).id;
        if (defaultMeetingSectionId) {
          this.simpleReportForm.patchValue({
            meetingSectionId: defaultMeetingSectionId
          });
        }
      }
    }
  }

  public onSelectMeetingSection() {
    if (this.meeting) {
      this.selectedMeetingSectionHasOfferings =
        this.meeting.hasOfferings &&
        includes(
          this.meeting.meetingSectionIdsHavingOfferings,
          parseInt(this.simpleReportForm.value.meetingSectionId)
        );
    }
  }

  submitSimpleReportForm() {
    // console.log(this.simpleReportForm.value);
    if (this.simpleReportForm.valid) {
      var _meeting: SimpleAttendanceReport = Object.assign(
        {},
        this.simpleReportForm.value
      );

      // console.log(_meeting.meetingDate);
      // _meeting.meetingDate = new Date(_meeting.meetingDate);
      // console.log(_meeting.meetingDate);

      //console.log(_meeting.meetingDate);
      //_meeting.meetingDate = new Date(_meeting.meetingDate);
      // console.log(_meeting.meetingDate);

      const report: MeetingReportToSubmit = {
        meetingId: this.meeting.id,
        meetingAttendance: _meeting,
        meetingParticipant: null,
        meetingReportType: this.meeting.meetingReportType,
        meetingDate: _meeting.meetingDate
      };

      this.sweetAlertService
        .showConfirm("Your Report will be submitted.")
        .then(a => {
          if (a.value) {
            this.loading = true;
            this.reportingServce
              .submitAttendanceReport(report)
              .pipe(finalize(() => (this.loading = false)))
              .subscribe((data: ResponseModel) => {
                this.sweetAlertService.showSuccess(data.message);

                //console.log(data);
                // this.submitted = false;
                this.simpleReportForm.reset();
              });
          }
        });
    }
  }

  onDatePickerValueChange($event) {}

  viewReportsList() {
    this.reportsListTitle = "This Month's Report(s)";
    this.reportsKeys = this.getReportsKeys();
    const filter = new ReportFilter();
    filter.periodType = ReportAnalysisPeriodType.ThisMonth;
    this.loadSubmittedReports(filter);
    this.isInSubmitMode = false;
  }

  private getReportsKeys() {
    return [
      { field: "males", label: "Males" },
      { field: "females", label: "Females" },
      {
        field: "children",
        label: "Children"
      },
      { field: "totalAdults", label: "Total Adults" },
      { field: "totalAttendance", label: "Total Attend." },
      { field: "newConverts", label: "New Birth" },
      { field: "firstTimers", label: "First Timers" },
      { field: "testimonies", label: "Testimonies" },
      { field: "meetingDate", label: "Meeting Date" },
      { field: "reportedAt", label: "Reported At" }
    ];
  }

  private loadSubmittedReports(filter: ReportFilter) {
    this.loading = true;
    this.reportingServce
      .getSubmittedReports(this.meeting.id, filter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.submittedReports = response;
      });
  }

  public filterSubmittedReports() {
    const filter = new ReportFilter();
    filter.periodType = ReportAnalysisPeriodType.Custom;

    filter.startDate = this.utilitiesService.createDateAsUTC(
      this.filterFormGroup.value.startDate
    );
    filter.endDate = this.utilitiesService.createDateAsUTC(
      this.filterFormGroup.value.endDate
    );

    this.reportsListTitle =
      filter.startDate + " - " + filter.endDate + " Report(s)";
    this.loadSubmittedReports(filter);
  }

  public openModalToEditReport(index: number) {
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      //class: "modal-sm",
      initialState: {
        report: this.submittedReports[index],
        meetingId: this.meeting.id,
        pageActionType: ReportPageActionType.Edit
      }
    };

    this.bsModalRef = this.modalService.show(
      ReportAttendanceDialogComponent,
      config
    );
    this.bsModalRef.content.action.subscribe((value: SubmittedReportItem) => {
      //console.log(value); // here you will get the value
      if (value) {
        this.submittedReports[index] = value as SubmittedReportItem;
      }
    });
  }

  navigateBackToReportsList() {
    this.router.navigate(["app/reports/menu/" + ReportPageActionType.Submit]);
  }

  ngOnDestroy(): void {
    this.routeSubscription.unsubscribe();
  }
}
