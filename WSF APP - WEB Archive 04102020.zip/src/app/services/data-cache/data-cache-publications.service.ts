import { Injectable } from "@angular/core";
import {
  PaginatedPublications,
  Publication
} from "../../models/publications.models";
import { find } from "lodash";
import { cloneDeep } from "lodash";
import {
  DataCacheMode,
  PaginatorFilter,
  PageDirection
} from "../../models/utilities.models";

@Injectable({
  providedIn: "root"
})
export class DataCachePublicationsService {
  PAGE_SIZE: number = 20;
  CURRENT_PAGE: number = 0;
  ITEMS_TO_SHOW: number = 5;

  private cachedBookmarkedPublications: PaginatedPublications;
  private cachedApprovedPublications: PaginatedPublications;
  private cachedDisapprovedPublications: PaginatedPublications;
  private cachedUnapprovedPublications: PaginatedPublications;
  private cachedNotVisiblePublications: PaginatedPublications;
  private cachedFilteredPublications: Publication[];
  private lastSelectedPageMode: DataCacheMode;

  constructor() {
    this.initCache();
    //console.log("AM CALLED AGAIN. WHY");
  }

  public getPubliciations(mode: DataCacheMode): Publication[] {
    let pub: Publication[];

    if (mode == DataCacheMode.Approved) {
      pub = this.cachedApprovedPublications.publications;
    } else if (mode == DataCacheMode.Unapproved) {
      pub = this.cachedUnapprovedPublications.publications;
    } else if (mode == DataCacheMode.Disapproved) {
      pub = this.cachedDisapprovedPublications.publications;
    } else if (mode == DataCacheMode.Bookmarked) {
      pub = this.cachedBookmarkedPublications.publications;
    } else if (mode == DataCacheMode.NotVisible) {
      pub = this.cachedNotVisiblePublications.publications;
    } else if (mode == DataCacheMode.Search) {
      pub = this.cachedFilteredPublications;
    }

    return pub;
  }

  public cachePublications(
    mode: DataCacheMode,
    response: PaginatedPublications
  ) {
    this.lastSelectedPageMode = mode;

    if (mode == DataCacheMode.Approved) {
      this.updateCache(this.cachedApprovedPublications, response);
    } else if (mode == DataCacheMode.Unapproved) {
      this.updateCache(this.cachedUnapprovedPublications, response);
    } else if (mode == DataCacheMode.Disapproved) {
      this.updateCache(this.cachedDisapprovedPublications, response);
    } else if (mode == DataCacheMode.Bookmarked) {
      this.updateCache(this.cachedBookmarkedPublications, response);
    } else if (mode == DataCacheMode.NotVisible) {
      this.updateCache(this.cachedNotVisiblePublications, response);
    }

    return response.paginator;
  }

  public cacheFilteredTestimonies(
    mode: DataCacheMode,
    response: Publication[]
  ) {
    this.lastSelectedPageMode = mode;
    this.cachedFilteredPublications = response;
  }

  private updateCache(
    cacheData: PaginatedPublications,
    newData: PaginatedPublications
  ) {
    cacheData.publications.push(...newData.publications);
    cacheData.paginator.lastMaxId = newData.paginator.lastMaxId;
    cacheData.paginator.lastMaxId = newData.paginator.lastMaxId;
    cacheData.paginator.lastMaxDate = newData.paginator.lastMaxDate;
    cacheData.paginator.lastMinDate = newData.paginator.lastMinDate;
    cacheData.paginator.totalItemsCount = newData.paginator.totalItemsCount;
  }

  private initCache() {
    const page: PaginatorFilter = new PaginatorFilter();
    page.pageSize = this.PAGE_SIZE;
    page.direction = PageDirection.NEXT;
    // page.currentPage = this.CURRENT_PAGE;
    //  page.noItemsToShow = this.ITEMS_TO_SHOW;

    const pub: PaginatedPublications = {
      paginator: Object.assign({}, page),
      publications: []
    };

    this.cachedApprovedPublications = cloneDeep(pub);
    this.cachedUnapprovedPublications = cloneDeep(pub);
    this.cachedDisapprovedPublications = cloneDeep(pub);
    this.cachedBookmarkedPublications = cloneDeep(pub);
    this.cachedNotVisiblePublications = cloneDeep(pub);
    this.cachedFilteredPublications = [];

    this.lastSelectedPageMode = DataCacheMode.Approved;
  }

  public getPaginator(mode: DataCacheMode): PaginatorFilter {
    if (mode == DataCacheMode.Approved) {
      return this.cachedApprovedPublications.paginator;
    } else if (mode == DataCacheMode.Unapproved) {
      return this.cachedUnapprovedPublications.paginator;
    } else if (mode == DataCacheMode.Disapproved) {
      return this.cachedDisapprovedPublications.paginator;
    } else if (mode == DataCacheMode.Bookmarked) {
      return this.cachedBookmarkedPublications.paginator;
    } else if (mode == DataCacheMode.NotVisible) {
      return this.cachedNotVisiblePublications.paginator;
    }
  }

  private resetPaginatorFilter(
    cacheData: PaginatorFilter,
    newData: PaginatorFilter
  ) {
    cacheData.lastMaxId = newData.lastMaxId;
    cacheData.lastMaxId = newData.lastMaxId;
    cacheData.lastMaxDate = newData.lastMaxDate;
    cacheData.lastMinDate = newData.lastMinDate;
    cacheData.totalItemsCount = newData.totalItemsCount;
  }

  public updatePaginator(mode: DataCacheMode, paginator: PaginatorFilter) {
    if (mode == DataCacheMode.Approved) {
      //this.cachedApprovedTestimonies.paginator = paginator;
      this.resetPaginatorFilter(
        this.cachedApprovedPublications.paginator,
        paginator
      );
    } else if (mode == DataCacheMode.Unapproved) {
      //this.cachedUnapprovedTestimonies.paginator = paginator;
      this.resetPaginatorFilter(
        this.cachedUnapprovedPublications.paginator,
        paginator
      );
    } else if (mode == DataCacheMode.Disapproved) {
      //this.cachedDisapprovedTestimonies.paginator = paginator;
      this.resetPaginatorFilter(
        this.cachedDisapprovedPublications.paginator,
        paginator
      );
    } else if (mode == DataCacheMode.Bookmarked) {
      // this.cachedBookmarkedTestimonies.paginator = paginator;
      this.resetPaginatorFilter(
        this.cachedBookmarkedPublications.paginator,
        paginator
      );
    } else if (mode == DataCacheMode.NotVisible) {
      //this.cachedNotVisibleTestimonies.paginator = paginator;
      this.resetPaginatorFilter(
        this.cachedNotVisiblePublications.paginator,
        paginator
      );
    }
  }

  public setLastSelectedPageMode(pageListMode: DataCacheMode) {
    this.lastSelectedPageMode = pageListMode;
  }

  public getLastSelectedPageMode(): DataCacheMode {
    return this.lastSelectedPageMode;
  }
}
