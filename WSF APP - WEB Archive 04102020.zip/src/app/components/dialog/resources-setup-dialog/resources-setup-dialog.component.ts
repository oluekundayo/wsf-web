import { finalize } from "rxjs/operators";
import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy
} from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import {
  Lookup,
  ResponseModel,
  AppResourceType,
  AppApprovalType
} from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators, FormArray } from "@angular/forms";

import { BsModalRef } from "ngx-bootstrap/modal";

import { filter } from "lodash";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { Resource } from "../../../models/resources.models";

@Component({
  selector: "app-resources-setup-dialog",
  templateUrl: "./resources-setup-dialog.component.html",
  styleUrls: ["./resources-setup-dialog.component.scss"]
})
export class ResourcesSetupDialogComponent implements OnInit, OnDestroy {
  loading = false;
  title: string;
  selectedResourceId: number = 0;
  selectedResourceCategoryId: number = 0;
  isNew: boolean = false;
  allAssignablePrivileges: string[] = [];
  @Output() action = new EventEmitter();
  resourceTypes: string[] = [];
  approvalTypes: string[] = [];

  formGroup: FormGroup;

  constructor(
    private api: APIService,
    public bsModalRef: BsModalRef,
    private fb: FormBuilder,
    private sweetAlertService: SweetAlertService
  ) {}

  ngOnInit() {
    //var valueArray = Object.keys(AppResourceType);
    //console.log(valueArray);

    this.resourceTypes = Object.keys(AppResourceType).map(function(type) {
      return AppResourceType[type];
    });

    this.approvalTypes = Object.keys(AppApprovalType).map(function(type) {
      return AppApprovalType[type];
    });

    // console.log(typeArray);

    this.formGroup = this.fb.group({
      id: [this.selectedResourceId],
      resourceCategoryId: [this.selectedResourceCategoryId],
      name: [this.title],
      description: [""],
      abbreviation: [""],
      urlOnWeb: [""],
      urlOnMobile: [""],
      postUrlOnWeb: [""],
      postUrlOnMobile: [""],
      getUrlOnWeb: [""],
      getUrlOnMobile: [""],
      icon: [""],
      cssClass: [""],
      itemOrder: [""],
      assignablePrivileges: [""],
      isVisible: [""],
      isAvailableOnWeb: [""],
      isAvailableOnMobile: [""],
      isShownOnQuickLinkPage: [""],
      resourceType: [""],
      approvalType: [""]
    });

    if (!this.isNew) {
      this.getResource();
    }
  }

  private getResource() {
    this.loading = true;
    this.api
      .get<Resource>(ApiRoutes.resources.resources, this.selectedResourceId)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((response: Resource) => {
        this.patchForm(response);
      });
  }

  private patchForm(r: Resource) {
    this.formGroup.patchValue({
      resourceCategoryId: r.resourceCategoryId,
      name: r.name,
      description: r.description,
      abbreviation: r.abbreviation,
      urlOnWeb: r.urlOnWeb,
      urlOnMobile: r.urlOnMobile,
      postUrlOnWeb: r.postUrlOnWeb,
      postUrlOnMobile: r.postUrlOnMobile,
      getUrlOnWeb: r.getUrlOnWeb,
      getUrlOnMobile: r.getUrlOnMobile,
      icon: r.icon,
      cssClass: r.cssClass,
      itemOrder: r.itemOrder,
      assignablePrivileges: r.assignablePrivileges,
      isVisible: r.isVisible,
      isAvailableOnWeb: r.isAvailableOnWeb,
      isAvailableOnMobile: r.isAvailableOnMobile,
      isShownOnQuickLinkPage: r.isShownOnQuickLinkPage,
      resourceType: r.resourceType,
      approvalType: r.approvalType
    });
  }

  public saveChanges() {
    this.sweetAlertService
      .showConfirm("Changes will be Committed")
      .then(response => {
        if (response.value) {
          var assigned = Object.assign({}, this.formGroup.value);

          //console.log(assigned);
          this.loading = true;

          if (this.isNew) {
            this.api
              .post<ResponseModel>(ApiRoutes.resources.resources, assigned)
              .pipe(finalize(() => (this.loading = false)))
              .subscribe((response: ResponseModel) => {
                this.sweetAlertService.showSuccess(response.message);
                assigned.id = response.data;
                this.action.emit(assigned);
                this.bsModalRef.hide();
              });
          } else {
            this.api
              .put<ResponseModel>(
                ApiRoutes.resources.resources,
                this.selectedResourceId,
                assigned
              )
              .pipe(finalize(() => (this.loading = false)))
              .subscribe((response: ResponseModel) => {
                this.sweetAlertService.showSuccess(response.message);
                this.action.emit(assigned);
                this.bsModalRef.hide();
              });
          }
        }
      });
  }

  ngOnDestroy(): void {}
}
