import { Component, OnInit } from "@angular/core";
import { Lookup } from "../../../models/utilities.models";
import {
  TransportationCentralLocation,
  TransportationLoadingHub,
  TransportationLoadingPoint
} from "../../../models/follow_up.models";
import { finalize } from "rxjs/operators";
import { FollowUpService } from "../../../services/components-services/followup.service";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { Observable } from "rxjs";

@Component({
  selector: "app-loading-bays",
  templateUrl: "./loading-bays.component.html",
  styleUrls: ["./loading-bays.component.scss"]
})
export class LoadingBaysComponent implements OnInit {
  public centralLocations$: Observable<TransportationCentralLocation[]>;
  public loading: boolean = false;
  public selectedLoadingPoint: TransportationLoadingPoint;
  public bsModalRef: BsModalRef;

  public myCenterLoadingPoints: TransportationLoadingPoint[] = [];
  public otherCenterLoadingPoints: TransportationLoadingPoint[] = [];

  constructor(
    private followUpService: FollowUpService,
    private modalService: BsModalService
  ) {}

  ngOnInit() {
    this.getLoadingPointsWithDepartures();
    this.getCentralLocations();
  }

  private getCentralLocations() {
    this.centralLocations$ = this.followUpService.getCentralLocations();
    /*.pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        console.log(response);
        this.centralLocations = response;
      });*/
  }

  public getLoadingPointsWithDepartures(centralLocationId: number = 0) {
    console.log(centralLocationId);

    this.loading = true;
    this.followUpService
      .getLoadingPointsInALocation(centralLocationId)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        console.log(response);
        if (centralLocationId == 0) this.myCenterLoadingPoints = response;
        else this.otherCenterLoadingPoints = response;
      });
  }

  /*public showLoadingBays(index: number, centralLocationId: number) {
    //console.log(centralLocationId);

    if (!this.centralLocations[index].loadingHubs) {
      this.followUpService
        .getLoadingHubsWithPoints(centralLocationId)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          //console.log(response);
          this.centralLocations[index].loadingHubs = response;
          //this.loadingHubs = response;
          //this.isListingPageMode = true;
        });
    }
  }*/

  public setSelectedLoadingPoint(
    template: any,
    point: TransportationLoadingPoint
  ) {
    this.selectedLoadingPoint = point;
    this.bsModalRef = this.modalService.show(template, {
      ignoreBackdropClick: true
    });
  }
}
