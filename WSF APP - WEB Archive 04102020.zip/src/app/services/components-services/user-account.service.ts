import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { catchError, map, tap } from "rxjs/operators";

import { APIService } from "../api.service";
import { PositionLevel, CenterProfile } from "../../models/centers.models";
import { ApiRoutes } from "../api.routes";
import {
  UserProfile,
  ChangePasswordDetails
} from "../../models/user_account.models";
import { ResponseModel } from "../../models/utilities.models";

@Injectable()
export class UserAccountService {
  constructor(private http: HttpClient, private apiservice: APIService) {}
  updateProfile(profile: UserProfile) {
    return this.apiservice.post<ResponseModel>(
      ApiRoutes.user_account.profile,
      profile
    );
  }

  updateUserProfileOnLogin(profile: UserProfile) {
    return this.apiservice.post<ResponseModel>(
      ApiRoutes.user_account.update_user_profile_on_login,
      profile
    );
  }

  getProfile() {
    return this.apiservice.getAll<UserProfile>(ApiRoutes.user_account.profile);
  }

  getProfileOnLogin() {
    return this.apiservice.getAll<UserProfile>(
      ApiRoutes.user_account.get_user_profile_on_login
    );
  }

  updateCenterProfile(profile: CenterProfile) {
    return this.apiservice.post<ResponseModel>(
      ApiRoutes.user_account.center_profile,
      profile
    );
  }

  getCenterProfile() {
    return this.apiservice.getAll<CenterProfile>(
      ApiRoutes.user_account.center_profile
    );
  }
}
