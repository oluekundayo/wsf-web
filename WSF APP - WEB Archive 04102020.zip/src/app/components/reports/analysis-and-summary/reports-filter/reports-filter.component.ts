import {
  Component,
  OnInit,
  TemplateRef,
  Output,
  EventEmitter,
  Input,
  OnDestroy
} from "@angular/core";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import {
  ReportFilter,
  MeetingDashboardItem
} from "../../../../models/reporting.models";
import {
  ReportAnalysisPeriodType,
  Privilege
} from "../../../../models/utilities.models";
import { FormBuilder, FormGroup } from "@angular/forms";
import { ReportingService } from "../../../../services/components-services/reporting.service";
import { ReportsMenuService } from "../../../../services/components-services/reports-menu.service";
import { Subscription } from "rxjs";
import { SweetAlertService } from "../../../../services/utils/sweet-alert.service";
import { finalize } from "rxjs/operators";
import {
  DrillDownCenters,
  CenterSearchResult
} from "../../../../models/centers.models";
import { filter } from "lodash";

@Component({
  selector: "app-reports-filter",
  templateUrl: "./reports-filter.component.html",
  styleUrls: ["./reports-filter.component.scss"]
})
export class ReportsFilterComponent implements OnInit, OnDestroy {
  bsModalRef: BsModalRef;
  meetings: MeetingDashboardItem[] = [];
  selectedMeeting: MeetingDashboardItem = null;
  formGroup: FormGroup;
  //subscription: Subscription;
  loading: boolean = false;
  //selectedPeriodType = ReportAnalysisPeriodType.ThisMonth;
  drilledDownCenters: DrillDownCenters[] = [];
  selectedCenter: CenterSearchResult;

  @Output() onSelectPeriodType: EventEmitter<ReportFilter> = new EventEmitter();
  @Input() reportFilter: ReportFilter;
  @Input() showAllMeetingsOption: boolean = false;
  @Input() showSwitchMeetingControl: boolean = false;
  @Output() onChangeMeetingType: EventEmitter<
    MeetingDashboardItem
  > = new EventEmitter();

  constructor(
    private modalService: BsModalService,
    private fb: FormBuilder,
    private reportMenuService: ReportsMenuService,
    private reportingService: ReportingService,
    private sweetAlertService: SweetAlertService
  ) {}

  ngOnInit() {
    this.drilledDownCenters = [];
    this.drillDownCenters({ centerId: 0 }, 0);

    if (!this.reportFilter) {
      this.reportFilter = new ReportFilter();
    }

    if (this.showSwitchMeetingControl) {
      this.getAssignedMeetings();
    }

    this.formGroup = this.fb.group({
      startDate: [this.reportFilter.startDate],
      endDate: [this.reportFilter.endDate],
      meetingSectionId: [this.reportFilter.meetingSectionId]
    });
    //console.log(this.reportFilter);
  }

  private getAssignedMeetings() {
    let defaultMeeting: MeetingDashboardItem;

    if (this.showAllMeetingsOption) {
      defaultMeeting = {
        id: 0,
        name: "All Meetings",
        selected: true
      } as MeetingDashboardItem;
    } else {
      defaultMeeting = {
        id: 0,
        name: "Switch to another Meeting"
      } as MeetingDashboardItem;
    }

    this.meetings.push(defaultMeeting);
    this.selectedMeeting = defaultMeeting;

    this.loading = true;
    this.reportingService
      .getAssignedMeetings(Privilege.CanView)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        // console.log(response);
        this.meetings.push(...response);
        this.reportMenuService.SetMeetingsMenu(this.meetings);
      });
  }

  public navigateToReportAnalysis() {
    if (!this.showAllMeetingsOption && this.selectedMeeting.id) {
      this.sweetAlertService
        .showConfirm(
          "Proceed on navigating to " + this.selectedMeeting.name + " Reports?"
        )
        .then(value => {
          if (value.value) {
            this.reportingService.navigateToReportAnalysis(
              this.selectedMeeting
            );
          }
        });
    } else if (this.showAllMeetingsOption) {
      //this.reportFilter.meetingId = this.selectedMeeting.id;
      this.onChangeMeetingType.emit(this.selectedMeeting);
    }
  }

  public periodTypeSelected(type: string) {
    //console.log(type);
    //const filter = new ReportFilter();
    this.reportFilter.periodType = (<any>ReportAnalysisPeriodType)[type];
    this.onSelectPeriodType.emit(this.reportFilter);
  }

  openModal(template: TemplateRef<any>) {
    this.bsModalRef = this.modalService.show(template, {
      ignoreBackdropClick: true
    });
    // (click)="periodTypeSelected('Custom')"
  }

  onCustomOk() {
    this.reportFilter.periodType = ReportAnalysisPeriodType.Custom;
    this.reportFilter.startDate = this.formGroup.value.startDate;
    this.reportFilter.endDate = this.formGroup.value.endDate;
    this.reportFilter.meetingSectionId = this.formGroup.value.meetingSectionId;
    this.onSelectPeriodType.emit(this.reportFilter);
    this.bsModalRef.hide();
  }

  public drillDownCenters(
    parentCenter: CenterSearchResult,
    selectedIndex: number
  ) {
    //console.log(parentCenter);

    if (parentCenter.centerId) {
      this.sweetAlertService
        .showCustomConfirmOnSelectCenter(
          `<strong>${
            parentCenter.displayAddress
          }</strong> will be used for filtering and only its Data will be shown."`
        )
        .then(response => {
          if (response.dismiss) {
            this.drilldownProcess(parentCenter, selectedIndex);
          } else if (response.value) {
            this.selectedCenter = parentCenter;
            this.reportFilter.userCenterId = parentCenter.centerId;
            this.reportFilter.userCenterTypeId = parentCenter.centerTypeId;
            this.reportingService.CacheSelectedCenterForFiltering(parentCenter);
          }
        });
    } else {
      this.drilldownProcess(parentCenter, selectedIndex);
    }
  }

  private drilldownProcess(
    parentCenter: CenterSearchResult,
    selectedIndex: number
  ) {
    if (parentCenter && parentCenter.centerId >= 0) {
      this.loading = true;
      this.reportingService
        .getCentersDrillDown(parentCenter.centerId)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          /* this.drilledDownCenters = filter(
        this.drilledDownCenters,
        (a, index) => {
          return index <= selectedIndex;
        }
      );*/

          this.drilledDownCenters.push({
            centerTypeId: response[0].centerTypeId,
            parentCenters: response
          } as DrillDownCenters);
        });
    }

    this.drilledDownCenters = filter(this.drilledDownCenters, (a, index) => {
      return index <= selectedIndex;
    });
  }

  public clearSelectedCenter() {
    this.selectedCenter = null;
    this.reportFilter.userCenterId = 0;
    this.reportFilter.userCenterTypeId = 0;
    this.reportingService.CacheSelectedCenterForFiltering(null);
  }

  public closeModal() {
    this.clearSelectedCenter();
    this.bsModalRef.hide();
  }

  ngOnDestroy(): void {
    //this.subscription.unsubscribe();
  }
}
