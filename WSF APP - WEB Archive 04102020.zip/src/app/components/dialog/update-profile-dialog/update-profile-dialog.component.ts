import {
  Component,
  OnInit,
  OnDestroy,
  EventEmitter,
  Output
} from "@angular/core";
import { finalize } from "rxjs/operators";
import { ResponseModel } from "../../../models/utilities.models";
import { Validators, FormBuilder, FormGroup } from "@angular/forms";
import { UserProfile } from "../../../models/user_account.models";
import { APIService } from "../../../services/api.service";
import { UserAccountService } from "../../../services/components-services/user-account.service";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { BsModalRef } from "ngx-bootstrap/modal";

@Component({
  selector: "app-update-profile-dialog",
  templateUrl: "./update-profile-dialog.component.html",
  styleUrls: ["./update-profile-dialog.component.scss"]
})
export class UpdateProfileDialogComponent implements OnInit, OnDestroy {
  loading = false;
  formGroup: FormGroup;
  genderList: string[] = [];
  ageGroupList: string[] = [];
  prefixList: string[] = [];
  myProfile: UserProfile;
  @Output() action = new EventEmitter<boolean>();

  constructor(
    private api: APIService,
    private fb: FormBuilder,
    private userAccountService: UserAccountService,
    private sweetAlertService: SweetAlertService,
    public bsModalRef: BsModalRef
  ) {}

  ngOnInit() {
    this.prefixList = ["Pastor", "Elder", "Dcn.", "Dcns.", "Bro.", "Sis."];
    this.genderList = ["Male", "Female"];
    this.ageGroupList = ["Adult", "Child"];
    this.createForm();
    this.loadProfile();
  }

  public loadProfile() {
    this.loading = true;
    this.userAccountService
      .getProfileOnLogin()
      //.pipe(finalize(() => (this.loading = false)))
      .subscribe(
        (response: UserProfile) => {
          if (response) {
            this.myProfile = response;
            //console.log(response);
            this.patchForm();
          }
          this.loading = false;
        },
        error => {
          this.loading = false;
        }
      );
  }

  private createForm() {
    this.formGroup = this.fb.group({
      prefix: [""],
      lastname: ["", Validators.required],
      firstname: ["", Validators.required],
      otherName: [""],
      gender: [""],
      address: [""],
      phone: [""],
      email: [""],
      centerAddress: ["", Validators.required],
      centeShortAddress: [""]
    });
  }

  private patchForm() {
    this.formGroup.patchValue({
      prefix: this.myProfile.prefix,
      lastname: this.myProfile.lastname,
      firstname: this.myProfile.firstname,
      otherName: this.myProfile.otherName,
      gender: this.myProfile.gender,
      address: this.myProfile.address,
      phone: this.myProfile.phone,
      email: this.myProfile.email,
      centerAddress: this.myProfile.centerAddress
        ? this.myProfile.centerAddress
        : null,
      centeShortAddress: this.myProfile.centeShortAddress
    });

    this.formGroup.controls["firstname"].markAsTouched();
    this.formGroup.controls["firstname"].markAsDirty();

    this.formGroup.controls["lastname"].markAsTouched();
    this.formGroup.controls["lastname"].markAsDirty();

    this.formGroup.controls["centerAddress"].markAsTouched();
    this.formGroup.controls["centerAddress"].markAsDirty();
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
  }

  public updateProfile() {
    if (this.formGroup.valid) {
      this.sweetAlertService
        .showConfirm("Your Profile will be updated.")
        .then(a => {
          if (a.value) {
            this.loading = true;
            this.userAccountService
              .updateUserProfileOnLogin(this.formGroup.value)
              .pipe(finalize(() => (this.loading = false)))
              .subscribe((response: ResponseModel) => {
                if (response.isOk) {
                  this.sweetAlertService.showSuccess(
                    "Your Profile has been successfully updated"
                  );
                  this.action.emit(true);
                  this.bsModalRef.hide();
                }
              });
          }
        });
    }
  }

  ngOnDestroy(): void {}
}
