import { MenuInfo } from "./menu.models";
import { Lookup } from "./utilities.models";
import { StarredTestimony } from "./testimonies.models";

export class LoginDetails {
  username: string;
  password: string;
  appVersion: string;
  appType: string;
}

export class LoggedInUser {
  displayname?: string;
  token: string;
  menu: MenuInfo[];
  isProfileUpdated: boolean;
}

export class ChangePasswordDetails {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export class NewUserDetails {
  username: string;
  password: string;
  accessCode: string;
  confirmPassword: string;
  registeredPhone: string;
  registeredEmail?: string;
  roleId?: number;
  roleCode?: string;
  parentCenterId?: number;
  newPhone?: string;
  newEmail?: string;
  userAlias?: string;
  positionHolderId?: string;
}

export class AccessCodeList {
  ministerLastname: string;
  ministerFirstname: string;
  ministerFullName: string;
  ministerPhone: string;
  ministerEmail: string;
  ministerAddress: string;
  ministerPositionLevel: string;
  ministerGender: string;
  centerAddress: string;
  centerShortAddress: string;
  centerId: number;
  accessCode: string;
  showAccessCode: boolean;
}

export class UserProfile {
  centerId: number;
  centerAddress: string;
  centeShortAddress: string;
  lastname: string;
  firstname: string;
  otherName: string;
  email: string;
  phone: string;
  prefix: string;
  address: string;
  accessCode: string;
  gender: number;
  maritalStatus: string;
  username: string;
  joinedChurchAt: Date;
  dateOfBirth: Date;
  occupation: string;
  otherProfessionalSkills: string;
  waterBaptismAt: Date;
  holyGhostBaptismAt: Date;
  churchDepartment: string;
  joinedChurchDepartmentAt: Date;
  positionLevel: string;
  highestQualification: string;
  highestQualificationAt: number;
  wofbiStatus: string;
  wofbiStatusAt: Date;
  weddingAnniversaryDate: Date;
  convertedAt: Date;
  isCentersContact: boolean;
}

export class SignUpUserProfiling {
  userRoles: Lookup[] = [];
  parentCenterType: Lookup;
  parentCenters: Lookup[] = [];
}

export class ForgotPasswordDetails {
  positionHolderId: string;
  registeredPhone: string;
  roleId: number;
  roleCode: string;
  newPassword: string;
  otp: string;
}

export class VerifyUserOtp {
  positionHolderId: string;
  registeredPhone: string;
  otp: string;
}

/*

export class UserAccountRoutes {
    static login = "login";
    
  }*/
