import { FileAttachment } from "./church_broadcasts.models";
import { AppResourceType } from "./utilities.models";

export class Resource {
  id: number;
  resourceCategoryId?: number;
  name?: string;
  description?: string;
  abbreviation?: string;
  urlOnWeb?: string;
  urlOnMobile?: string;
  postUrlOnWeb?: string;
  postUrlOnMobile?: string;
  getUrlOnWeb?: string;
  getUrlOnMobile?: string;
  icon?: string;
  cssClass?: string;
  itemOrder?: number;
  assignablePrivileges?: string[];
  isVisible?: boolean;
  isAvailableOnWeb?: boolean;
  isAvailableOnMobile?: boolean;
  isFreeForAll?: boolean;
  hasChildren?: boolean;
  isShownOnQuickLinkPage?: boolean;
  resourceType?: string;
  approvalType?: string;
  status?: string;
}

export class ResourceCategory {
  id: number;
  name: string;
  description: string;
  order: number;
  cssClass: string;
  createdAt: Date;
  createdBy: string;
}

export class AssignableResourceGroup {
  category: string;
  resources: AssignableResource[];
}

export class AssignableResource {
  id: number;
  categoryId: number;
  categoryName?: string;
  //type?: string;
  name: string;
  description?: string;
  itemOrder?: number;
  hasBeenAssignedToAnyId?: boolean;
  resourceType?: string;
  approvalType?: string;
  //assignedResources: AssignedResource[];
}

/*export class AssignedResource {
  resourceId: number;
  accessors: ResourceSharing[];
  createdAt: Date;
  createdBy: string;
}*/

/*export class ResourceAccessor {
  accessorId: number;
  accessorName: string;
  resourceId: number;
  resourceName: string;
  accessorType: string;
  privileges: string[];
}*/

export class ResourceAccessor {
  resourceSharingId: number;
  resourceType: AppResourceType;
  approvalType: string;
  positionLevelId: number;
  positionLevel: string;
  userId?: number;
  userName?: string;
  //resourceId: number;
  privileges: string[];
  //resourceName: string;
  //accessorType: string;
  //accessorName: string;
}

/*export class AssignablePrivilege {
  id: number;
  name: string;
  description: string;
}*/

/*
export class MyDownload {
  material_id: number;
  category: string;
  title: string;
  created_at: Date;
  created_by: string;
}

export class MyDownloadDetail {
  material_id: number;
  category: string;
  title: string;
  note: string;
  attachments: FileAttachment[];
  created_at: Date;
  created_by: string;
}

export class MyPost {
  post_id: number;
  category: string;
  title: string;
  created_at: Date;
  created_by: string;
}

export class MyPostDetail {
  post_id: number;
  category: string;
  title: string;
  message: string;
  attachments: FileAttachment[];
  created_at: Date;
  created_by: string;
}

export class MyApproval {
  approval_type: string;
  approval_type_id: number;
  reasons: string;
  url: string;
  created_at: Date;
  created_by: string;
}

export class MyReport {
  meeting_id: number;
  name: string;
  submit_url: string;
  view_url: string;
  owner: ReportResourceOwner;
}

export class ReportResourceOwner {
  can_submit: boolean;
  can_view: boolean;
  can_submit_and_view: boolean;
  holder_is_host_for_a_meeting: boolean;
  holder_is_a_hierarchy_for_reporter: boolean;
  holder_is_a_combined_meeting_reporter: boolean;
  is_assigned_to_a_center: boolean;
  is_assigned_to_a_position: boolean;
  created_at: Date;
  created_by: string;
}

export class AssignedReport {
  meeting_id: number;
  owners: ReportResourceOwner[];
}

export class AssignedApproval {
  approval_type_id: number;
  approval_type: string;
  // owners: ResourceOwner[];
  created_at: Date;
  created_by: string;
}
*/

/*
export class ResourcesRoutes {
  static myDownloads = "my_downloads";
  static myInbox = "my_inbox";
  static myReports = "my_reports";
  static myApprovals = "my_approvals";
  static resources = "resources";
  static resourcesCategories = "resources_categories";
  static assignResources = "assign_resources";
  static assignApprovals = "assign_approvals";
  static assignReports = "assign_reports";
}
*/
