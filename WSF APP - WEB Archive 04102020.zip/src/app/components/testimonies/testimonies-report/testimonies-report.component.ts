import { finalize } from "rxjs/operators";
import { Router, ActivatedRoute } from "@angular/router";
import { Component, OnInit, OnDestroy } from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import {
  PaginatorFilter,
  Lookup,
  ApiUrlParam,
  ResponseModel,
  ApprovalStatus,
  VisibilityStatus,
  ApprovalPost,
  SimpleFilter,
  StatusReport,
  PageDirection,
  ReportAnalysisPeriodType
} from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { ReportFilter } from "../../../models/reporting.models";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import { sumBy, filter } from "lodash";
import { TestimonyService } from "../../../services/components-services/testimony.service";
import {
  Testimony,
  TestimoniesStatusReport
} from "../../../models/testimonies.models";
//import * as moment from "moment";
import { UtilitiesService } from "../../../services/utils/utilities.service";
import { ReportingService } from "../../../services/components-services/reporting.service";
import { ChartOptions } from "chart.js";
import { ApproveTestimonyDialogComponent } from "../../dialog/approve-testimony-dialog/approve-testimony-dialog.component";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { TabDirective } from "ngx-bootstrap/tabs";

@Component({
  selector: "app-testimonies-report",
  templateUrl: "./testimonies-report.component.html",
  styleUrls: ["./testimonies-report.component.scss"]
})
export class TestimoniesReportComponent implements OnInit, OnDestroy {
  loading = false;
  unapprovedTestimonies: Testimony[] = [];
  unproofreadTestimonies: Testimony[] = [];
  testimoniesStatusReport: TestimoniesStatusReport;

  unapprovedPaginator: PaginatorFilter;
  unproofreadPaginator: PaginatorFilter;

  public chartColors: Array<any> = [];
  public chartOptionsForCounts: ChartOptions;
  public trendsChartOptions: ChartOptions;
  public trendsChartLabels: string[] = [];
  public countsChartLabels: string[] = [];
  public trendsChartData: any[] = [];
  public countsChartData: number[] = [];
  public isTrendsChartReady: boolean = false;
  bsModalRef: BsModalRef;
  PAGINATOR_PAGE_SIZE: number = 10;

  constructor(
    private testimonyService: TestimonyService,
    private sweetAlertService: SweetAlertService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private reportingService: ReportingService,
    private modalService: BsModalService
  ) {}

  ngOnInit() {
    this.initCharts();
    this.initPaginators();
    this.getTestimoniesReport();
    //this.getUnProofreadTestimonies();
    //this.getApprovedTestimonies();
  }

  private initPaginators() {
    this.unapprovedPaginator = new PaginatorFilter();
    this.unapprovedPaginator.pageSize = this.PAGINATOR_PAGE_SIZE;
    this.unapprovedPaginator.direction = PageDirection.NEXT;
    this.unapprovedPaginator.lastMaxId = 0;
    this.unapprovedPaginator.totalItemsCount = 0;
    this.unapprovedPaginator.currentPageStart = 0;
    this.unapprovedPaginator.currentPageEnd = 0;

    this.unproofreadPaginator = new PaginatorFilter();
    this.unproofreadPaginator.pageSize = this.PAGINATOR_PAGE_SIZE;
    this.unproofreadPaginator.direction = PageDirection.NEXT;
    this.unproofreadPaginator.lastMaxId = 0;
    this.unproofreadPaginator.totalItemsCount = 0;
    this.unproofreadPaginator.currentPageStart = 0;
    this.unproofreadPaginator.currentPageEnd = 0;
  }

  public getTestimoniesReport() {
    const filter = new SimpleFilter();
    filter.getOnlyDataTrend = false;
    this.reportingService.injectDatesIntoStatusReportsFilter(
      filter,
      ReportAnalysisPeriodType.ThisYear
    );
    this.testimonyService
      .getTestimoniesReport(filter)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.testimoniesStatusReport = response;
        this.prepareCharts(this.testimoniesStatusReport);
      });
  }

  private initCharts() {
    try {
      this.trendsChartData = [
        { data: [], label: "Shared" },
        { data: [], label: "Approved" },
        { data: [], label: "Disapproved" }
      ];

      this.countsChartLabels.push(...["Shared", "Approved", "Disapproved"]);

      this.trendsChartOptions = {
        responsive: true,
        //scaleShowVerticalLines: false,
        //fill: false,
        // We use these empty structures as placeholders for dynamic theming.
        scales: { xAxes: [{}], yAxes: [{}] },
        plugins: {
          datalabels: {
            anchor: "end",
            align: "end"
          }
        }
      };

      this.chartOptionsForCounts = {
        //rotation: 1 * Math.PI,
        //circumference: 1 * Math.PI,
        scales: { scaleLabel: { fontSize: 13 } },
        title: {
          display: true,
          text: "Status Summary"
        },
        plugins: {
          /*labels: {
          render: function(args) {
            const label = args.label,
              value = args.value;
            return label + ": " + value;
          }
          //arc: true
        }*/
          labels: [
            {
              render: "label",
              position: "outside"
            },
            {
              render: "value"
            }
          ],
          arc: true
        }
      };

      this.isTrendsChartReady = false;
    } catch (e) {}
  }

  private resetChartData() {
    this.trendsChartData = [
      { data: [], label: "Shared" },
      { data: [], label: "Approved" },
      { data: [], label: "Disapproved" }
    ];

    this.countsChartData = [];

    this.trendsChartLabels = [];
  }

  private prepareCharts(reports: TestimoniesStatusReport) {
    try {
      this.resetChartData();

      const allItems = sumBy(reports.trends, item => item.allItemsCount);
      const allApproved = sumBy(
        reports.trends,
        item => item.approvedItemsCount
      );
      const allDisapproved = sumBy(
        reports.trends,
        item => item.disapprovedItemsCount
      );

      this.countsChartData.push(...[allItems, allApproved, allDisapproved]);

      reports.expectedPeriodKeys.forEach(key => {
        const groupedData = filter(reports.trends, function(
          item: StatusReport
        ) {
          return (
            item[key.key] == key.value && item[key.parentKey] == key.parentValue
          );
        });
        //console.log(groupedData);
        this.trendsChartData[0].data.push(
          sumBy(groupedData, item => item.allItemsCount)
        );

        this.trendsChartData[1].data.push(
          sumBy(groupedData, item => item.approvedItemsCount)
        );

        this.trendsChartData[1].data.push(
          sumBy(groupedData, item => item.disapprovedItemsCount)
        );
      });

      reports.expectedPeriodKeys.forEach(key => {
        this.trendsChartLabels.push(this.reportingService.getChartKey(key));
      });
      this.isTrendsChartReady = true;
    } catch (e) {}
  }

  public openApprovalModal(
    testimony: Testimony,
    currentStatus: ApprovalStatus
  ) {
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      initialState: {
        selectedTestimonyIdInput: testimony.id,
        currentStatusInput: currentStatus
      },
      animate: true
    };

    this.bsModalRef = this.modalService.show(
      ApproveTestimonyDialogComponent,
      config
    );

    if (this.bsModalRef.content.action) {
      this.bsModalRef.content.action.subscribe(value => {
        //console.log(value); // here you will get the value
        if (value) {
          if (currentStatus == ApprovalStatus.Unapproved) {
            const index = this.unapprovedTestimonies.indexOf(testimony);
            if (index > -1) {
              this.unapprovedTestimonies.splice(index, 1);
            }
          } else if (currentStatus == ApprovalStatus.Unproofread) {
            const index = this.unproofreadTestimonies.indexOf(testimony);
            if (index > -1) {
              this.unproofreadTestimonies.splice(index, 1);
            }
          }
        }
      });
    }
  }

  onSelectPendingPublicationsTab(currentStatus: string, ev?: any) {
    //console.log(currentStatus);
    if (!(ev instanceof TabDirective)) return;

    if (
      currentStatus == ApprovalStatus.Unapproved &&
      !this.unapprovedTestimonies.length
    ) {
      this.getUnapprovedTestimonies();
    } else if (
      currentStatus == ApprovalStatus.Unproofread &&
      !this.unproofreadTestimonies.length
    ) {
      this.getUnproofreadTestimonies();
    }
  }

  getUnapprovedTestimonies() {
    this.testimonyService
      .getUnApprovedTestimonies(this.unapprovedPaginator)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.unapprovedPaginator = response.paginator;
        this.unapprovedTestimonies = response.testimonies;
      });
  }

  getUnproofreadTestimonies() {
    this.testimonyService
      .getUnProofReadTestimonies(this.unproofreadPaginator)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.unproofreadPaginator = response.paginator;
        this.unproofreadTestimonies = response.testimonies;
      });
  }

  loadNextItems(currentStatus: string) {
    if (currentStatus == ApprovalStatus.Unapproved) {
      this.loadNextUnapprovedItemsProcess();
    } else if (currentStatus == ApprovalStatus.Unproofread) {
      this.loadNextUnproofreadItemsProcess();
    }
  }

  loadPreviousItems(currentStatus: string) {
    if (currentStatus == ApprovalStatus.Unapproved) {
      this.loadPreviousUnapprovedItemsProcess();
    } else if (currentStatus == ApprovalStatus.Unproofread) {
      this.loadPreviousUnproofreadItemsProcess();
    }
  }

  loadNextUnapprovedItemsProcess() {
    // connect to api on first page to update data
    if (
      this.unapprovedPaginator.totalItemsCount >
      this.unapprovedTestimonies.length
    ) {
      this.loading = true;
      this.unapprovedPaginator.direction = PageDirection.NEXT;

      this.testimonyService
        .getApprovedTestimonies(this.unapprovedPaginator)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          //console.log(response);
          this.unapprovedTestimonies = response.testimonies;
          this.unapprovedPaginator = response.paginator;

          //console.log(this.pageListMode);
        });
    }
  }

  loadPreviousUnapprovedItemsProcess() //paginator: PaginatorFilter
  {
    // connect to api on first page to update data
    this.loading = true;
    this.unapprovedPaginator.direction = PageDirection.PREVIOUS;

    this.testimonyService
      .getApprovedTestimonies(this.unapprovedPaginator)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        let tempEnd = 0;
        this.unapprovedPaginator = response.paginator;
        this.unapprovedTestimonies = response.testimonies;
      });
  }

  loadNextUnproofreadItemsProcess() {
    // connect to api on first page to update data
    if (
      this.unproofreadPaginator.totalItemsCount >
      this.unproofreadTestimonies.length
    ) {
      this.loading = true;
      this.unproofreadPaginator.direction = PageDirection.NEXT;

      this.testimonyService
        .getApprovedTestimonies(this.unproofreadPaginator)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          //console.log(response);
          this.unproofreadTestimonies = response.testimonies;
          this.unproofreadPaginator = response.paginator;

          //console.log(this.pageListMode);
        });
    }
  }

  loadPreviousUnproofreadItemsProcess() //paginator: PaginatorFilter
  {
    // connect to api on first page to update data
    this.loading = true;
    this.unproofreadPaginator.direction = PageDirection.PREVIOUS;

    this.testimonyService
      .getUnProofReadTestimonies(this.unproofreadPaginator)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        let tempEnd = 0;
        this.unproofreadPaginator = response.paginator;
        this.unproofreadTestimonies = response.testimonies;
      });
  }

  ngOnDestroy(): void {}
}
