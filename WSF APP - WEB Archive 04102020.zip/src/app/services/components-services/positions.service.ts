import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { catchError, map, tap } from "rxjs/operators";

import { APIService } from "../api.service";
import { PositionLevel } from "../../models/centers.models";
import { ApiRoutes } from "../api.routes";

@Injectable()
export class PositionService {
  //private url = "church_setup/position_levels/lookup";
  constructor(private http: HttpClient, private apiservice: APIService) {}
  getPositionLevels() {
    return this.apiservice.getAll<PositionLevel[]>(
      ApiRoutes.position_levels.position_levels
    );
  }
}
