import { Component, OnInit, OnDestroy } from "@angular/core";
import { Router } from "@angular/router";

import {
  FormBuilder,
  Validators,
  FormGroup,
  FormControl
} from "@angular/forms";

import { Observable, Subscription } from "rxjs";
import { environment } from "environments/environment";
import { APIService } from "../../services/api.service";
import { AuthService } from "../../services/auth.service";
import { ApiRoutes } from "../../services/api.routes";
import {
  LoginDetails,
  LoggedInUser,
  NewUserDetails,
  SignUpUserProfiling,
  ForgotPasswordDetails,
  VerifyUserOtp
} from "../../models/user_account.models";
import { SweetAlertArrayOptions } from "sweetalert2";
import { SweetAlertService } from "../../services/utils/sweet-alert.service";
import { finalize, timeout } from "rxjs/operators";
import { LoginService } from "../../services/components-services/login.service";
import { ResponseModel } from "../../models/utilities.models";

@Component({
  selector: "app-forgot-password",
  templateUrl: "./forgot-password.component.html",
  styleUrls: ["./forgot-password.component.scss"]
})
export class ForgotPasswordComponent implements OnInit {
  test: Date = new Date();
  //type: FormGroup;
  appName: string = "WSF Portal";
  formGroup: FormGroup;
  loading: boolean = false;
  signUpProfiling: SignUpUserProfiling;
  //isVerficationCodeValid: boolean = false;
  actionStep: number = 1;
  requiresRoleCode: boolean = false;
  positionHolderId: string = "";

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private loginService: LoginService,
    private sweetAlertService: SweetAlertService
  ) {
    this.createForm();
  }

  ngOnInit() {
    this.getSignUpProfiling();

    //this.checkFullPageBackgroundImage();

    /*setTimeout(function() {
      try {
        // after 1000 ms we add the class animated to the login/register card
        $(".card").removeClass("card-hidden");
      } catch (e) {}
    }, 700);*/
  }

  private createForm() {
    this.formGroup = this.fb.group({
      roleId: [null, Validators.required],
      roleCode: [""],
      password: [""],
      otp: [null],
      confirmPassword: [""],
      registeredPhone: [""]
    });
  }

  private getSignUpProfiling() {
    this.loading = true;
    this.loginService
      .signUpProfiling()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        if (response) {
          this.signUpProfiling = response;
          this.signUpProfiling.userRoles.push({ id: 0, name: "Others" });
        }
      });
  }

  public onSelectRole(roleId: number) {
    if (roleId == 0) {
      this.requiresRoleCode = true;
    } else if (roleId > 0) {
      this.requiresRoleCode = false;
    } else {
      this.requiresRoleCode = false;
    }
  }

  public validateUserProfile() {
    const user = new ForgotPasswordDetails();
    user.registeredPhone = this.formGroup.value.registeredPhone;
    user.roleId = this.formGroup.value.roleId;
    user.roleCode = this.formGroup.value.roleCode;

    let error = "";
    if (user.roleId == 0 && !user.roleCode) {
      error += "Your Role Code is Required. <br/>";
    }

    if (!user.registeredPhone) {
      error += "Your Registered Phone Contact is Required. <br/";
    }

    if (error) {
      this.sweetAlertService.showError(error, true);
      return;
    }

    this.loading = true;
    this.loginService
      .validateUserProfile(user)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((response: ResponseModel) => {
        this.positionHolderId = response.data;
        this.actionStep = 2;
      });
  }

  public verifyOtp() {
    const user = new VerifyUserOtp();
    user.otp = this.formGroup.value.otp;
    user.positionHolderId = this.positionHolderId;

    let error = "";
    if (!user.otp) {
      error += "The Verification Code sent to your phone is Required. <br/>";
    }

    if (error) {
      this.sweetAlertService.showError(error, true);
      return;
    }

    this.loading = true;
    this.loginService
      .verifyOtpForForgotPassword(user)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((response: ResponseModel) => {
        this.actionStep = 3;
      });
  }

  public resetPassword() {
    const user = new ForgotPasswordDetails();
    user.positionHolderId = this.positionHolderId;
    user.newPassword = this.formGroup.value.password;

    const res = this.validateUserAccountInputs(
      this.formGroup.value.password,
      this.formGroup.value.confirmPassword
    );

    if (!res.isOk) {
      this.sweetAlertService.showError(res.error, true);
      return;
    }

    this.sweetAlertService
      .showConfirm("Your Password will be reset")
      .then(response => {
        if (response.value) {
          this.loading = true;
          this.loginService
            .resetPassword(user)
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              this.sweetAlertService.showSuccess(response.message);
              this.router.navigate(["auth/user/login"]);
            });
        }
      });
  }

  private validateUserAccountInputs(
    newPassword: string,
    confirmPassword: string
  ): ResponseModel {
    const response = new ResponseModel();

    response.isOk = true;
    response.error = "";

    if (!newPassword || newPassword.length < 4) {
      response.error +=
        "New Password is required and must be of 4 Characters minimum. <br/><br/>";
      response.isOk = false;
    }

    if (newPassword != confirmPassword) {
      response.error += "New Password and Confirm Password must be thesame. ";
      response.isOk = false;
    }

    return response;
  }
}
