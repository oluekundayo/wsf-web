import { NgModule } from "@angular/core";
import { SharedModule } from "../../app.shared.module";
import { ReportingRoutingModule } from "./reporting-routing.module";
//import { ConvenantHourOfPrayersComponent } from "./convenenant-hour-of-prayers/convenant-hour-of-prayers.component";
//import { WaterBaptismComponent } from "./water-baptism/water-baptism.component";
import { ApprovalForCombinedMeetingsComponent } from "./approval-for-combined-meetings/approval-for-combined-meetings.component";
import { ReportsMenuComponent } from "./reports-menu/reports-menu.component";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";
import { PopoverModule } from "ngx-bootstrap/popover";
import { ProgressbarModule } from "ngx-bootstrap/progressbar";
import { ViewSubmittedReportsComponent } from "./view-submitted-reports/view-submitted-reports.component";
import { MarkAttendanceDialogComponent } from "../dialog/mark-attendance-dialog/mark-attendance-dialog.component";
import { ReportsAnalysisForAttendanceComponent } from "./analysis-and-summary/reports-analysis-for-attendance/reports-analysis-for-attendance.component";
import { ChartsModule, BaseChartDirective } from "ng2-charts";
import { ReportAttendanceDialogComponent } from "../dialog/report-attendance-dialog/report-attendance-dialog.component";
import { AttendanceReportComponent } from "./attendance-report/attendance-report.component";
import { SingleParticipationReportComponent } from "./single-participation-report/single-participation-report.component";
import { MultipleParticipationsReportComponent } from "./multiple-participations-report/multiple-participations-report.component";
import { ReportsAnalysisForMultipleParticipationsComponent } from "./analysis-and-summary/reports-analysis-for-multiple-participations/reports-analysis-for-multiple-participations.component";
import { NgxPrintModule } from "ngx-print";
import { CreateMeetingParticipantDialogComponent } from "../dialog/create-meeting-participant-dialog/create-meeting-participant-dialog.component";
import { ReportsAnalysisOnFinancialInflowComponent } from "./analysis-and-summary/reports-analysis-on-financial-inflow/reports-analysis-on-financial-inflow.component";
import { SubmitOfferingsComponent } from "./submit-offerings/submit-offerings.component";
import { TabsModule } from "ngx-bootstrap/tabs";
import { AttendanceReportEditComponent } from "./attendance-report-edit/attendance-report-edit.component";
import { DelegatedAttendanceReportComponent } from "./delegated-attendance-report/delegated-attendance-report.component";

@NgModule({
  imports: [
    SharedModule,
    ReportingRoutingModule,
    ChartsModule,
    ProgressbarModule.forRoot(),
    NgxPrintModule,
    TabsModule.forRoot()
  ],
  declarations: [
    AttendanceReportComponent,
    //ConvenantHourOfPrayersComponent,
    MultipleParticipationsReportComponent,
    SingleParticipationReportComponent,
    //WaterBaptismComponent,
    ApprovalForCombinedMeetingsComponent,
    ReportsMenuComponent,
    CreateMeetingParticipantDialogComponent,
    ViewSubmittedReportsComponent,
    MarkAttendanceDialogComponent,
    ReportsAnalysisForAttendanceComponent,
    ReportsAnalysisForMultipleParticipationsComponent,
    ReportAttendanceDialogComponent,
    ReportsAnalysisOnFinancialInflowComponent,
    SubmitOfferingsComponent,
    AttendanceReportEditComponent,
    DelegatedAttendanceReportComponent
  ],
  entryComponents: [
    CreateMeetingParticipantDialogComponent,
    MarkAttendanceDialogComponent,
    ReportAttendanceDialogComponent
  ]
  //entryComponents: [ModalOperationalDivisionsComponent]
})
export class ReportingModule {
  constructor() {}
}
