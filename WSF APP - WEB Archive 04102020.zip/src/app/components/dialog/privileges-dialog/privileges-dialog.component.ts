import { finalize } from "rxjs/operators";
import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  OnDestroy
} from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import {
  Lookup,
  ApiUrlParam,
  ResponseModel,
  AppResourceType
} from "../../../models/utilities.models";
import { FormBuilder, FormGroup, Validators, FormArray } from "@angular/forms";
import { CenterType, PositionLevel } from "../../../models/centers.models";
import { BsModalRef } from "ngx-bootstrap/modal";
import {
  AssignableResource,
  ResourceAccessor
} from "../../../models/resources.models";
import { filter } from "lodash";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";

@Component({
  selector: "app-privileges-dialog",
  templateUrl: "./privileges-dialog.component.html",
  styleUrls: ["./privileges-dialog.component.scss"]
})
export class PrivilegesDialogComponent implements OnInit, OnDestroy {
  loading = false;
  title: string;
  selectedResourceId: number;
  //selectedPositionLevels: PositionLevel[] = [];
  //selectedPositionLevel: PositionLevel;
  //allAssignablePositionLevels: PositionLevel[] = [];
  //assignedResourceAccessors: ResourceAccessor[] = [];
  allAssignablePrivileges: string[] = [];
  appResourceType: AppResourceType;
  appApprovalType: string;
  @Output() action = new EventEmitter();
  showRoles: boolean = false;
  addMoreRole: boolean = false;

  formGroup: FormGroup;
  accessorsArray: FormArray;

  resourceAccessors: ResourceAccessor[] = [];

  constructor(
    private api: APIService,
    public bsModalRef: BsModalRef,
    private fb: FormBuilder,
    private sweetAlertService: SweetAlertService
  ) {
    this.formGroup = fb.group({
      accessors: fb.array([])
    });

    this.accessorsArray = this.formGroup.get("accessors") as FormArray;
  }

  ngOnInit() {
    this.loadAllPositionLevelsWithReferenceToAssignedPrivileges();
  }

  private addMoreRolesToResource() {
    this.addMoreRole = true;
  }

  public saveResourceAssignedAccessors() {
    this.sweetAlertService
      .showConfirm("Changes will be Committed")
      .then(response => {
        if (response.value) {
          const accessors = this.formGroup.value.accessors;
          var assigned = filter(accessors, (a: ResourceAccessor) => {
            a.resourceType = this.appResourceType;
            a.approvalType = this.appApprovalType;
            return a.privileges && a.privileges.length > 0;
          });

          //console.log(assigned);

          this.loading = true;
          this.api
            .put<ResponseModel>(
              ApiRoutes.resources.resource_sharing,
              this.selectedResourceId,
              assigned
            )
            .pipe(finalize(() => (this.loading = false)))
            .subscribe((response: ResponseModel) => {
              this.sweetAlertService.showSuccess(response.message);
              this.action.emit(
                assigned && assigned.length ? "hasAssignedId" : null
              );
              this.bsModalRef.hide();
            });
        }
      });
  }

  addItem(accessor: ResourceAccessor): void {
    const group = this.fb.group({
      positionLevelId: [accessor.positionLevelId],
      positionLevel: [accessor.positionLevel],
      resourceId: this.selectedResourceId,
      //resourceName: accessor.resourceName,
      //accessorType: accessor.accessorType,
      privileges: [accessor.privileges]
    });
    this.accessorsArray.push(group);
  }

  private loadAllPositionLevelsWithReferenceToAssignedPrivileges() {
    // this.loading = true;
    this.api
      .getAll<ResourceAccessor[]>(
        ApiRoutes.resources
          .resources_sharing_get_all_position_levels_with_assigned_privileges_to_a_resource +
          "/" +
          this.selectedResourceId +
          "/" +
          this.appResourceType
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);

        response.forEach(accessor => {
          this.addItem(accessor);
        });

        this.resourceAccessors = response;

        // console.log(this.formGroup.value);
      });
  }

  ngOnDestroy(): void {}
}
