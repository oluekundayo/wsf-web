import {
  Contact,
  CenterMemberShipStatus,
  Lookup,
  CenterMemberConversionStatus
} from "./utilities.models";
import { ResourceAccessor } from "./resources.models";
import {
  MeetingParticipantGetModel,
  MeetingAttendedByNewCenterMember
} from "./reporting.models";
import { LookupViewModel } from "../../../models/wsftypes";
import { ChurchSystem } from "./setups.models";

export class CenterType {
  id: number;
  name: string;
  description: string;
  churchId: number;
  churchStructuralDivisionId: number;
  parentCenterTypeId: number;
  includeInFamilyTreeName: boolean;
  centersNamePrefix: string;
  centersAliasPrefix: string;
  orderBy: number;
  createdAt: Date;
  createdBy: string;
  positionLevels: PositionLevel[];
  churchSystemsIds: number[];
  churchSystems: ChurchSystem[];
}

export class CenterContact {
  ministerLastname?: string;
  ministerfirstname?: string;
  ministerFullName: string;
  ministerPhone?: string;
  ministerEmail?: string;
  ministerAddress?: string;
  ministerGender?: string;
  centerAddress: string;
  centerId: number;
}

export class CenterTypesPerSystem {
  centerTypeId: number;
  centerType: string;
  allCentersCount: number;
  itemOrder: number;
  systemsCenters: CentersPerSystem[];
}

export class CentersPerSystem {
  churchSystemId: number;
  churchSystem: string;
  centersCount: number;
}

export class CenterDescendantsPerChurchSystem {
  systems: Lookup[];
  descendantsTypeCountsPerSystem: CenterTypesPerSystem[];
}

export class CenterSearchParams {
  centerTypeId: number = 0;
  churchSystemId: number = 0;
  searchByAddress: string = "";
  searchByMinister: string = "";
  searchByAddressOrMinister: string = "";
  limitSearchToDescendants: boolean = true;
  limitSearchToACenterType: boolean = false;
  limitSearchToAChurchSystem: boolean = false;
}

export class CenterSearchResult {
  centerId: number;
  centerTypeId?: number;
  number?: number;
  displayAddress?: string;
  centerAlias?: string;
  parentCenter?: string;
  parentCenterId?: number;
  churchSystemsIds?: number[];
  positionHolderId?: number;
  ministerEmail?: string;
  ministerFullName?: string;
  ministerAddress?: string;
  ministerMaritalStatus?: string;
  ministerPhone?: string;
  ministerPrefix?: string;
  ministerGender?: string;
  positionLevelId?: number;
}

export class Center {
  id: number;
  parentId: number;
  centerTypeId: number;
  number?: number;
  name: string;
  chartLabel: string;
  address: string; //E.g P12D123
  shortNameFromAddress: string;
  centerAlias: string;
  useSystemCenterNumbering: boolean;
  churchSystemsIds: number[];
  churchSystemsTags: string[];
  activeStatus: string;
  positionHolder: PositionHolder;
  centerStartDate: Date;
  addCenterUser: boolean;
  createdAt: Date;
  createdBy: string;
}

export class CenterMemberGetModel {
  id: number;
  prefix?: string;
  lastname: string;
  firstname: string;
  otherName?: string;
  ageGroup?: string;
  gender?: string;
  fullName: string;
  address?: string;
  phone?: string;
  phone2?: string;
  email?: string;
  maritalStatus?: string;
  weddingAnniversary?: Date;
  birthDay?: number;
  birthMonth?: string;
  birthYear?: number;
  dateOfBirth?: Date;
  membershipType?: CenterMemberShipStatus;
  memberConversionStatus?: CenterMemberConversionStatus;
  experiencedHolyGhostBaptism?: boolean;
  meetingDate: Date;
  meetingId: number;
  isSelected: boolean;
  centerId: number;
  centeShortAddress?: string;
  centerAddress: string;
  contactGender?: string;
  contactAddress?: string;
  contactPrefix: string;
  contactPhone?: string;
  contactEmail?: string;
  contactFirstname: string;
  contactLastname: string;
}

export class CenterMemberPostModel {
  id: number;
  centerId: number;
  center?: string;
  positionLevel?: string;
  positionLevelId?: number;
  personalDetails?: MemberPersonalDetails;
  qualification?: MemberQualification;
  churchDetails?: MemberChurchDetails;
  meetingAttended?: MeetingAttendedByNewCenterMember;
  AddressGeometryId?: number;
  invitedBy: Contact;
  /*isNewConvert?: boolean;
  isFirstTimer?: boolean;
  isCenterMember?: boolean;
  */
  membershipStatus: CenterMemberShipStatus;
  memberConversionStatus?: CenterMemberConversionStatus;
  createdAt?: Date;
  createdBy?: string;
  meetingParticipationStatus: MeetingParticipantGetModel;
}

export class MemberPersonalDetails {
  prefix?: string;
  lastname: string;
  firstname: string;
  otherName?: string;
  fullName: string;
  address?: string;
  gender?: string;
  ageGroup?: string;
  phone?: string;
  phone2?: string;
  email?: string;
  maritalStatus?: string;
  weddingAnniversary?: Date;
  birthDay?: number;
  birthMonth?: string;
  birthYear?: number;
  dateOfBirth?: Date;
  //joinedCenterAt?: Date;
  //convertedAt?: Date;
  holyGhostBaptismDate?: Date;
}

export class MemberQualification {
  highestQualification?: string;
  qualificationYear?: number;
  occupation?: string;
  otherProfessionalSkills?: string;
}

export class MemberChurchDetails {
  wofbiStatus?: string;
  wofbiStatusDate?: Date;
}

export class CenterProfile {
  centerId: number;
  centeShortAddress?: string;
  centerAddress: string;
  contactGender?: string;
  contactAddress?: string;
  contactPrefix: string;
  contactPhone?: string;
  contactEmail?: string;
  contactFirstname: string;
  contactLastname: string;
  contactPositionHolderId: number;
}

export class CenterLocation {
  id: number;
  country: string;
  state: string;
  city: string;
  address: string;
  description: string;
  created_at: Date;
  created_by: string;
}

export class CenterDataFromExcel {
  CenterNumber: number;
  CenterAddress: string;
  CenterShortNameFromAddress: string;
  MinisterPrefix: string; //E.g P12D123
  MinisterLastname: string;
  MinisterFirstname: string;
  MinisterOthername: string;
  MinisterPhone: string;
  MinisterEmail: string;
  MinisterSex: string;
  MinisterAddress: string;
  Center_type: string;
  ChurchSystemsTags: string;
  ParentCenterId: number;
}

export class PositionLevel {
  id: number;
  centerTypeId: number;
  name: string;
  description: string;
  isDefaultLevel: boolean;
  orderBy: number;
  createdAt: Date;
  createdBy: string;
  centerTypeName: string;
  assignedResources?: ResourceAccessor[];
  hasSameCenterTypeWithCurrentUser: boolean;
  alternativeCodeForSignUp: string;
  assignedPositionLevelsToManage: number[] = [];
  assignedChurchSystemsToManage: number[] = [];
  assignedCenterTypesToManage: number[] = [];
  isCentersContactLevel: boolean;
  showOnSignUp: boolean;
}

/*export class PositionLevelPrivilegeType {
  id?: number;
  name?: string;
  centerTypeId?: number;
  orderBy?: number;
}*/

export class AssignedPositionLevelPrivileges {
  assignedCenterTypes?: CenterType[];
  assignedPositionLevels?: PositionLevel[];
  assignedChurchSystems?: ChurchSystem[];
}

export class PositionModificationType {
  id: number;
  name: string;
  description: string;
  createdAt: Date;
  createdBy: string;
}

export class PositionHolder {
  id: number;
  centerId: number;
  positionHolderId: string;
  email: string;
  firstname: string;
  lastname: string;
  othername: string;
  fullname: string;
  address: string;
  maritalStatus: string;
  phone: string;
  prefix: string;
  gender: string;
  positionLevelId: number;
  holderChurchSystemIds: number[];
  createdAt: Date;
  createdBy: string;
  centerTypeId: number;
  hasSameCenterTypeWithCurrentUser?: boolean;
  isCentersContact?: boolean;
}

export class DrillDownCenters {
  centerId: number;
  // parentLevel: number;
  searchedCenter: CenterSearchResult;
  centerTypeId: number;
  parentCenters: CenterSearchResult[];
}

export class CenterToDelete {
  centerId: number;
  deletePermanently: boolean;
  reason: string;
  suspendCenter: boolean;
  authorizedBy?: string;
}

export class CenterToMove {
  newParentCenterId: number;
  oldParentCenterId: number;
  descendantsToMove: number[];
  reason: string;
  authorizedBy: string;
}

/*
export class PositionsRoutes {
  static positions = "positions";
  static positionsHolders = "positions_holders";
  static positionLevels = "position_levels";
  static positionModificationTypes = "position_modification_types";
  static positionStructureTypes = "position_structure_types";
}
*/

/*
export class CentersRoutes {
  static centerMembers = "center_members";
  static centerTypes = "center_types";
  static downloadCentersData = "download_centers_data";
  static updateCentersData = "update_centers_data";
  static createNewCenter = "create_a_center";
  static registerExistingCenters = "register_existing_centers";
  static centerLocations = "centers_locations";
  static centers = "centers";
}
*/
