import { Component, OnInit } from "@angular/core";
import { CenterType, PositionLevel } from "../../../models/centers.models";
import { Observable } from "rxjs";
import { finalize } from "rxjs/operators";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { FormBuilder } from "@angular/forms";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
import {
  AssignableResource,
  AssignableResourceGroup
} from "../../../models/resources.models";

import { groupBy, map, chain, uniqBy, find } from "lodash";
import { PrivilegesDialogComponent } from "../../dialog/privileges-dialog/privileges-dialog.component";
import { ResourcesSetupDialogComponent } from "../../dialog/resources-setup-dialog/resources-setup-dialog.component";
import { Meeting } from "../../../models/meetings.models";
import { Lookup, AppResourceType } from "../../../models/utilities.models";

@Component({
  selector: "app-resources-setup",
  templateUrl: "./resources-setup.component.html",
  styleUrls: ["./resources-setup.component.scss"]
})
export class ResourcesSetupComponent implements OnInit {
  //centerTypes$: Observable<CenterType[]>;
  //centerTypes: CenterType[];
  bsModalRef: BsModalRef;
  loading: boolean = false;
  assignableResourcesGroup: AssignableResourceGroup[];
  allAssignablePrivileges: string[] = [];
  categories: Lookup[] = [];

  constructor(
    private api: APIService,
    private formBuilder: FormBuilder,
    private modalService: BsModalService,
    private sweetAlertService: SweetAlertService
  ) {}

  ngOnInit() {
    this.loadAllResources();
    this.getAllAssignablePrivileges();
  }

  private loadAllResources() {
    this.loading = true;
    this.api
      .getAll<AssignableResource[]>(ApiRoutes.resources.get_all_resources)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);

        this.categories = chain(response)
          .map(e => {
            return { id: e.categoryId, name: e.categoryName } as Lookup;
          })
          .uniqBy("id")
          .value();

        const group = chain(response)
          .groupBy(x => x.categoryName)
          .map((value, key) => ({ category: key, resources: value }))
          .value();

        this.assignableResourcesGroup = group;
      });
  }

  public getAllAssignablePrivileges() {
    this.loading = true;
    this.api
      .getAll<string[]>(
        ApiRoutes.resources.resources_sharing_get_access_privileges
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.allAssignablePrivileges = response;
      });
  }

  public openModalToEditResource(resource: AssignableResource) {
    //console.log(resource);

    const config = {
      backdrop: true,
      ignoreBackdropClick: false,
      class: "modal-lg",
      initialState: {
        title: resource.name,
        selectedResourceId: resource.id,
        // allAssignablePositionLevels: this.allAssignablePositionLevels,
        allAssignablePrivileges: this.allAssignablePrivileges
      }
    };

    this.bsModalRef = this.modalService.show(
      ResourcesSetupDialogComponent,
      config
    );
    this.bsModalRef.content.action.subscribe(value => {
      // console.log(value); // here you will get the value

      if (value) {
        /*value.displayAddress = value.shortNameFromAddress
          ? value.address + " (" + value.shortNameFromAddress + ")"
          : value.address;
        this.parentCenter = value;**/
      }
    });
  }

  public openModalToAddResource(categoryName: string) {
    //console.log(resource);

    const catId = this.getResourceCategoryId(categoryName);

    const config = {
      backdrop: true,
      ignoreBackdropClick: false,
      class: "modal-lg",
      initialState: {
        title: "Add New Resource",
        selectedResourceCategoryId: catId,
        isNew: true,
        // allAssignablePositionLevels: this.allAssignablePositionLevels,
        allAssignablePrivileges: this.allAssignablePrivileges
      }
    };

    this.bsModalRef = this.modalService.show(
      ResourcesSetupDialogComponent,
      config
    );
    this.bsModalRef.content.action.subscribe(value => {
      // console.log(value); // here you will get the value

      if (value) {
        const section = find(this.assignableResourcesGroup, e => {
          return e.category == categoryName;
        });

        if (section && section.resources) {
          section.resources.push({
            name: value.name,
            id: value.id,
            categoryId: catId,
            categoryName: categoryName,
            hasBeenAssignedToAnyId: false
          } as AssignableResource);
        }
      }
    });
  }

  private getResourceCategoryId(categoryName: string): number {
    //console.log(this.categories);
    const cate = find(this.categories, e => e.name == categoryName);
    //console.log(cate);
    if (cate) {
      return cate.id;
    } else {
      return 0;
    }
    //console.log(cate);
  }
}
