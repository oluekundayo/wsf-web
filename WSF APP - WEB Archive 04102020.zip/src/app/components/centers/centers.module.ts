import { NgModule } from "@angular/core";
import { SharedModule } from "../../app.shared.module";
import { CentersDataDownloadComponent } from "./centers-data-download/centers-data-download.component";
import { CentersDataUpdateComponent } from "./centers-data-update/centers-data-update.component";
import { CreateNewCentersComponent } from "./create-new-centers/create-new-centers.component";
import { RegisterExistingCentersComponent } from "./register-existing-centers/register-existing-centers.component";
import { CentersRoutingModule } from "./centers-routing.module";
import { CreateNewCenterPositionHolderComponent } from "./create-new-center-position-holder/create-new-center-position-holder.component";
import { ViewRegisteredCentersComponent } from "./view-registered-centers/view-registered-centers.component";
import { MyCenterComponent } from "./my-center/my-center.component";
import { FindACenterComponent } from "./find-a-center/find-a-center.component";
import { FindACenterDialogComponent } from "../dialog/find-a-center-dialog/find-a-center-dialog.component";
import { EditCenterDialogComponent } from "../dialog/edit-center-dialog/edit-center-dialog.component";
import { RemoveCenterComponent } from "./remove-center/remove-center.component";
import { MoveCenterComponent } from "./move-center/move-center.component";

@NgModule({
  imports: [SharedModule, CentersRoutingModule],
  declarations: [
    CentersDataDownloadComponent,
    CentersDataUpdateComponent,
    CreateNewCentersComponent,
    RegisterExistingCentersComponent,
    FindACenterDialogComponent,
    CreateNewCentersComponent,
    CreateNewCenterPositionHolderComponent,
    ViewRegisteredCentersComponent,
    MyCenterComponent,
    FindACenterComponent,
    EditCenterDialogComponent,
    RemoveCenterComponent,
    MoveCenterComponent
  ],
  entryComponents: [FindACenterDialogComponent, EditCenterDialogComponent]
})
export class CentersModule {}
