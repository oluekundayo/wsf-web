import { NgModule } from "@angular/core";
import { SharedModule } from "../../app.shared.module";
import { ResourcesSetupDialogComponent } from "../dialog/resources-setup-dialog/resources-setup-dialog.component";
import { SetupsRoutingModule } from "./setups-routing.module";
import { ManagePrivilegesComponent } from "./manage-privileges/manage-privileges.component";
import { PrivilegesDialogComponent } from "../dialog/privileges-dialog/privileges-dialog.component";
import { ResourcesSetupComponent } from "./resources-setup/resources-setup.component";
import { MeetingsSetupComponent } from "./meetings-setup/meetings-setup.component";
import { ManagePositionLevelsComponent } from "./manage-position-levels/manage-position-levels.component";
import { DashboardComponent } from "../../dashboard/dashboard.component";
import { ChartsModule } from "ng2-charts";
import { CenterTypesSetupComponent } from "./center-types-setup/center-types-setup.component";

@NgModule({
  imports: [SharedModule, SetupsRoutingModule, ChartsModule],
  //PrivilegesDialogComponent - now declared in Shared Module bacause its used by botb admin and superuser
  declarations: [
    ResourcesSetupDialogComponent,
    ResourcesSetupComponent,
    //ManageResourcesForSuperuserComponent,
    MeetingsSetupComponent,
    ManagePositionLevelsComponent,
    ManagePrivilegesComponent,
    CenterTypesSetupComponent
  ],
  entryComponents: [ResourcesSetupDialogComponent, PrivilegesDialogComponent]
})
export class SetupsModule {}
