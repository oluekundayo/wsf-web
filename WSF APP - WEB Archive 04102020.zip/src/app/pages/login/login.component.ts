import { Component, OnInit, OnDestroy } from "@angular/core";
import { Router } from "@angular/router";

import {
  FormBuilder,
  Validators,
  FormGroup,
  FormControl
} from "@angular/forms";

import { Observable, Subscription } from "rxjs";
import { environment } from "environments/environment";
import { APIService } from "../../services/api.service";
import { AuthService } from "../../services/auth.service";
import { ApiRoutes } from "../../services/api.routes";
import { LoginDetails, LoggedInUser } from "../../models/user_account.models";
import { SweetAlertArrayOptions } from "sweetalert2";
import { SweetAlertService } from "../../services/utils/sweet-alert.service";
import { MenuInfo } from "../../models/menu.models";
import { finalize, timeout } from "rxjs/operators";
import { LoginService } from "../../services/components-services/login.service";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { UpdateProfileDialogComponent } from "../../components/dialog/update-profile-dialog/update-profile-dialog.component";
import { MenuService } from "../../services/components-services/menu.service";

//declare var $: any;

@Component({
  moduleId: module.id,
  selector: "login-cmp",
  templateUrl: "./login.component.html"
})
export class LoginComponent implements OnInit, OnDestroy {
  test: Date = new Date();
  appName: string = "WSF Portal";

  public loginDetails: LoginDetails;
  public loginForm: FormGroup;
  public loading: boolean = false;
  bsModalRef: BsModalRef;

  constructor(
    private router: Router,
    private loginService: LoginService,
    private fb: FormBuilder,
    private auth: AuthService,
    private alert: SweetAlertService,
    private menuService: MenuService,
    private modalService: BsModalService
  ) {
    this.loginDetails = new LoginDetails();
    this.loginDetails.username = this.auth.getUsername();
    this.auth.logout();
  }

  /*checkFullPageBackgroundImage() {
    var $page = $(".full-page");
    var image_src = $page.data("image");

    if (image_src !== undefined) {
      var image_container =
        '<div class="full-page-background" style="background-image: url(' +
        image_src +
        ') "/>';
      $page.append(image_container);
    }
  }*/

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: [this.loginDetails.username, Validators.required],
      password: [this.loginDetails.password, Validators.required]
    });

    /*  try {
      this.checkFullPageBackgroundImage();

      setTimeout(function() {
        // after 1000 ms we add the class animated to the login/register card
        $(".card").removeClass("card-hidden");
      }, 700);
    } catch (e) {}*/
  }

  public navigateToDashboard() {
    this.loading = true;
    this.loginDetails = this.loginForm.value;
    this.loginDetails.appVersion = environment.APP_VERSION;
    this.loginDetails.appType = environment.APP_TYPE;

    this.loginService
      .login(this.loginDetails)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(data => {
        //console.log(data);

        this.auth.cacheUsername(this.loginDetails.username);
        this.auth.setToken(data.token);
        if (this.loginDetails.username == "superuser") {
          this.menuService.SetUserMenu(this.loginService.getMenu());
        } else {
          this.menuService.SetUserMenu(data.menu);
        }
        this.loginDetails = null;

        if (!data.isProfileUpdated) {
          this.openModalToUpdateProfile();
        } else {
          setTimeout(() => {
            this.router.navigate(["/app/dashboard"]);
          }, 50);
        }
      });
  }

  public navigateToDashboardMock() {
    this.loading = true;
    this.loginDetails = this.loginForm.value;
    this.loginDetails.appVersion = environment.APP_VERSION;
    this.loginDetails.appType = environment.APP_TYPE;

    if (
      this.loginDetails.password == "test123" &&
      this.loginDetails.username == "test"
    ) {
      this.loginService
        .login(this.loginDetails)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(data => {
          //console.log(data);
          this.auth.cacheUsername(this.loginDetails.username);
          this.auth.setToken(data.token);
          this.menuService.SetUserMenu(data.menu);
          this.router.navigate(["/app/dashboard"]);
        });
    } else {
      this.loading = false;
      alert("Invalid Credentials");
    }
  }

  public openModalToUpdateProfile() {
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      //class: "modal-sm",
      initialState: {}
    };

    this.bsModalRef = this.modalService.show(
      UpdateProfileDialogComponent,
      config
    );
    this.bsModalRef.content.action.subscribe((value: boolean) => {
      if (value) {
        setTimeout(() => {
          this.router.navigate(["/app/dashboard"]);
        }, 50);
      }
    });
  }

  ngOnDestroy() {
    // this.confirmSubcription.unsubscribe();
  }
}
