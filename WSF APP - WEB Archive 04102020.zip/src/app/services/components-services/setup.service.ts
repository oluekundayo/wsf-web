import { Injectable } from "@angular/core";

import { APIService } from "../api.service";
import { ApiRoutes } from "../api.routes";
import { Observable } from "rxjs";
import { PositionLevel, CenterType } from "../../models/centers.models";
import {
  Meeting,
  MeetingAbsenceReason,
  MeetingSection
} from "../../models/meetings.models";
import {
  Country,
  State,
  City,
  Church,
  ChurchStructuralDivision,
  ChurchSystem,
  ResourcesCategory,
  Resource
} from "../../models/setups.models";

@Injectable()
export class church_setupservice {
  constructor(private apiService: APIService) {}

  // Country Services
  getCountries(): Observable<Country[]> {
    return this.apiService.getAll<Country[]>(ApiRoutes.church_setups.countries);
  }

  getCountryById(id: number) {
    return this.apiService.get<Country>(ApiRoutes.church_setups.countries, id);
  }

  createCountry(object: Country): Observable<Country> {
    return this.apiService.post(ApiRoutes.church_setups.countries, object);
  }

  updateCountry(object: Country): Observable<Country> {
    return this.apiService.put(
      ApiRoutes.church_setups.countries,
      object.id,
      object
    );
  }

  deleteCountry(id: number) {
    return this.apiService.delete(ApiRoutes.church_setups.countries, id);
  }

  // State Services
  getStates(): Observable<State[]> {
    return this.apiService.getAll<State[]>(ApiRoutes.church_setups.states);
  }

  getStateById(id: number) {
    return this.apiService.get<State>(ApiRoutes.church_setups.states, id);
  }

  createState(object: State): Observable<State> {
    return this.apiService.post(ApiRoutes.church_setups.states, object);
  }

  updateState(object: State): Observable<State> {
    return this.apiService.put(
      ApiRoutes.church_setups.states,
      object.id,
      object
    );
  }

  deleteState(id: number) {
    return this.apiService.delete(ApiRoutes.church_setups.states, id);
  }

  // City Services
  getCities(): Observable<City[]> {
    return this.apiService.getAll<City[]>(ApiRoutes.church_setups.cities);
  }

  getCityById(id: number) {
    return this.apiService.get<City>(ApiRoutes.church_setups.cities, id);
  }

  createCity(object: City): Observable<City> {
    return this.apiService.post(ApiRoutes.church_setups.cities, object);
  }

  updateCity(object: City): Observable<City> {
    return this.apiService.put(
      ApiRoutes.church_setups.cities,
      object.id,
      object
    );
  }

  deleteCity(id: number) {
    return this.apiService.delete(ApiRoutes.church_setups.cities, id);
  }

  // Church Services
  getChurches(): Observable<Church[]> {
    return this.apiService.getAll<Church[]>(ApiRoutes.church_setups.churches);
  }

  getChurchById(id: number) {
    return this.apiService.get<Church>(ApiRoutes.church_setups.churches, id);
  }

  createChurch(object: Church): Observable<Church> {
    return this.apiService.post(ApiRoutes.church_setups.churches, object);
  }

  updateChurch(object: Church): Observable<Church> {
    return this.apiService.put(
      ApiRoutes.church_setups.churches,
      object.id,
      object
    );
  }

  deleteChurch(id: number) {
    return this.apiService.delete(ApiRoutes.church_setups.churches, id);
  }

  // ChurchStructuralDivision Services
  getChurchStructuralDivisions(): Observable<ChurchStructuralDivision[]> {
    return this.apiService.getAll<ChurchStructuralDivision[]>(
      ApiRoutes.church_setups.structural_divisions
    );
  }

  getChurchStructuralDivisionById(id: number) {
    return this.apiService.get<ChurchStructuralDivision>(
      ApiRoutes.church_setups.structural_divisions,
      id
    );
  }

  createChurchStructuralDivision(
    object: ChurchStructuralDivision
  ): Observable<ChurchStructuralDivision> {
    return this.apiService.post(
      ApiRoutes.church_setups.structural_divisions,
      object
    );
  }

  updateChurchStructuralDivision(
    object: ChurchStructuralDivision
  ): Observable<ChurchStructuralDivision> {
    return this.apiService.put(
      ApiRoutes.church_setups.structural_divisions,
      object.id,
      object
    );
  }

  deleteChurchStructuralDivision(id: number) {
    return this.apiService.delete(
      ApiRoutes.church_setups.structural_divisions,
      id
    );
  }

  // ChurchSystem Services
  getChurchSystems(): Observable<ChurchSystem[]> {
    return this.apiService.getAll<ChurchSystem[]>(
      ApiRoutes.church_setups.church_systems
    );
  }

  getChurchSystemById(id: number) {
    return this.apiService.get<ChurchSystem>(
      ApiRoutes.church_setups.church_systems,
      id
    );
  }

  createChurchSystem(object: ChurchSystem): Observable<ChurchSystem> {
    return this.apiService.post(ApiRoutes.church_setups.church_systems, object);
  }

  updateChurchSystem(object: ChurchSystem): Observable<ChurchSystem> {
    return this.apiService.put(
      ApiRoutes.church_setups.church_systems,
      object.id,
      object
    );
  }

  deleteChurchSystem(id: number) {
    return this.apiService.delete(ApiRoutes.church_setups.church_systems, id);
  }

  // ResourcesCategory Services
  getResourcesCategories(): Observable<ResourcesCategory[]> {
    return this.apiService.getAll<ResourcesCategory[]>(
      ApiRoutes.resources.resources_categories
    );
  }

  getResourcesCategoryById(id: number) {
    return this.apiService.get<ResourcesCategory>(
      ApiRoutes.resources.resources_categories,
      id
    );
  }

  createResourcesCategory(
    object: ResourcesCategory
  ): Observable<ResourcesCategory> {
    return this.apiService.post(
      ApiRoutes.resources.resources_categories,
      object
    );
  }

  updateResourcesCategory(
    object: ResourcesCategory
  ): Observable<ResourcesCategory> {
    return this.apiService.put(
      ApiRoutes.resources.resources_categories,
      object.id,
      object
    );
  }

  deleteResourcesCategory(id: number) {
    return this.apiService.delete(ApiRoutes.resources.resources_categories, id);
  }

  // Resource Services
  getResources(): Observable<Resource[]> {
    return this.apiService.getAll<Resource[]>(ApiRoutes.resources.resources);
  }

  getResourceById(id: number) {
    return this.apiService.get<Resource>(ApiRoutes.resources.resources, id);
  }

  createResource(object: Resource): Observable<Resource> {
    return this.apiService.post(ApiRoutes.resources.resources, object);
  }

  updateResource(object: Resource): Observable<Resource> {
    return this.apiService.put(
      ApiRoutes.resources.resources,
      object.id,
      object
    );
  }

  deleteResource(id: number) {
    return this.apiService.delete(ApiRoutes.resources.resources, id);
  }

  // CenterType Services
  getCenterTypes(): Observable<CenterType[]> {
    return this.apiService.getAll<CenterType[]>(
      ApiRoutes.centers.centers_types
    );
  }

  getCenterTypeById(id: number) {
    return this.apiService.get<CenterType>(ApiRoutes.centers.centers_types, id);
  }

  createCenterType(object: CenterType): Observable<CenterType> {
    return this.apiService.post(ApiRoutes.centers.centers_types, object);
  }

  updateCenterType(object: CenterType): Observable<CenterType> {
    return this.apiService.put(
      ApiRoutes.centers.centers_types,
      object.id,
      object
    );
  }

  deleteCenterType(id: number) {
    return this.apiService.delete(ApiRoutes.centers.centers_types, id);
  }

  // PositionLevel Services
  getPositionLevels(): Observable<PositionLevel[]> {
    return this.apiService.getAll<PositionLevel[]>(
      ApiRoutes.position_levels.position_levels
    );
  }

  getPositionLevelById(id: number) {
    return this.apiService.get<PositionLevel>(
      ApiRoutes.position_levels.position_levels,
      id
    );
  }

  createPositionLevel(object: PositionLevel): Observable<PositionLevel> {
    return this.apiService.post(
      ApiRoutes.position_levels.position_levels,
      object
    );
  }

  updatePositionLevel(object: PositionLevel): Observable<PositionLevel> {
    return this.apiService.put(
      ApiRoutes.position_levels.position_levels,
      object.id,
      object
    );
  }

  deletePositionLevel(id: number) {
    return this.apiService.delete(
      ApiRoutes.position_levels.position_levels,
      id
    );
  }

  // MeetingSection Services
  getMeetingSections(): Observable<MeetingSection[]> {
    return this.apiService.getAll<MeetingSection[]>(
      ApiRoutes.meetings.meetings_sections
    );
  }

  getMeetingSectionById(id: number) {
    return this.apiService.get<MeetingSection>(
      ApiRoutes.meetings.meetings_sections,
      id
    );
  }

  createMeetingSection(object: MeetingSection): Observable<MeetingSection> {
    return this.apiService.post(ApiRoutes.meetings.meetings_sections, object);
  }

  updateMeetingSection(object: MeetingSection): Observable<MeetingSection> {
    return this.apiService.put(
      ApiRoutes.meetings.meetings_sections,
      object.id,
      object
    );
  }

  deleteMeetingSection(id: number) {
    return this.apiService.delete(ApiRoutes.meetings.meetings_sections, id);
  }

  // MeetingAbsenceReason Services
  getMeetingAbsenceReasons(): Observable<MeetingAbsenceReason[]> {
    return this.apiService.getAll<MeetingAbsenceReason[]>(
      ApiRoutes.meetings.meetings_absence_reasons
    );
  }

  getMeetingAbsenceReasonById(id: number) {
    return this.apiService.get<MeetingAbsenceReason>(
      ApiRoutes.meetings.meetings_absence_reasons,
      id
    );
  }

  createMeetingAbsenceReason(
    object: MeetingAbsenceReason
  ): Observable<MeetingAbsenceReason> {
    return this.apiService.post(
      ApiRoutes.meetings.meetings_absence_reasons,
      object
    );
  }

  updateMeetingAbsenceReason(
    object: MeetingAbsenceReason
  ): Observable<MeetingAbsenceReason> {
    return this.apiService.put(
      ApiRoutes.meetings.meetings_absence_reasons,
      object.id,
      object
    );
  }

  deleteMeetingAbsenceReason(id: number) {
    return this.apiService.delete(
      ApiRoutes.meetings.meetings_absence_reasons,
      id
    );
  }
}
