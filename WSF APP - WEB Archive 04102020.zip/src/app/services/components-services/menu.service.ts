import { Injectable } from "@angular/core";
import { Subject, Observable, BehaviorSubject } from "rxjs";
import { MenuInfo } from "../../models/menu.models";

@Injectable({
  providedIn: "root"
})
export class MenuService {
  private subject = new BehaviorSubject<MenuInfo[]>([]);

  constructor() {}

  public SetUserMenu(menu: MenuInfo[]) {
    this.subject.next(menu);
  }

  public GetUserMenu(): Observable<MenuInfo[]> {
    return this.subject.asObservable();
  }
}
