import { Routes, RouterModule } from "@angular/router";

import { AdminLayoutComponent } from "./layouts/admin/admin-layout.component";
import { AuthLayoutComponent } from "./layouts/auth/auth-layout.component";
import { NgModule } from "@angular/core";
import { AuthGuard } from "./services/guards/auth-guard.service";

export const AppRoutes: Routes = [
  {
    path: "app",
    component: AdminLayoutComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: "dashboard",
        loadChildren: "./dashboard/dashboard.module#DashboardModule"
      },
      {
        path: "centers",
        loadChildren: "./components/centers/centers.module#CentersModule"
      },
      {
        path: "reports",
        loadChildren: "./components/reports/reporting.module#ReportingModule"
      },
      /* {
        path: "reports-analysis",
        loadChildren:
          "./components/reports-analysis/reports-analysis.module#ReportsAnalysisModule"
      },
      {
        path: "resources",
        loadChildren: "./components/resources/resources.module#ResourcesModule"
      },*/
      {
        path: "publications",
        loadChildren:
          "./components/publications/publications.module#PublicationsModule"
      },
      {
        path: "testimonies",
        loadChildren:
          "./components/testimonies/testimonies.module#TestimoniesModule"
      },
      {
        path: "user-account",
        loadChildren:
          "./components/user-account/user-account.module#UserAccountModule"
      },
      {
        path: "follow-up",
        loadChildren: "./components/follow-up/follow-up.module#FollowUpModule"
      },
      {
        path: "transportation-system",
        loadChildren:
          "./components/transportation-system/transportation-system.module#TransportationSystemModule"
      },
      {
        path: "setups",
        loadChildren: "./components/setups/setups.module#SetupsModule"
      }

      /* {
        path: "setups",
        loadChildren: "./components/setups/setups.module#SetupsModule"
      },
      {
        path: "charts",
        loadChildren: "./charts/charts.module#ChartsModule"
      }*/
      /* {
        path: "profile",
        loadChildren: "./userpage/user.module#UserModule"
      }*/
    ]
  },
  {
    path: "auth",
    component: AuthLayoutComponent,
    children: [
      {
        path: "user",
        loadChildren: "./pages/pages.module#PagesModule"
      }
    ]
  },
  {
    path: "",
    redirectTo: "auth/user/login",
    pathMatch: "full"
  }
];

@NgModule({
  imports: [RouterModule.forRoot(AppRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
