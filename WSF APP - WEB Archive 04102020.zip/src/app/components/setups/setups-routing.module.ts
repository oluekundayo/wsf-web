import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "../../services/guards/auth-guard.service";
import { ManagePrivilegesComponent } from "./manage-privileges/manage-privileges.component";
import { ResourcesSetupComponent } from "./resources-setup/resources-setup.component";
import { MeetingsSetupComponent } from "./meetings-setup/meetings-setup.component";
import { ManagePositionLevelsComponent } from "./manage-position-levels/manage-position-levels.component";
import { DashboardComponent } from "../../dashboard/dashboard.component";
import { ApiRoutes } from "app/services/api.routes";
import { CenterTypesSetupComponent } from "./center-types-setup/center-types-setup.component";

const routes: Routes = [
  {
    path: "setup-resources",
    component: ResourcesSetupComponent,
    data: {
      title: "Setup Resources"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "setup-center-types",
    component: CenterTypesSetupComponent,
    data: {
      title: "Setup Center Type"
    },
    canActivate: [AuthGuard]
  },

  {
    path: "setup-meetings",
    component: MeetingsSetupComponent,
    data: {
      title: "Setup Meetings"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "manage-position-levels",
    component: ManagePositionLevelsComponent,
    data: {
      title: "Manage Position Levels"
    },
    canActivate: [AuthGuard]
  },
  {
    path: "manage-privileges",
    component: ManagePrivilegesComponent,
    data: {
      title: "Manage Privileges",
      id: 2
    },
    canActivate: [AuthGuard]
  },
  {
    path: ApiRoutes.super_user.setup_access_privileges_code,
    component: ManagePrivilegesComponent,
    data: {
      title: "Manage Privileges",
      id: 1
    },
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SetupsRoutingModule {}
