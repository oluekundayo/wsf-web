import {
  Component,
  OnInit,
  AfterViewChecked,
  AfterViewInit,
  OnDestroy,
  TemplateRef
} from "@angular/core";
import { DataCacheTestimoniesService } from "../../../services/data-cache/data-cache-testimonies.service";
import { TabDirective } from "ngx-bootstrap/tabs";
import { ApiRoutes } from "../../../services/api.routes";
import { Validators, FormGroup, FormBuilder } from "@angular/forms";
import {
  Testimony,
  PaginatedTestimonies
} from "../../../models/testimonies.models";
import { TestimonyService } from "../../../services/components-services/testimony.service";
import {
  PaginatorFilter,
  Lookup,
  ApprovalStatus,
  DataCacheMode,
  PageDirection,
  SimpleFilterHolderWithDescription,
  PageFilterDescription
} from "../../../models/utilities.models";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { TestimonyPageType } from "../../../models/publications.models";

import {
  distinctUntilChanged,
  debounceTime,
  switchMap,
  tap,
  catchError,
  finalize,
  filter
} from "rxjs/operators";
import { Subject, Observable, of, concat } from "rxjs";
import { PagerService } from "../../../services/utils/pager.service";
import { Router } from "@angular/router";
import { random } from "lodash";
//import { ViewportScroller, Location } from "@angular/common";
//import * as moment from 'moment';

@Component({
  selector: "app-testimonies",
  templateUrl: "./testimonies.component.html",
  styleUrls: ["./testimonies.component.scss"]
})
export class TestimoniesComponent implements OnInit, OnDestroy, AfterViewInit {
  loading: boolean = false;
  //searchResults$: Observable<SearchTestimoniesResult[]>;
  //searchQuery$ = new Subject<string>();
  //selectedSearchItemId: number;
  //isSearchLoading: boolean = false;
  pageListMode: DataCacheMode = DataCacheMode.Approved;
  cachedApprovedTestimonies: Testimony[] = [];
  cachedBookmarkedTestimonies: Testimony[] = [];
  searchedTestimonies: Testimony[] = [];
  cachedApprovedPaginator: PaginatorFilter;
  cachedBookmarkedPaginator: PaginatorFilter;
  cachedPageListModeBeforeSearch: DataCacheMode = DataCacheMode.Approved;

  currentPageTitle: string = "All Testimonies";
  currentPaginator: PaginatorFilter;
  testimonies: Testimony[] = [];

  limitFormGroup: FormGroup;
  exlaimTextList: string[] = [
    "Good News",
    "Praise the Lord",
    "Striking",
    "He Did It Again",
    "Bless the Lord",
    "Come and See",
    "Hossanna",
    "I will Testify",
    "Thankful",
    "Who did it?"
  ];
  PAGINATOR_PAGE_SIZE: number = 10;
  selectedTestimonyId: number = 0;
  hasSelectedTestimonyBeenBookmarked: boolean = false;
  selectedTestimonyDetails: Testimony = new Testimony();
  public bsModalRef: BsModalRef;
  showLimitSection: boolean = false;
  public testimoniesCategories: Lookup[] = [];
  simpleFilterDescription: PageFilterDescription;

  constructor(
    private testimonyService: TestimonyService,
    private modalService: BsModalService,
    private fb: FormBuilder,
    private router: Router
  ) {
    this.createFilterFormGroup();
    this.initPaginators();
  }

  ngOnInit() {
    //this.pageListMode = this.dataCache.getLastSelectedPageMode();
    //this.changePageMode(this.pageListMode);
    this.loadNextItems(true);
    //this.initSearch();
  }

  private initPaginators() {
    this.currentPaginator = new PaginatorFilter();
    this.currentPaginator.pageSize = this.PAGINATOR_PAGE_SIZE;
    this.currentPaginator.direction = PageDirection.NEXT;
    this.currentPaginator.lastMaxId = 0;
    this.currentPaginator.totalItemsCount = 0;
    this.currentPaginator.currentPageStart = 0;
    this.currentPaginator.currentPageEnd = 0;

    this.cachedApprovedPaginator = new PaginatorFilter();
    this.cachedApprovedPaginator.pageSize = this.PAGINATOR_PAGE_SIZE;
    this.cachedApprovedPaginator.direction = PageDirection.NEXT;
    this.cachedApprovedPaginator.lastMaxId = 0;
    this.cachedApprovedPaginator.totalItemsCount = 0;
    this.cachedApprovedPaginator.currentPageStart = 0;
    this.cachedApprovedPaginator.currentPageEnd = 0;

    this.cachedBookmarkedPaginator = new PaginatorFilter();
    this.cachedBookmarkedPaginator.pageSize = this.PAGINATOR_PAGE_SIZE;
    this.cachedBookmarkedPaginator.direction = PageDirection.NEXT;
    this.cachedBookmarkedPaginator.lastMaxId = 0;
    this.cachedBookmarkedPaginator.totalItemsCount = 0;
    this.cachedBookmarkedPaginator.currentPageStart = 0;
    this.cachedBookmarkedPaginator.currentPageEnd = 0;

    this.changePageMode(this.pageListMode);
  }

  ngAfterViewInit() {
    this.getTestimoniesCategories();
    //console.log(this.scrollPosition);
    //this.viewportScroller.scrollToPosition(this.scrollPosition);
  }

  loadNextItems(
    isInitLoad: boolean = false
    //cachedTestimoniesInstance: Testimony[],
    //paginator: PaginatorFilter
  ) {
    // connect to api on first page to update data
    if (
      this.testimonies.length == 0 ||
      this.currentPaginator.totalItemsCount > this.testimonies.length
    ) {
      this.loading = true;
      this.currentPaginator.direction = PageDirection.NEXT;

      if (!this.currentPaginator.limitToBookmarks) {
        this.currentPaginator.filterStartDate = this.limitFormGroup.value.startDate;
        this.currentPaginator.filterEndDate = this.limitFormGroup.value.endDate;
      }
      this.currentPaginator.filterItemsCategoryId = this.limitFormGroup.value.categoryId;

      this.testimonyService
        .getApprovedTestimonies(this.currentPaginator)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          //console.log(response);
          this.updateResults(response.testimonies);
          //this.tempCurrentPaginator.direction = PageDirection.UNKNOWN;
          //this.dataCache.cacheTestimonies(this.pageListMode, response);
          this.testimonies = response.testimonies;

          //console.log(cachedTestimoniesInstance);

          this.currentPaginator = response.paginator;
          if (!isInitLoad) {
            this.currentPaginator.currentPageStart += this.currentPaginator.pageSize;
            this.currentPaginator.currentPageEnd = this.testimonies.length
              ? this.currentPaginator.currentPageEnd + this.testimonies.length
              : 0;
          } else {
            this.currentPaginator.currentPageStart = this.testimonies.length
              ? 1
              : 0;
            this.currentPaginator.currentPageEnd = this.testimonies.length
              ? this.currentPaginator.pageSize
              : 0;
          }

          if (this.pageListMode == DataCacheMode.Approved) {
            this.cachedApprovedTestimonies = this.testimonies;
            this.cachedApprovedPaginator = this.currentPaginator;
          } else if (this.pageListMode == DataCacheMode.Bookmarked) {
            this.cachedBookmarkedTestimonies = this.testimonies;
            this.cachedBookmarkedPaginator = this.currentPaginator;
          }
        });
    }
  }

  loadPreviousItems() //cachedTestimoniesInstance: Testimony[],
  //paginator: PaginatorFilter
  {
    // connect to api on first page to update data
    this.loading = true;
    this.currentPaginator.direction = PageDirection.PREVIOUS;

    if (!this.currentPaginator.limitToBookmarks) {
      this.currentPaginator.filterStartDate = this.limitFormGroup.value.startDate;
      this.currentPaginator.filterEndDate = this.limitFormGroup.value.endDate;
    }

    this.currentPaginator.filterItemsCategoryId = this.limitFormGroup.value.categoryId;
    this.testimonyService
      .getApprovedTestimonies(this.currentPaginator)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        //console.log(response);
        this.updateResults(response.testimonies);
        //this.tempCurrentPaginator.direction = PageDirection.UNKNOWN;
        //this.dataCache.cacheTestimonies(this.pageListMode, response);
        let tempEnd = 0;
        if (
          this.currentPaginator.currentPageEnd ==
          this.currentPaginator.totalItemsCount
        ) {
          tempEnd = this.currentPaginator.currentPageEnd -= this.testimonies.length;
        }

        this.testimonies = response.testimonies;
        this.currentPaginator = response.paginator;

        this.currentPaginator.currentPageStart -= this.currentPaginator.pageSize;

        if (tempEnd == 0) {
          this.currentPaginator.currentPageEnd -= this.testimonies.length;
        }

        if (this.pageListMode == DataCacheMode.Approved) {
          this.cachedApprovedTestimonies = this.testimonies;
          this.cachedApprovedPaginator = this.currentPaginator;
        } else if (this.pageListMode == DataCacheMode.Bookmarked) {
          this.cachedBookmarkedTestimonies = this.testimonies;
          this.cachedBookmarkedPaginator = this.currentPaginator;
        }
      });
  }

  public changePageMode(pageMode: string) {
    if (pageMode == DataCacheMode.Approved) {
      this.pageListMode = DataCacheMode.Approved;
      this.currentPageTitle = "All Testimonies";
      this.cachedApprovedPaginator.limitToBookmarks = false;
      this.testimonies = this.cachedApprovedTestimonies;
      this.currentPaginator = this.cachedApprovedPaginator;
    } else if (pageMode == DataCacheMode.Bookmarked) {
      this.pageListMode = DataCacheMode.Bookmarked;
      this.currentPageTitle = "Starred Testimonies";
      this.cachedBookmarkedPaginator.limitToBookmarks = true;
      this.testimonies = this.cachedBookmarkedTestimonies;
      this.currentPaginator = this.cachedBookmarkedPaginator;

      if (!this.cachedBookmarkedTestimonies) {
        this.loadNextItems();
      }
    }
  }

  /*private initSearch() {
    this.searchResults$ = concat(
      of([] as SearchTestimoniesResult[]), // default items
      this.searchQuery$.pipe(
        debounceTime(200),
        distinctUntilChanged(),
        tap(() => (this.isSearchLoading = true)),
        switchMap(term =>
          this.testimonyService.searchTestimonies(term).pipe(
            catchError(() => of([] as SearchTestimoniesResult[])), // empty list on error
            tap(() => (this.isSearchLoading = false))
          )
        )
      )
    );
  }*/

  private getTestimoniesCategories() {
    this.testimonyService
      .getTestimonyCategories()
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.testimoniesCategories = response;
      });
  }

  trackerFn(index, item) {
    //do what ever logic you need to come up with the unique identifier of your item in loop, I will just return the object id.
    return index;
  }

  public navigateToDetails(id: number, template: any) {
    // this.router.navigate(["app/testimonies/testimony-details/testimony", id]);
    /* this.selectedTestimonyId = id;
    this.hasSelectedTestimonyBeenBookmarked = isBookmarkItem;*/
    // this.isInDataListMode = false;
    if (id) {
      this.loading = true;
      this.testimonyService
        .getTestimonyDetail(id)
        .pipe(finalize(() => (this.loading = false)))
        .subscribe(response => {
          this.selectedTestimonyDetails = response;
          this.bsModalRef = this.modalService.show(template, {
            ignoreBackdropClick: true,
            class: "modal-lg"
          });
        });
    }
  }

  createFilterFormGroup() {
    this.limitFormGroup = this.fb.group({
      startDate: [null],
      endDate: [null],
      categoryId: [null]
      //searchText: [""]
    });
  }

  updateResults(data: Testimony[]) {
    data.forEach(element => {
      element.exclaimText = this.exlaimTextList[random(0, 9)];
      element.imageUrl =
        "../../../../assets/img/hallelujah/hallelujah_" +
        random(1, 120) +
        ".jpeg";
    });
  }

  public navigateToShareTestimony() {
    this.router.navigate(["/app/testimonies/send-testimonies"]);
  }

  public onApplyFilter(filterHolder: SimpleFilterHolderWithDescription) {
    this.simpleFilterDescription = filterHolder.description;
    this.cachedPageListModeBeforeSearch = this.pageListMode;
    //console.log(term);
    this.testimonyService
      .searchTestimonies(filterHolder.filter)
      .pipe(
        finalize(() => {
          this.loading = false;
          this.pageListMode = DataCacheMode.Search;
          if (filterHolder.isAdvancedSearch && filterHolder.bsModalRef)
            filterHolder.bsModalRef.hide();
        })
      )
      .subscribe(response => {
        //this.removeRunningFilter();
        this.searchedTestimonies = response;
      });
  }

  ngOnDestroy(): void {}
}
