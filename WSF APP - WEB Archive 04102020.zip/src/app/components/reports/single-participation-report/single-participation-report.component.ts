import { Component, OnInit, ViewEncapsulation, OnDestroy } from "@angular/core";
import { FormBuilder, FormGroup, Validators, FormArray } from "@angular/forms";
import {
  MeetingReportToSubmit,
  MeetingParticipantGetModel,
  MeetingDashboardItem
} from "app/models/reporting.models";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
//import { CenterMember } from "../../../models/centers.models";
import { Router, ActivatedRoute, NavigationEnd } from "@angular/router";
import { finalize, filter, map } from "rxjs/operators";
import {
  ResponseModel,
  CenterMemberShipStatus,
  ReportPageActionType
} from "../../../models/utilities.models";
import { Meeting } from "../../../models/meetings.models";
import { Subscription } from "rxjs";
import { ReportingService } from "../../../services/components-services/reporting.service";
import { CreateMeetingParticipantDialogComponent } from "../../dialog/create-meeting-participant-dialog/create-meeting-participant-dialog.component";

@Component({
  selector: "app-single-participation-report",
  templateUrl: "./single-participation-report.component.html",
  styleUrls: ["./single-participation-report.component.css"],
  encapsulation: ViewEncapsulation.Emulated,
  providers: [ReportingService]
})
export class SingleParticipationReportComponent implements OnInit, OnDestroy {
  bsModalRef: BsModalRef;
  loading: boolean = false;
  attendees: MeetingParticipantGetModel[] = [];
  //meetingId: number = 0;
  coordinatedBy: string = "";
  meetingDate: Date;
  meeting: MeetingDashboardItem;
  routeSubscription: Subscription;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private activeRoute: ActivatedRoute,
    private reportingServce: ReportingService,
    private modalService: BsModalService,
    private sweetAlertService: SweetAlertService
  ) {
    /* try {
      const routeParams = this.activeRoute.snapshot.params;
      this.meetingId = routeParams.id;
      console.log(this.meetingId);
    } catch (e) {}*/
    try {
      this.routeSubscription = this.router.events
        .pipe(
          filter(e => e instanceof NavigationEnd),
          map(() => this.router.getCurrentNavigation().extras.state)
        )
        .subscribe(response => {
          this.meeting = response.meeting;
        });
    } catch (e) {
      //console.log(e);
    }
  }

  ngOnInit() {
    this.getCurrentParticipants();
  }

  private getCurrentParticipants() {
    this.loading = true;
    this.reportingServce
      .getCurrentMonthParticipants(this.meeting.id)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((data: MeetingParticipantGetModel[]) => {
        //console.log(data);
        this.attendees = data;
      });
  }

  public openModalToCreateCenterMember() {
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      initialState: {
        memberShipStatus: CenterMemberShipStatus.MeetingParticipant,
        meeting: this.meeting,
        markParticipantAttendanceAsPresent: true
      }
    };

    this.bsModalRef = this.modalService.show(
      CreateMeetingParticipantDialogComponent,
      config
    );
    this.bsModalRef.content.action.subscribe(
      (value: MeetingParticipantGetModel) => {
        //console.log(value); // here you will get the value
        if (value) {
          this.attendees.unshift(value);
        }
      }
    );
  }

  navigateBackToReportsList() {
    this.router.navigate(["app/reports/menu/" + ReportPageActionType.Submit]);
  }

  private validateInputs(): ResponseModel {
    const response = new ResponseModel();
    response.error = "";
    response.isOk = true;

    if (!this.meetingDate) {
      response.isOk = false;
    }

    /* if(this.attendees.includes())
        {
          response.isOk = false;
        }*/

    return response;
  }

  ngOnDestroy(): void {
    try {
      this.bsModalRef.content.action.unsubscribe();
    } catch {}
    this.routeSubscription.unsubscribe();
  }
}
