import { tap, map, catchError, retry } from "rxjs/operators";
import { Router } from "@angular/router";
import { Injectable } from "@angular/core";
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
  HttpResponse
} from "@angular/common/http";
import { Observable } from "rxjs";
import { AuthService } from "app/services/auth.service";
import { SweetAlertService } from "./utils/sweet-alert.service";


//https://medium.com/@amcdnl/authentication-in-angular-jwt-c1067495c5e0
//https://medium.com/@ryanchenkie_40935/angular-authentication-using-the-http-client-and-http-interceptors-2f9d1540eb8

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor(
    private router: Router,
    private auth: AuthService,
    private sweetAlertService: SweetAlertService
  ) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const token = this.auth.getToken();

    if (token)
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`,
          //'Content-Type': 'application/x-www-form-urlencoded',
          Accept: "application/json"
          //"Content-Type": "application/json" // removed today 12-02-2019 to allow uploading files in publication. so content type is automatically determined by the app.
        }
      });

    /*if (!request.headers.has("Content-Type"))
      request = request.clone({
        setHeaders: {
          "Content-Type": "application/json"
        }
      });*/
    // ____________________________ Handle 1 sample________________________________
    //return next.handle(request);

    return next.handle(request).pipe(
      map((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {
          // change the response body here
          //console.log(event.body);
          //console.log(request.method);
          /*let message = "";
          if (request.method == "POST") 
          {
            message = "New Item(s) successfully created.";
          } 
          else if (request.method == "PUT") 
          {
            message = "Item successfully updated.";
          } else if (request.method == "DELETE") 
          {
            message = "Item successfully deleted.";
          }
          if (message) this.sweetAlertService.showSuccess(message); */
          /*
          if (typeof event.body === "string")
            this.dialog.openMessage(event.body, "Information");
          else if (event.body instanceof Object) {
            if (event.body.message)
              this.dialog.openMessage(event.body.message, "Information");
            if (event.body.data)
              return event.clone({
                body: event.body.data
              });
          }*/
        }

        return event;
      }),
      tap(
        (event: HttpEvent<any>) => {},
        (error: any) => {
          if (error instanceof HttpErrorResponse) {
            let alertMessage = null;
            if (error.status === 401) {
              alertMessage =
                "Your authentication session has expired. Kindly login again to refresh. Redirect to login page?";
            } else if (error.status === 403) {
              alertMessage =
                "Your user account is not authorised to access this resource. Kindly check your login details. Redirect to login page?";
            }

            if (alertMessage) {
              this.sweetAlertService
                .showConfirmRedirect(alertMessage)
                .then(response => {
                  if (response.value) {
                    this.router.navigate(["/auth/user/login"]);
                  }
                });
            }
          }
        }
      )
    );

    // ____________________________ Handle 3 sample________________________________
    /*return (
      next
        .handle(request)
        //.retry(3)

        // filter out only events that HTTP event.
        .filter((event: HttpEvent<any>) => event instanceof HttpResponse)

        .map((event: HttpEvent<any>) => {
          if (event instanceof HttpResponse) {
            if (event.status == 200 && event.body.message) {
              let data = event.body.data;
              let message = event.body.message;
              event.clone({ body: data });
              this.dialog.openMessage(message, "Response");
              console.log(event.body);
            }
          }
          return event;
        })
    );*/
  }
}
