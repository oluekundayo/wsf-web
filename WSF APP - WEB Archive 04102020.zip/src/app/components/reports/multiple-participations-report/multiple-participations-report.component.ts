import { Component, OnInit, ViewEncapsulation, OnDestroy } from "@angular/core";
import { FormBuilder, FormGroup, Validators, FormArray } from "@angular/forms";
import {
  MeetingReportToSubmit,
  MeetingParticipantGetModel,
  MeetingDashboardItem
} from "app/models/reporting.models";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { SweetAlertService } from "../../../services/utils/sweet-alert.service";
//import { CenterMember } from "../../../models/centers.models";
import { Router, ActivatedRoute, NavigationEnd } from "@angular/router";
import { finalize, filter, map } from "rxjs/operators";
import {
  ResponseModel,
  CenterMemberShipStatus,
  ReportPageActionType
} from "../../../models/utilities.models";
import { MarkAttendanceDialogComponent } from "../../dialog/mark-attendance-dialog/mark-attendance-dialog.component";
import { CenterMemberPostModel } from "../../../models/centers.models";
import { Subscription } from "rxjs";
import { Meeting } from "../../../models/meetings.models";
import { ReportingService } from "../../../services/components-services/reporting.service";
import { CreateMeetingParticipantDialogComponent } from "../../dialog/create-meeting-participant-dialog/create-meeting-participant-dialog.component";

@Component({
  selector: "app-multiple-participations-report",
  templateUrl: "./multiple-participations-report.component.html",
  styleUrls: ["./multiple-participations-report.component.css"],
  encapsulation: ViewEncapsulation.Emulated
  //providers: [ReportingService]
})
export class MultipleParticipationsReportComponent
  implements OnInit, OnDestroy {
  bsModalRef: BsModalRef;
  loading: boolean = false;
  attendees: MeetingParticipantGetModel[] = [];
  //meetingId: number = 0;
  coordinatedBy: string = "";
  meetingDate: Date;
  meeting: MeetingDashboardItem;
  routeSubscription: Subscription;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private activeRoute: ActivatedRoute,
    private reportingServce: ReportingService,
    private modalService: BsModalService,
    private sweetAlertService: SweetAlertService
  ) {
    /*try {
      const routeParams = this.activeRoute.snapshot.params;
      this.meetingId = routeParams.id;
      //console.log(this.meetingId);
    } catch (e) {}*/

    try {
      this.routeSubscription = this.router.events
        .pipe(
          filter(e => e instanceof NavigationEnd),
          map(() => this.router.getCurrentNavigation().extras.state)
        )
        .subscribe(response => {
          this.meeting = response.meeting;
        });
    } catch (e) {
      //console.log(e);
    }
  }

  ngOnInit() {
    this.getCurrentParticipants();
  }

  private getCurrentParticipants() {
    /*const array2: MeetingParticipantGetModel[] = [];

    const counts = [1, 2, 3, 4, 5, 6, 7, 8];

    counts.forEach(element => {
      const mmm = new MeetingParticipantGetModel();
      mmm.id = 1;
      mmm.fullName = "Mr. Oluwadahunsi Ayotunde " + element;
      mmm.ageGroup = "Adult " + element;
      mmm.phone = "07069011717";
      mmm.gender = "Male";
      mmm.totalAttendanceCount = 2;

      array2.push(mmm);
    });

    this.attendees = array2;
    return;*/

    this.loading = true;
    this.reportingServce
      .getCurrentParticipants(this.meeting.id)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe((data: MeetingParticipantGetModel[]) => {
        //console.log(data);
        this.attendees = data;
      });
  }

  public openModalToCreateCenterMember() {
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      initialState: {
        memberShipStatus: CenterMemberShipStatus.MeetingParticipant,
        meeting: this.meeting,
        markParticipantAttendanceAsPresent: true
      }
    };

    this.bsModalRef = this.modalService.show(
      CreateMeetingParticipantDialogComponent,
      config
    );
    this.bsModalRef.content.action.subscribe(
      (value: MeetingParticipantGetModel) => {
        //console.log(value); // here you will get the value
        if (value) {
          this.attendees.unshift(value);
        }
      }
    );
  }

  private getNewParticiPantRecord(
    value: CenterMemberPostModel
  ): MeetingParticipantGetModel {
    //console.log(value);

    const part = new MeetingParticipantGetModel();

    if (value.personalDetails) {
      part.ageGroup = value.personalDetails.ageGroup;
      part.centerMemberId = value.id;
      part.fullName = value.personalDetails.fullName;
      part.gender = value.personalDetails.gender;
      part.phone = value.personalDetails.phone;
      part.prefix = value.personalDetails.prefix;
    }

    if (value.meetingParticipationStatus) {
      part.participationCount =
        value.meetingParticipationStatus.participationCount;
      part.participationStatus =
        value.meetingParticipationStatus.participationStatus;
      part.participantStatusId =
        value.meetingParticipationStatus.participantStatusId;
      part.startDate = value.meetingParticipationStatus.startDate;
      part.completionDate = value.meetingParticipationStatus.completionDate;
    }

    //console.log(part);
    return part;
  }

  public openModalToMarkAttendance(index: number) {
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      //class: "modal-sm",
      initialState: {
        attendee: this.attendees[index],
        meeting: this.meeting
      }
    };

    this.bsModalRef = this.modalService.show(
      MarkAttendanceDialogComponent,
      config
    );
    this.bsModalRef.content.action.subscribe(
      (value: MeetingParticipantGetModel) => {
        //console.log(value); // here you will get the value
        if (value) {
          this.attendees[index] = value as MeetingParticipantGetModel;
        }
      }
    );
  }

  navigateBackToReportsList() {
    this.router.navigate(["app/reports/menu/" + ReportPageActionType.Submit]);
  }

  /*navigateToViewReport() {
    this.router.navigate([
      "app/reports/view-submitted-reports",
      this.meetingId
    ]);
  }*/

  /*submitReport() {
    const validate = this.validateInputs();
    if (!validate.isOk) {
      this.sweetAlertService.showError(validate.error);
      return;
    }

    const report: MeetingReportToSubmit = {
      meetingId: this.meetingId,
      meetingAttendance: null,
      meetingParticipants: this.attendees,
      meetingDate: this.meetingDate,
      coordinatedBy: this.coordinatedBy
    };

    //console.log(report);

    this.loading = true;
    this.reportingServce
      .submitParticipantsAttendanceReport(report)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(data => {
        this.resetPage();
      });
  }

  private resetPage() {
    alert("Page Reset");
  }*/

  private validateInputs(): ResponseModel {
    const response = new ResponseModel();
    response.error = "";
    response.isOk = true;

    if (!this.meetingDate) {
      response.isOk = false;
    }

    /* if(this.attendees.includes())
        {
          response.isOk = false;
        }*/

    return response;
  }

  ngOnDestroy(): void {
    try {
      this.bsModalRef.content.action.unsubscribe();
    } catch {}
    this.routeSubscription.unsubscribe();
  }
}
