import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Meeting } from "../../../models/meetings.models";
import { ReportingService } from "../../../services/components-services/reporting.service";

@Component({
  selector: "app-approval-for-combined-meetings",
  templateUrl: "./approval-for-combined-meetings.component.html",
  styleUrls: ["./approval-for-combined-meetings.component.css"],
  encapsulation: ViewEncapsulation.Emulated,
  providers: [ReportingService]
})
export class ApprovalForCombinedMeetingsComponent implements OnInit {
  combinedMeetingApprovalForm: FormGroup;

  meetingTypes: Meeting[];
  submitted: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private reportingServce: ReportingService
  ) {}

  ngOnInit() {
    this.getMeetingTypes();
    this.createForm();
  }

  getMeetingTypes() {
    /*this.reportingServce.getMeetings().subscribe(data => {
      this.meetingTypes = data;
    });*/
  }

  public createForm() {
    this.combinedMeetingApprovalForm = this.formBuilder.group({
      // meetingId: [2],
      meetingType: ["", Validators.required],
      theme: ["", Validators.required],
      requestNote: ["", Validators.required],
      proposedDate: ["", Validators.required],
      hostingCentre: ["", Validators.required],
      coordinatedBy: ["", Validators.required]
    });
  }

  submitCombinedMeetingApprovalForm() {
    this.submitted = true;

    /*if (this.combinedMeetingApprovalForm.valid) {
      this.reportingServce
        .combinedMeetingRequest(this.combinedMeetingApprovalForm.value)
        .subscribe(data  => {
          this.submitted = false;
          this.combinedMeetingApprovalForm.reset();
        });
    }*/
  }
}
