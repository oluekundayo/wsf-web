import { finalize } from "rxjs/operators";
import { Component, OnInit, OnDestroy } from "@angular/core";
import { APIService } from "../../../services/api.service";
import { ApiRoutes } from "../../../services/api.routes";
import { Observable, Subscription } from "rxjs";
import { Lookup, ApiUrlParam } from "../../../models/utilities.models";
import {
  CenterSearchResult,
  CenterSearchParams,
  CenterTypesPerSystem,
  CenterDescendantsPerChurchSystem,
  CentersPerSystem
} from "../../../models/centers.models";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { EditCenterDialogComponent } from "../../dialog/edit-center-dialog/edit-center-dialog.component";
import { map, get, find } from "lodash";

@Component({
  selector: "app-view-registered-centers",
  templateUrl: "./view-registered-centers.component.html",
  styleUrls: ["./view-registered-centers.component.scss"]
})
export class ViewRegisteredCentersComponent implements OnInit, OnDestroy {
  loading = false;
  searchCriteria: string = "";
  centerFinderResults: CenterSearchResult[] = [];
  bsModalRef: BsModalRef;
  descendantsCenterTypesPerSystem: CenterTypesPerSystem[] = [];
  appendTextToSearchResultLabel: string = "";
  distinctChurchSystems: Lookup[] = [];
  searchFilter: string = "";
  pagingCurrentPage: number = 1;
  pagingItemsPerPage: number = 10;

  lastSelectedCenterType: CenterTypesPerSystem;
  lastSelectedChurchSystem: Lookup;

  constructor(private api: APIService, private modalService: BsModalService) {}

  ngOnInit() {
    this.getDescendantsCounts();
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
  }

  public getDescendantsCounts() {
    this.centerFinderResults = [];

    this.loading = true;

    this.api
      .getAll<CenterDescendantsPerChurchSystem>(
        ApiRoutes.centers.get_descendants_counts_per_church_system
      )
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.descendantsCenterTypesPerSystem =
          response.descendantsTypeCountsPerSystem;
        this.distinctChurchSystems = response.systems;

        //console.log(response);
      });
  }

  public findACenter() {
    if (!this.searchCriteria) {
      alert("Search Criteria not valid.");
      return;
    }

    this.appendTextToSearchResultLabel = "Search";

    const params = new CenterSearchParams();
    params.searchByAddressOrMinister = this.searchCriteria;

    this.loading = true;
    this.api
      .post<CenterSearchResult[]>(ApiRoutes.centers.search, params)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.centerFinderResults = response;
      });
  }

  public loadCenterTypeCenters(centerType: CenterTypesPerSystem) {
    this.appendTextToSearchResultLabel = centerType.centerType + " Type";
    //console.log("response");
    const params = new CenterSearchParams();
    params.limitSearchToACenterType = true;
    params.centerTypeId = centerType.centerTypeId;

    this.loading = true;
    this.api
      .post<CenterSearchResult[]>(ApiRoutes.centers.search, params)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        // console.log(response);
        this.centerFinderResults = response;
      });

    this.lastSelectedCenterType = centerType;
    this.lastSelectedChurchSystem = null;
  }

  public loadChurchSystemCenters(churchSystem: Lookup) {
    this.appendTextToSearchResultLabel = churchSystem.name + " System";

    const params = new CenterSearchParams();
    params.limitSearchToAChurchSystem = true;
    params.churchSystemId = churchSystem.id;

    this.loading = true;
    this.api
      .post<CenterSearchResult[]>(ApiRoutes.centers.search, params)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe(response => {
        this.centerFinderResults = response;
      });

    this.lastSelectedChurchSystem = churchSystem;
    this.lastSelectedCenterType = null;
  }

  public openEditCenterDialog(
    selectedCenter: CenterSearchResult,
    type: string,
    index: number = -1
  ) {
    const config = {
      backdrop: true,
      ignoreBackdropClick: true,
      class: "modal-lg",
      animated: true,
      initialState: {
        selectedCenter: selectedCenter,
        editType: type
      }
    };

    this.bsModalRef = this.modalService.show(EditCenterDialogComponent, config);

    this.bsModalRef.content.action.subscribe((value: CenterSearchResult) => {
      // console.log(value); // here you will get the value
      /*if (value) {
        this.centerFinderResults[index] = value;
      }*/

      if (this.lastSelectedCenterType == null) {
        this.loadChurchSystemCenters(this.lastSelectedChurchSystem);
      } else if (this.lastSelectedChurchSystem == null) {
        this.loadCenterTypeCenters(this.lastSelectedCenterType);
      }
    });
  }

  public filterCentersCountInASystem(
    systemsCenters: CentersPerSystem[],
    systemId: number
  ): number {
    const system: CentersPerSystem = find(systemsCenters, function(
      o: CentersPerSystem
    ) {
      return o.churchSystemId == systemId;
    });

    return system ? system.centersCount : 0;
  }

  ngOnDestroy(): void {}
}
