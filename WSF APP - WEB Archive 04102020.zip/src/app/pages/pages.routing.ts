import { Routes } from "@angular/router";

import { RegisterComponent } from "./register/register.component";
import { LockComponent } from "./lock/lock.component";
import { LoginComponent } from "./login/login.component";
import { FaqComponent } from "./faq/faq.component";
import { ForgotPasswordComponent } from "./forgot-password/forgot-password.component";

export const PagesRoutes: Routes = [
  {
    path: "login",
    component: LoginComponent
  },

  {
    path: "lock",
    component: LockComponent
  },
  {
    path: "register",
    component: RegisterComponent
  },
  {
    path: "forgot-password",
    component: ForgotPasswordComponent
  },

  {
    path: "faq",
    component: FaqComponent
  }
];
