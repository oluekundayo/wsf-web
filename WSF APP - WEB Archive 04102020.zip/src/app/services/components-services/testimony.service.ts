import { Injectable } from "@angular/core";

import {
  TestimonyClassification,
  Testimony,
  PaginatedTestimonies,
  TestimoniesStatusReport,
  TestimonyApproval
} from "../../models/testimonies.models";
import { APIService } from "../api.service";
import { ApiRoutes } from "../api.routes";
import { Observable } from "rxjs";
import {
  ResponseModel,
  Lookup,
  VisibilityStatus,
  ApprovalPost,
  PaginatorFilter,
  ApprovalStatus,
  SimpleFilter
} from "../../models/utilities.models";
import { ReportFilter } from "../../models/reporting.models";

@Injectable()
export class TestimonyService {
  private url = ApiRoutes;
  constructor(private apiservice: APIService) {}

  getTestimoniesClassifications = () => {
    return this.apiservice.getAll<Lookup[]>(
      this.url.testimonies.get_testimonies_classifications
    );
  };

  postTestimony(testimony: Testimony): Observable<ResponseModel> {
    return this.apiservice.post<ResponseModel>(
      this.url.testimonies.testimonies,
      testimony
    );
  }

  getApprovedTestimonies = (paginator: PaginatorFilter) => {
    /*const _paginator: PaginatorFilter = {
      pageSize: paginator.pageSize,
      lastMaxId: paginator.lastMaxId,
      lastMaxDate: paginator.lastMaxDate,
      lastMinId: paginator.lastMinId,
      lastMinDate: paginator.lastMinDate,
      limitToBookmarks: paginator.limitToBookmarks
      
    };*/

    paginator.approvalStatus = ApprovalStatus.Approved;

    return this.apiservice.find<PaginatedTestimonies>(
      this.url.testimonies.get_paginated_testimonies,
      paginator
    );
  };

  getDisApprovedTestimonies = (paginator: PaginatorFilter) => {
    /*const _paginator: PaginatorFilter = {
      pageSize: paginator.pageSize,
      lastMaxId: paginator.lastMaxId,
      lastMaxDate: paginator.lastMaxDate,
      lastMinId: paginator.lastMinId,
      lastMinDate: paginator.lastMinDate,
      limitToBookmarks: paginator.limitToBookmarks
    };*/

    paginator.approvalStatus = ApprovalStatus.Disapproved;

    return this.apiservice.find<PaginatedTestimonies>(
      this.url.testimonies.get_paginated_testimonies,
      paginator
    );
  };

  getUnApprovedTestimonies = (paginator: PaginatorFilter) => {
    /* const _paginator: PaginatorFilter = {
      pageSize: paginator.pageSize,
      lastMaxId: paginator.lastMaxId,
      lastMaxDate: paginator.lastMaxDate,
      lastMinId: paginator.lastMinId,
      lastMinDate: paginator.lastMinDate,
      limitToBookmarks: paginator.limitToBookmarks
    };*/

    paginator.approvalStatus = ApprovalStatus.Unapproved;

    return this.apiservice.find<PaginatedTestimonies>(
      this.url.testimonies.get_paginated_testimonies,
      paginator
    );
  };

  getUnProofReadTestimonies = (paginator: PaginatorFilter) => {
    /*const _paginator: PaginatorFilter = {
      pageSize: paginator.pageSize,
      lastMaxId: paginator.lastMaxId,
      lastMaxDate: paginator.lastMaxDate,
      lastMinId: paginator.lastMinId,
      lastMinDate: paginator.lastMinDate,
      limitToBookmarks: paginator.limitToBookmarks
    };*/

    paginator.approvalStatus = ApprovalStatus.Unproofread;

    return this.apiservice.find<PaginatedTestimonies>(
      this.url.testimonies.get_paginated_testimonies,
      paginator
    );
  };

  /*getAllUnapprovedTestimonies = (pageSize: any, lastMinId: any) => {
    return this.apiservice.getAll<PaginatedTestimonies>(
      `${
        this.url.testimonies.get_paginated_testimonies
      }/${pageSize}/${lastMinId}`
    );
  };

  getAllActiveTestimonies = (pageSize: any, lastMinId: any) => {
    return this.apiservice.getAll<PaginatedTestimonies>(
      `${
        this.url.testimonies.get_paginated_testimonies
      }/${pageSize}/${lastMinId}`
    );
  };

  getAllBookmarkedTestimonies = (pageSize: any, lastMinId: any) => {
    return this.apiservice.getAll<PaginatedTestimonies>(
      `${
        this.url.testimonies.get_paginated_testimonies
      }/${pageSize}/${lastMinId}`
    );
  };*/

  /* searchTestimonies = (query: string) => {
    return this.apiservice.getAll<SearchTestimoniesResult[]>(
      `${this.url.testimonies.search_testimonies}/${query}`
    );
  };*/

  searchTestimonies = (filter: SimpleFilter) => {
    return this.apiservice.post<Testimony[]>(
      this.url.testimonies.search_testimonies,
      filter
    );
  };

  getTestimonyDetail = id => {
    return this.apiservice.get<Testimony>(this.url.testimonies.testimonies, id);
  };

  getTestimonyCategories() {
    return this.apiservice.getAll<Lookup[]>(
      this.url.testimonies.get_testimonies_classifications
    );
  }

  public bookmarkItem(bookmark) {
    return this.apiservice.put(
      this.url.testimonies.bookmark_testimony,
      0,
      bookmark
    );
  }
  public approveItem(itemId: number, approval: TestimonyApproval) {
    return this.apiservice.put(
      this.url.testimonies.approve_testimony,
      itemId,
      approval
    );
  }

  public proofReadItem(itemId: number, approval: TestimonyApproval) {
    return this.apiservice.put(
      this.url.testimonies.proofread_testimony,
      itemId,
      approval
    );
  }

  public saveNewClassification(classif: Lookup) {
    return this.apiservice.post(
      this.url.testimonies.save_new_classification,
      classif
    );
  }

  public getTestimoniesReport(filter: SimpleFilter) {
    return this.apiservice.find<TestimoniesStatusReport>(
      this.url.testimonies.get_testimonies_reports,
      filter
    );
  }

  public getMyPreviousTestimonies(filter: SimpleFilter) {
    return this.apiservice.find<Testimony[]>(
      this.url.testimonies.get_my_previous_testimonies,
      filter
    );
  }

  public updateVisibilityStatus(id: number, status: ApprovalPost) {
    return this.apiservice.patch(
      this.url.testimonies.patch_visibility_status,
      id,
      status
    );
  }

  deleteTestimony = id => {
    return this.apiservice.delete<Testimony>(
      this.url.testimonies.testimonies,
      id
    );
  };
}
